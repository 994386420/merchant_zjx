package com.merchant.address;

import java.util.HashMap;

import com.merchant.adapter.CityListAdapter;
import com.merchant.base.BaseActivity;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
/**
 * ��ַѡ��
 * 
 * @author chenwei
 * 
 * 
 */
public class AddressChooseActivity extends BaseActivity implements OnClickListener {
	
	private ImageView manage_title_back_image;// ����
	private TextView et_province;
	private TextView et_city;
	private TextView et_area;
	private FrameLayout choose_province_frame_layout;
	private FrameLayout choose_city_frame_layout;
	private FrameLayout choose_area_frame_layout;
	/*
	 * ���ʡ�ݡ����ء�����
	 */
	private PopupWindow mPopupWindow;
	private ListView mListView;
	private CityListAdapter mListAdapter;
	private String[] mCitys, mAreas;// ������С���������
	private HashMap<String, String> mCityMaps, mAreaMaps;// ���С�����map
	private String mProvinceId, mCityId, mAreaId;// ʡ�ݡ����С�����id
	private TextView text_title;// ����
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_address_choose);
		initProvinceDatas();
		Init();	
	}

	private void Init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("��д��ַ");
		et_province = (TextView) findViewById(R.id.choose_province_edit);
		et_city =  (TextView) findViewById(R.id.choose_city_edit);
		et_area =  (TextView) findViewById(R.id.choose_area_edit);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		choose_province_frame_layout = (FrameLayout) findViewById(R.id.choose_province_frame_layout);
		choose_city_frame_layout = (FrameLayout) findViewById(R.id.choose_city_frame_layout);
		choose_area_frame_layout = (FrameLayout) findViewById(R.id.choose_area_frame_layout);
		manage_title_back_image.setOnClickListener(this);
		choose_province_frame_layout.setOnClickListener(this);
		choose_city_frame_layout.setOnClickListener(this);
		choose_area_frame_layout.setOnClickListener(this);
	}


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
		View view;
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.choose_province_frame_layout:
			Log.i("ddddd", "=================");
			if (mProvinDatasMap != null && mProvinDatasMap.length > 0) {
				Log.i("ddddd", "____________________-");
				view = inflater.inflate(R.layout.popup_city_layout, null);
				mPopupWindow = new PopupWindow(view, 500,
						300, false);
				mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
				mPopupWindow.showAsDropDown(et_province);
				mListView = (ListView) view.findViewById(R.id.popup_city_list);
				mListAdapter = new CityListAdapter(getApplicationContext(),
						mProvinDatasMap);
				mListView.setAdapter(mListAdapter);
				mListView.setOnItemClickListener(mProvinceItemClickListener);

			}
			break;

		case R.id.choose_city_frame_layout:
			if (mCitys != null && mCitys.length > 0) {
				view = inflater.inflate(R.layout.popup_city_layout, null);
				mPopupWindow = new PopupWindow(view, 500,
						300, false);
				mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
				mPopupWindow.showAsDropDown(et_city);
				mListView = (ListView) view.findViewById(R.id.popup_city_list);
				mListAdapter = new CityListAdapter(getApplicationContext(),
						mCitys);
				mListView.setAdapter(mListAdapter);
				mListView.setOnItemClickListener(mCityItemClickListener);
			}
			break;
		case R.id.choose_area_frame_layout:
			if (mAreas != null && mAreas.length > 0) {
				view = inflater.inflate(R.layout.popup_city_layout, null);
				mPopupWindow = new PopupWindow(view, 500,
						300, false);
				mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
				mPopupWindow.showAsDropDown(et_area);
				mListView = (ListView) view.findViewById(R.id.popup_city_list);
				mListAdapter = new CityListAdapter(getApplicationContext(),
						mAreas);
				mListView.setAdapter(mListAdapter);
				mListView.setOnItemClickListener(mAreaItemClickListener);
			}
			break;
		}
	}
	
	OnItemClickListener mProvinceItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mPopupWindow.dismiss();
			mCitys = mCitisDatasMap.get(mProvinDatasMap[position]);
			mCityMaps = mCitysAllMap.get(mProvinDatasMap[position]);
			et_province.setText(mProvinDatasMap[position]);
			// ��ȡѡ���ʡ��id
			mProvinceId = mProvinceAllMap.get(mProvinDatasMap[position]);
			Log.i("ʡ��id", mProvinDatasMap[position] + "==============="
					+ mProvinceId);
		}
	};

	OnItemClickListener mCityItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mPopupWindow.dismiss();
			mAreas = mDistrictDatasMap.get(mCitys[position]);
			mAreaMaps = mDistrictAllMap.get(mCitys[position]);
			et_city.setText(mCitys[position]);
			// ��ȡѡ��ĳ���id
			mCityId = mCityMaps.get(mCitys[position]);
			Log.i("����id", mCitys[position] + "============" + mCityId);
		}
	};

	OnItemClickListener mAreaItemClickListener = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mPopupWindow.dismiss();
			et_area.setText(mAreas[position]);
			// ��ȡѡ�������id
			mAreaId = mAreaMaps.get(mAreas[position]);
			Log.i("����id",
					mAreas[position] + "========="
							+ mAreaMaps.get(mAreas[position]));
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
