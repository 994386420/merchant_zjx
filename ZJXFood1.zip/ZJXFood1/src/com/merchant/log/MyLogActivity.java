package com.merchant.log;

/**
 * ��¼
 * 
 * @author chenwei
 * 
 * 
 */

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.constant.MyApplication;
import com.merchant.dialog.CustomProgressDialog;
import com.merchant.home.AgentHomeActivity;
import com.merchant.home.BeautySalouHomeActivity;
import com.merchant.home.MyHomeActivity;
import com.merchant.json.ReadJson;
import com.merchant.merchantsettled.MerChantSettledActivity;
import com.merchant.popupwindow.XieyiPopupWindow;
import com.merchant.util.UpdateVersionService;
import com.merchant.zjxfood.RetrievePassWordActivity;
import com.merchant.zjxfood.RetrievePwdActivity;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Paint;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class MyLogActivity extends Activity implements OnClickListener {
	// ��¼
	private TextView mLog;
	// ������
	private LinearLayout mHeadLayout;
	// ��������
	private TextView mForgetPwdText;
	// ����
	private ImageView mBackImage;
	// ��¼��ť
	private Button mLogBtn;
	// �û���������
	private EditText mUserName, mPassWord;
	private String json = "";
	private Bundle mBundle;
	private String username;
	private ArrayList<HashMap<String, Object>> mList;
	private ImageView user_pwd_delete_image;
	private ImageView user_name_delete_image;
	// �̼�������פ
	private Button btn_MerchantStettled;
	// ��ס����
	private CheckBox mRememberPwd;
	private String id;
	private boolean isLogClick = true;
	private String sign = "";
	private CheckBox checkBox_remember_btn_login;
	// private ArrayList<HashMap<String, Object>> mUserMap;
	private ArrayList<HashMap<String, Object>> mUserDataList;
	private MainFrameTask mMainFrameTask = null;
	private CustomProgressDialog progressDialog = null;
	private HashMap<String, Object> mUserMapLists;
	boolean isExit;
	private XieyiPopupWindow xieyipop;
	private UpdateVersionService updateVersionService;
	String str = null;
	private MyApplication MyApplication;
	public static String num = "0";

	// private String can = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_log);
		initView();
		// �ж��Ƿ��ס����
		isRemember();
		mBundle = getIntent().getExtras();
		if (mBundle != null) {
			username = mBundle.getString("userName");
			mUserName.setText(username);
			id = mBundle.getString("Id");
		}
		MyApplication = (MyApplication) getApplication();
		if (MyApplication.getName().equals("1")) {
			handler.sendEmptyMessageDelayed(5, 1000);
		}
		// �ж��Ƿ�������
		if (!(isNetworkConnected(getApplicationContext()))
				&& !(isWifiConnected(getApplicationContext()))) {
			Toast.makeText(getApplicationContext(), "���粻���ã����������",
					Toast.LENGTH_SHORT).show();
		}
	}

	private void initView() {
		mHeadLayout = (LinearLayout) findViewById(R.id.user_log_title);
		mLog = (TextView) findViewById(R.id.log_user_log_text);
		mForgetPwdText = (TextView) findViewById(R.id.forget_password_text);
		// mBackImage = (ImageView) mHeadLayout
		// .findViewById(R.id.user_log_back_image);
		mLogBtn = (Button) findViewById(R.id.user_log_submit);
		mUserName = (EditText) findViewById(R.id.user_name_edit);
		mPassWord = (EditText) findViewById(R.id.user_pwd_edit);
		// mRememberPwd = (CheckBox)
		// findViewById(R.id.checkBox_remember_btn_login);
		btn_MerchantStettled = (Button) findViewById(R.id.btn_Merchants_settled);
		mForgetPwdText.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);// �»���
		user_name_delete_image = (ImageView) findViewById(R.id.user_name_delete_image);
		user_pwd_delete_image = (ImageView) findViewById(R.id.user_pwd_delete_image);
		checkBox_remember_btn_login = (CheckBox) findViewById(R.id.checkBox_remember_btn_login);

		user_name_delete_image.setOnClickListener(this);
		user_pwd_delete_image.setOnClickListener(this);
		checkBox_remember_btn_login.setOnClickListener(this);
		mUserName.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				if (TextUtils.isEmpty(s)) {
					user_name_delete_image.setVisibility(View.GONE);
					checkBox_remember_btn_login.setChecked(true);
					mLogBtn.setBackgroundResource(R.drawable.bg_message_btn_start);
				} else {
					user_name_delete_image.setVisibility(View.VISIBLE);
					mLogBtn.setBackgroundResource(R.drawable.bg_message_btn);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub

			}
		});
		mPassWord.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				if (TextUtils.isEmpty(arg0)) {
					user_pwd_delete_image.setVisibility(View.GONE);
					checkBox_remember_btn_login.setChecked(true);
				} else {
					user_pwd_delete_image.setVisibility(View.VISIBLE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub

			}
		});
		mForgetPwdText.setOnClickListener(this);
		// mBackImage.setOnClickListener(this);
		mLogBtn.setOnClickListener(this);
		btn_MerchantStettled.setOnClickListener(this);
		// mAutomaticLog.setOnCheckedChangeListener(mChangeListener);

	}

	// ��ȡ�����ʺ���Ϣ
	private void isRemember() {
		SharedPreferences sp = getApplicationContext().getSharedPreferences(
				"MyMerchants", MODE_PRIVATE);
		if (sp != null) {
			mUserName.setText(sp.getString("userName", ""));
			mPassWord.setText(sp.getString("pwd", ""));
			// Constants.password = mu;
		}

	}

	@Override
	public void onClick(View v) {
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.user_name_delete_image:
			mUserName.setText("");
			break;
		case R.id.user_pwd_delete_image:
			mPassWord.setText("");
			break;
		case R.id.btn_Merchants_settled:
			// �̼�������פ
			intent.setClass(getApplicationContext(),
					MerChantSettledActivity.class);
			startActivity(intent);
			break;
		case R.id.forget_password_text:
			// ��������
			intent.setClass(getApplicationContext(), RetrievePwdActivity.class);
			startActivity(intent);
			break;
		case R.id.user_log_submit:
			if (mUserName.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "�������û���!",
						Toast.LENGTH_SHORT).show();
			} else if (mPassWord.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "�������û�����!",
						Toast.LENGTH_SHORT).show();
			} else if (!mUserName.getText().toString().equals("")
					&& !mPassWord.getText().toString().equals("")) {
				// mMainFrameTask = new MainFrameTask(this);
				// mMainFrameTask.execute();
				startProgressDialog();
				new Thread(mLogRun).start();
			} else {
				stopProgressDialog();
				Toast.makeText(getApplicationContext(), "��¼ʧ��!",
						Toast.LENGTH_SHORT).show();
			}
			break;
		}
	}

	// ����
	Runnable startUpdateRun = new Runnable() {
		@Override
		public void run() {
			Looper.prepare();
			updateVersionService = new UpdateVersionService(Constants.update,
					MyLogActivity.this);// ��������ҵ�����
			updateVersionService.checkUpdate();// ���ü����µķ���,������Ը���.�͸���.���ܸ��¾���ʾ�Ѿ������µİ汾��
			Looper.loop();
		}
	};
	Runnable mLogRun = new Runnable() {

		@Override
		public void run() {
			try {
				Pattern p = Pattern.compile("\\s*|\t|\r|\n");
				String ss = "username=" + mUserName.getText().toString()
						+ "&password=" + mPassWord.getText().toString();
				String sign = Constants.sortsStr(ss);

				String str = Constants.logUser
						+ sign
						+ "&username="
						+ URLEncoder.encode(mUserName.getText().toString(),
								"UTF-8") + "&password="
						+ mPassWord.getText().toString();
				// Log.i("log", ss+"========="+str);
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mUserMapLists", mUserMapLists
						+ "========mUserMapLists========");
				// mUserMap.get(1).get("Message").toString();
				Constants.Message = mUserMapLists.get("Message").toString();
				// Log.i("Message",
				// "================"
				// + mUserMap.get(0).get("Data").toString());
				mUserDataList = Constants.getJsonArray(mUserMapLists
						.get("Data").toString());
				Constants.Id = mUserDataList.get(0).get("id").toString();
				Constants.mtype = mUserDataList.get(0).get("mtype").toString();
				Constants.username = mUserDataList.get(0).get("username")
						.toString();
				Constants.merchantname = mUserDataList.get(0)
						.get("merchantname").toString();
				Constants.mobile = mUserDataList.get(0).get("mobile")
						.toString();
				// Log.i("kkkkkkkkkk", "lllllll"+
				// mUserDataList.get(0).get("password")
				// .toString());
				Log.i("mUserDataList", mUserDataList + "================");

				// ѡ���ס�ʺ�
				if (checkBox_remember_btn_login.isChecked()) {
					SharedPreferences sp = getApplicationContext()
							.getSharedPreferences("MyMerchants", MODE_PRIVATE);
					Editor editor = sp.edit();
					editor.putString("userName",
							p.matcher(mUserName.getText().toString())
									.replaceAll(""));
					editor.putString("pwd",
							p.matcher(mPassWord.getText().toString())
									.replaceAll(""));
					Constants.password = mPassWord.getText().toString();
					Constants.musername = mUserName.getText().toString();
					editor.putString("flag", 0 + "");
					editor.commit();

				}
				if (mUserDataList.get(0).get("mtype").toString().equals("1")) {
					handler.sendEmptyMessageDelayed(1, 1);
				} else if (mUserDataList.get(0).get("mtype").toString()
						.equals("2")) {
					handler.sendEmptyMessageDelayed(2, 1);
				} else if (mUserDataList.get(0).get("mtype").toString()
						.equals("3")) {
					handler.sendEmptyMessageDelayed(3, 1);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler.sendEmptyMessageDelayed(4, 0);
		}

	};

	Handler handler = new Handler() {
		@SuppressLint("HandlerLeak")
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				// ������
				isLogClick = true;
				intent.setClass(getApplicationContext(),
						AgentHomeActivity.class);
				// Bundle bundle = new Bundle();
				// bundle.putString("name", mUserName.getText().toString());
				// intent.putExtras(bundle);
				startActivity(intent);
				finish();
				break;
			case 2:
				// ����Ժ
				isLogClick = true;
				intent.setClass(getApplicationContext(),
						BeautySalouHomeActivity.class);
				startActivity(intent);
				finish();
				break;
			case 3:
				// ������
				isLogClick = true;
				intent.setClass(getApplicationContext(), MyHomeActivity.class);
				startActivity(intent);
				finish();
				break;
			case 4:
				stopProgressDialog();
				Toast.makeText(getApplicationContext(), Constants.Message,
						Toast.LENGTH_SHORT).show();
				break;
			case 5:
				new Thread(startUpdateRun).start();
				break;

			}
		};
	};
	/**
	 * �ж������Ƿ��
	 * 
	 * @param context
	 * @return
	 */
	public boolean isNetworkConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mNetworkInfo = mConnectivityManager
					.getActiveNetworkInfo();
			if (mNetworkInfo != null) {
				return mNetworkInfo.isAvailable();
			}
		}
		return false;
	}

	/**
	 * �ж�wifi�Ƿ����
	 * 
	 * @param context
	 * @return
	 */
	public boolean isWifiConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mWiFiNetworkInfo = mConnectivityManager
					.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
			if (mWiFiNetworkInfo != null) {
				return mWiFiNetworkInfo.isAvailable();
			}
		}
		return false;
	}
	OnCheckedChangeListener mChangeListener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
			if (isChecked) {
				checkBox_remember_btn_login.setChecked(true);
			}
		}
	};

	@Override
	protected void onDestroy() {
		stopProgressDialog();
		if (mMainFrameTask != null && !mMainFrameTask.isCancelled()) {
			mMainFrameTask.cancel(true);
		}
		super.onDestroy();
	}

	private void startProgressDialog() {
		if (progressDialog == null) {
			progressDialog = CustomProgressDialog.createDialog(this);
			// progressDialog.setMessage("��¼��...");
		}
		progressDialog.show();
	}

	private void stopProgressDialog() {
		if (progressDialog != null) {
			progressDialog.dismiss();
			progressDialog = null;
		}
	}

	public class MainFrameTask extends AsyncTask<Integer, String, Integer> {
		private MyLogActivity log = null;

		public MainFrameTask(MyLogActivity log) {
			this.log = log;
		}

		@Override
		protected void onCancelled() {
			stopProgressDialog();
			super.onCancelled();
		}

		@Override
		protected Integer doInBackground(Integer... params) {

			// try {
			// Thread.sleep(5000);
			// } catch (InterruptedException e) {
			// e.printStackTrace();
			// }
			return null;
		}

		@Override
		protected void onPreExecute() {
			startProgressDialog();
		}

		@Override
		protected void onPostExecute(Integer result) {
			stopProgressDialog();
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",
					Toast.LENGTH_SHORT).show();
			// ����handler�ӳٷ��͸���״̬��Ϣ
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};
}
