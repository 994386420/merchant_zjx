package com.merchant.manage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import com.merchant.adapter.ListViewAdapter;
import com.merchant.base.BaseActivity;
import com.merchant.constant.Constants;
import com.merchant.dialog.CustomProgressDialog;
import com.merchant.json.ReadJson;
import com.merchant.util.AsycImageLoader;
import com.merchant.util.BitmapUtil;
import com.merchant.util.DensityUtils;
import com.merchant.util.FileUtil;
import com.merchant.util.ImageBean;
import com.merchant.util.PathUtil;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.app.ActionBar.LayoutParams;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * �����޸�
 * 
 * @author chenwei
 * 
 * 
 */
@SuppressLint({ "SdCardPath", "ShowToast" })
public class DataModificationActivity extends BaseActivity implements
		OnClickListener {
	private final static String ALBUM_PATH = Environment
			.getExternalStorageDirectory() + "/download/";
	private ProgressDialog mSaveDialog = null;
	private String mFileName;
	private String mSaveMessage;
	private ImageView manage_title_back_image;// ����
	private AsycImageLoader imageloader;
	private ImageButton iamge1;
	private ImageButton iamge2;
	private ImageButton iamge3;
	private ImageButton image4;
	private CheckBox set_money_have;
	private CheckBox set_money_no;
	private CheckBox wifi_have;
	private CheckBox wifi_no;
	private CheckBox isparking;
	private CheckBox isparking_free;
	private CheckBox isparking_money;
	private CheckBox xieyi_checkbox;
	private Button xiazai;
	private int num;
	private int numm;
	boolean ischeck;
	/*
	 * ���ͼƬ����
	 */
	private Bitmap bitmap = null;// ͼƬ����
	public static ArrayList<ImageBean> imageList = new ArrayList<ImageBean>();
	private String image_path = null;
	private String image_pathh = null;
	private PopupWindow popupWindow = null;
	private View popView = null;
	private int clickedNum = 0;// �����Ƭ��ť�ı��
	private int CAMER = 10;// ����
	private int ALBUMS = 20;// ��Ƭ
	private TextView text_title;// ����
	private FrameLayout manage_time_choose_layout;// ʱ������
	// private LinearLayout manage_address_choose_layout;// ��ַѡ��
	// ��ʳ���
	private EditText food_ca_edt; // ������ť
	private PopupWindow pop_window; // PopupWindow��������
	private ArrayList<String> list;
	private FrameLayout food_frame_layout;
	// ���ö���
	private TextView set_money_text;// ���ö�������
	private FrameLayout set_money_frame_layout;
	private ArrayList<String> list_money;
	private PopupWindow pop_window_money; // PopupWindow��������
	// ��ǰѡ�е��б���λ��
	int clickPsition = -1;
	// Ӫҵʱ��
	private TextView start_time_text;
	private TextView end_time_text;
	private EditText rjxf_edt;// �˾�����
	private EditText detail_introduction;// ��ϸ����
	private TextView merchant_acount;// �̼��˺�
	private TextView merchant_phone;// �̼ҵ绰
	private TextView merchant_address;// �̼ҵ�ַ
	private Button manage_save;
	private String[] mPath = new String[4];
	private int x = 1;
	RunTask mRunTask;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> mGroupList;
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;
	private PopupWindow popupUpdate = null;
	private CustomProgressDialog progressDialog = null;
	private static final int DOWNLOAD_PREPARE = 0;
	private static final int DOWNLOAD_WORK = 1;
	private static final int DOWNLOAD_OK = 2;
	private static final int DOWNLOAD_ERROR = 3;
	private String url = "http://ssnn.hexnews.com/shxy.doc";
	private static final String TAG = "DataModificationActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_data_modification);
		init();
		new Thread(getmyinfo).start();
		new Thread(getgroups).start();
		registerBoradcastReceiver();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("�����޸�");
		manage_time_choose_layout = (FrameLayout) findViewById(R.id.manage_time_choose_layout);
		iamge1 = (ImageButton) findViewById(R.id.image1);
		iamge2 = (ImageButton) findViewById(R.id.image2);
		iamge3 = (ImageButton) findViewById(R.id.image3);
		image4 = (ImageButton) findViewById(R.id.image4);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		// Ӫҵ��ʼʱ��
		start_time_text = (TextView) findViewById(R.id.start_time_text);
		// Ӫҵ����ʱ��
		end_time_text = (TextView) findViewById(R.id.end_time_text);
		manage_title_back_image.setOnClickListener(this);
		iamge1.setOnClickListener(this);
		iamge2.setOnClickListener(this);
		iamge3.setOnClickListener(this);
		image4.setOnClickListener(this);
		manage_time_choose_layout.setOnClickListener(this);
		food_ca_edt = (EditText) findViewById(R.id.food_ca_edt);
		food_frame_layout = (FrameLayout) findViewById(R.id.food_frame_layout);
		food_frame_layout.setOnClickListener(this);
		set_money_text = (TextView) findViewById(R.id.set_money_text);
		list_money = getListMoney();
		set_money_text.setText(list_money.get(0));
		set_money_frame_layout = (FrameLayout) findViewById(R.id.set_money_frame_layout);
		set_money_frame_layout.setOnClickListener(this);
		rjxf_edt = (EditText) findViewById(R.id.rjxf_edt);
		detail_introduction = (EditText) findViewById(R.id.detail_introduction);
		merchant_acount = (TextView) findViewById(R.id.merchant_account);
		merchant_phone = (TextView) findViewById(R.id.merchant_phone);
		merchant_address = (TextView) findViewById(R.id.merchant_address);
		manage_save = (Button) findViewById(R.id.manage_save);
		set_money_have = (CheckBox) findViewById(R.id.set_money_checkhave);
		set_money_no = (CheckBox) findViewById(R.id.set_money_checkno);
		wifi_have = (CheckBox) findViewById(R.id.wifi_checkhave);
		wifi_no = (CheckBox) findViewById(R.id.wifi_checkno);
		isparking = (CheckBox) findViewById(R.id.parking_check);
		isparking_free = (CheckBox) findViewById(R.id.parking_checkhave);
		isparking_money = (CheckBox) findViewById(R.id.parking_checkno);
		xiazai = (Button) findViewById(R.id.xizai);
		// xieyi_checkbox = (CheckBox) findViewById(R.id.xizai_ck);
		manage_save.setOnClickListener(this);
		xiazai.setOnClickListener(this);
		set_money_have.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (set_money_have.isChecked()) {
					set_money_no.setChecked(false);
				}
			}
		});

		set_money_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (set_money_no.isChecked()) {
					set_money_have.setChecked(false);
				}
			}
		});

		wifi_have.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (wifi_have.isChecked()) {
					wifi_no.setChecked(false);
				}
			}
		});

		wifi_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (wifi_no.isChecked()) {
					wifi_have.setChecked(false);
				}
			}
		});

		isparking.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (isparking.isChecked()) {
					isparking_free.setChecked(false);
					isparking_money.setChecked(false);
				}
			}
		});

		isparking_free.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (isparking_free.isChecked()) {
					isparking.setChecked(false);
					isparking_money.setChecked(false);
				}
			}
		});

		isparking_money.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (isparking_money.isChecked()) {
					isparking.setChecked(false);
					isparking_free.setChecked(false);
				}
			}
		});
	}

	@SuppressLint({ "InlinedApi", "InflateParams", "ShowToast" })
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.manage_time_choose_layout:
			intent.setClass(getApplicationContext(),
					ManageTimeChooseActivity.class);
			intent.putExtra("start_time_text", start_time_text.getText()
					.toString());
			intent.putExtra("end_time_text", end_time_text.getText().toString());
			startActivity(intent);
			break;
		case R.id.xizai:
			Toast.makeText(this, "��ʼ�����ļ�", Toast.LENGTH_SHORT).show();
			new Thread() {
				@Override
				public void run() {
					downloadFile();
					super.run();
				}
			}.start();
			break;
		case R.id.image1:
			clickedNum = 0;
			showPopupWindow(v);
			break;
		case R.id.image2:
			clickedNum = 1;
			showPopupWindow(v);
			break;
		case R.id.image3:
			clickedNum = 2;
			showPopupWindow(v);
			break;
		case R.id.image4:
			clickedNum = 3;
			showPopupWindow(v);
			break;
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.manage_save:
			x = 1;
			startProgressDialog();
			mRunTask = new RunTask();
			mRunTask.execute("");
			break;
		case R.id.set_money_frame_layout:
			// ͨ������ע������ע�벼�ָ�View����
			View myViewm = getLayoutInflater().inflate(R.layout.pop, null);
			// ͨ��view �Ϳ����ߣ�����PopopWindow
			pop_window_money = new PopupWindow(myViewm, DensityUtils.dp2px(
					getApplicationContext(), 60), 240, true);
			pop_window_money.setBackgroundDrawable(getResources().getDrawable(
			// �˴�Ϊpopwindow ���ñ�����ͬ��.��������ⲿ����popwindow��ʧ
					R.color.no));
			pop_window_money.setFocusable(true);
			// ��window��ͼ��ʾ����Ҫ�Ĳ�������
			pop_window_money.showAsDropDown(set_money_frame_layout);
			ListView lvm = (ListView) myViewm.findViewById(R.id.lv_pop);
			lvm.setAdapter(new ListViewAdapter(DataModificationActivity.this,
					list_money));
			lvm.setOnItemClickListener(new AdapterView.OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,

				int position, long id) {

					set_money_text.setText(list_money.get(position));

					if (clickPsition != position) {

						clickPsition = position;
					}
					pop_window_money.dismiss();
				}
			});
			break;
		}
	}

	public ArrayList<String> getListMoney() {
		ArrayList<String> list_money = new ArrayList<String>();
		for (int i = 0; i < 101; i++) {
			list_money.add(i, "" + i);
		}
		return list_money;
	}

	/**
	 * �ļ�����
	 */
	private void downloadFile() {
		try {
			URL u = new URL(url);
			URLConnection conn = u.openConnection();
			conn.connect();
			InputStream is = conn.getInputStream();
			fileSize = conn.getContentLength();
			if (fileSize < 1 || is == null) {
				sendMessage(DOWNLOAD_ERROR);
			} else {
				sendMessage(DOWNLOAD_PREPARE);
				FileOutputStream fos = new FileOutputStream(getPath());
				byte[] bytes = new byte[1024];
				int len = -1;
				while ((len = is.read(bytes)) != -1) {
					fos.write(bytes, 0, len);
					downloadSize += len;
					sendMessage(DOWNLOAD_WORK);
				}
				sendMessage(DOWNLOAD_OK);
				is.close();
				fos.close();
			}
		} catch (Exception e) {
			sendMessage(DOWNLOAD_ERROR);
			e.printStackTrace();
		}
	}

	/**
	 * �ļ�һ���Ĵ�С
	 */
	int fileSize = 0;
	/**
	 * �Ѿ����صĴ�С
	 */
	int downloadSize = 0;
	/**
	 * handler������Ϣ
	 */
	@SuppressLint("HandlerLeak")
	private Handler handler1 = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case DOWNLOAD_PREPARE:
				// Toast.makeText(DataModificationActivity.this, "����׼��",
				// Toast.LENGTH_SHORT).show();
				// pb.setVisibility(ProgressBar.VISIBLE);
				Log.e(TAG, "һ��:" + fileSize);
				// pb.setMax(fileSize);
				break;
			case DOWNLOAD_WORK:
				Log.e(TAG, "������:" + downloadSize);
				// pb.setProgress(downloadSize);
				int res = downloadSize * 100 / fileSize;
				xiazai.setText("�����أ�" + res + "%");
				break;
			case DOWNLOAD_OK:
				Toast.makeText(DataModificationActivity.this, "�������",
						Toast.LENGTH_SHORT).show();
				xiazai.setClickable(false);
				xiazai.setText("�������!");
				break;
			case DOWNLOAD_ERROR:
				Toast.makeText(DataModificationActivity.this, "���س���",
						Toast.LENGTH_SHORT).show();
				break;
			}
			super.handleMessage(msg);
		}
	};

	/**
	 * �õ��ļ��ı���·��
	 * 
	 * @return
	 * @throws IOException
	 */
	private String getPath() throws IOException {
		String path = FileUtil.setMkdir(this) + File.separator
				+ url.substring(url.lastIndexOf("/") + 1);
		return path;
	}

	/**
	 * ��hand������Ϣ
	 * 
	 * @param what
	 */
	private void sendMessage(int what) {
		Message m = new Message();
		m.what = what;
		handler1.sendMessage(m);
	}

	/**
	 * ��ʾPopupWindow
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@SuppressLint({ "InlinedApi", "InflateParams", "ClickableViewAccessibility" })
	private void showPopupWindow(View anchor) {
		popView = LayoutInflater.from(this).inflate(R.layout.popupwindow_pop,
				null);
		popupWindow = new PopupWindow(popView, LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);
		popupWindow.setBackgroundDrawable(new ColorDrawable(0));// ���ñ���͸��
		popupWindow.setFocusable(true);// ��ý���
		popupWindow.setAnimationStyle(R.style.AnimBottom);
		popupWindow.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
		popupWindow.showAtLocation(anchor, Gravity.BOTTOM, 0, 0);
		popupWindow.update();// ˢ������
		popView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (popupWindow != null && popupWindow.isShowing()) {
					popupWindow.dismiss();
					popupWindow = null;
				}
				return false;
			}
		});
		// ���õ���¼�
		Button btn_taking_pictures = (Button) popView
				.findViewById(R.id.btn_taking_pictures);
		Button btn_photo_album = (Button) popView
				.findViewById(R.id.btn_photo_album);
		Button btn_cancle = (Button) popView.findViewById(R.id.btn_o_cancle);
		// ����
		btn_taking_pictures.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				deleteData(clickedNum);
				Intent intent = new Intent();
				intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
				// �ȶ���һ��ͼƬ�ļ���·��
				image_path = PathUtil.getPath_Image();
				Uri uri = Uri.fromFile(new File(image_path));
				intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
				intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
				startActivityForResult(intent, CAMER + clickedNum);
			}
		});
		// ��Ƭ
		btn_photo_album.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// ���ѡ�����յİ�ť����ͼƬ����ɾ��
				deleteData(clickedNum);
				if (Environment.getExternalStorageState().equals(
						Environment.MEDIA_MOUNTED)) {
					Intent intent = new Intent();
					intent.setAction(Intent.ACTION_GET_CONTENT);
					intent.addCategory(Intent.CATEGORY_OPENABLE);
					intent.setType("image/jpeg");
					startActivityForResult(intent, ALBUMS + clickedNum);
				}
			}
		});
		btn_cancle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				popupWindow.dismiss();
			}
		});
	}

	/**
	 * �����Ƭ
	 */
	@SuppressLint("ShowToast")
	@SuppressWarnings("deprecation")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Bitmap small_Bitmap = null;
		// �ж��Ƿ񷵻سɹ�
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode >= ALBUMS && requestCode < ALBUMS + 5) {// ��������淵�ص�����
				if (data == null) {
					Toast.makeText(this, "ͼƬû���õ�", 0).show();
					return;
				}
				clickedNum = requestCode - ALBUMS;
				// �������
				Uri uri = data.getData();
				Log.i("msg", uri.toString());
				// ���ͼƬ·��
				String proj = MediaStore.Images.Media.DATA;
				Cursor c = this.managedQuery(uri, new String[] { proj }, null,
						null, null);
				c.moveToFirst();
				int column_index = c
						.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
				image_path = c.getString(column_index);
				Log.i("msg", "path: " + image_path);
				// �Ż�ͼƬ
				bitmap = BitmapUtil.createImageThumbnail(image_path);
				image_path = PathUtil.getPath_Image();// ���һ���µ�ͼƬ·��
			}

			if (requestCode >= CAMER && requestCode < CAMER + 5) {// ��������淵�ص�����
				clickedNum = requestCode - CAMER;
				if (!Environment.getExternalStorageState().equals(
						Environment.MEDIA_MOUNTED)) {
					Toast.makeText(this, "SD��������", 1).show();
					return;
				}
				// ���������ص�����//�Ӵ洢��·���л��ͼƬ
				bitmap = BitmapUtil.createImageThumbnail(image_path);// ���·���ڵ�������ʱ����Ѿ��õ���
				// ����sd����
				Log.i("msg", "pathName: " + image_path);
			}
			mPath[clickedNum] = image_path;
			Log.i("msgggggggg", image_path);
			BitmapUtil.saveBitmap(image_path, bitmap);// ����ͼƬ
			small_Bitmap = BitmapUtil.createImageThumbnail(bitmap);// ��С
			// ��ͼƬ�ŵ��ؼ���
			switch (clickedNum) {
			case 0:
				iamge1.setImageBitmap(small_Bitmap);
				Log.i("msg", "photo0Im: " + iamge1);
				break;
			case 1:
				iamge2.setImageBitmap(small_Bitmap);
				break;
			case 2:
				iamge3.setImageBitmap(small_Bitmap);
				break;
			case 3:
				image4.setImageBitmap(small_Bitmap);
				break;

			}
			addData();
		} else {
			Toast.makeText(this, "ͼƬû���õ�", 0).show();
		}
		popupWindow.dismiss();

		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * ����ͼƬ·����ͼƬ������
	 */
	private void addData() {
		// ����ͼƬ·����������
		String[] s = image_path.split("/");
		ImageBean bean = new ImageBean(clickedNum, s[s.length - 1], bitmap);
		imageList.add(bean);
	}

	/**
	 * ɾ������
	 */
	public static void deleteData(int index) {
		// ���ѡ�����յİ�ť����ͼƬ����ɾ��
		for (int i = 0; i < imageList.size(); i++) {
			if (imageList.get(i).get_id() == index) {
				BitmapUtil.deleteBitmap(imageList.get(i).getPath());
				imageList.remove(i);
			}
		}
	}

	private void uploadEvaluation(String[] path) throws Exception {
		String res = "";
		try {

			if (wifi_have.isChecked()) {
				num = 1;
			} else if (wifi_no.isChecked()) {
				num = 0;
			}
			if (isparking.isChecked()) {
				numm = 0;
			} else if (isparking_free.isChecked()) {
				numm = 1;
			} else if (isparking_money.isChecked()) {
				numm = 2;
			}
			String ss = "uid="
					+ Constants.Id
					+ "&groupid="
					+ mDataList.get(0).get("groupid").toString()
					+ "&dcbl="
					+ set_money_text.getText().toString()
					// + et_province.getText().toString()
					+ "&iswifi="
					+ num
					// + et_city.getText().toString()
					+ "&rjxf="
					+ rjxf_edt.getText().toString()
					// + et_area.getText().toString()
					+ "&isparking=" + numm + "&starttime="
					+ start_time_text.getText().toString() + "&closetime="
					+ end_time_text.getText().toString() + "&introduction="
					+ detail_introduction.getText().toString();
			String sign = Constants.sortsStr(ss);
			res = Constants.updateinfo
					+ sign
					+ "&uid="
					+ Constants.Id
					+ "&groupid="
					+ mDataList.get(0).get("groupid").toString()
					+ "&dcbl="
					+ set_money_text.getText().toString()
					// + et_province.getText().toString()
					+ "&iswifi="
					+ num
					// + et_city.getText().toString()
					+ "&rjxf="
					+ rjxf_edt.getText().toString()
					// + et_area.getText().toString()
					+ "&isparking="
					+ numm
					+ "&starttime="
					+ start_time_text.getText().toString()
					+ "&closetime="
					+ end_time_text.getText().toString()
					+ "&introduction="
					+ URLEncoder.encode(detail_introduction.getText()
							.toString(), "UTF-8");
			Log.i("res", mDataList.get(0).get("groupid").toString()
					+ "=========res========");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpClient httpclient = new DefaultHttpClient();
		Log.i("res", res + "=========res========");
		HttpPost httpPost = new HttpPost(res);
		MultipartEntity mulentity = new MultipartEntity(
				HttpMultipartMode.BROWSER_COMPATIBLE);

		// ����ͼƬ��������
		if (!(path[0].equals(""))) {
			FileBody filebody = new FileBody(new File(path[0]));
			mulentity.addPart("foodimg1", filebody);
		}
		if (!(path[1].equals(""))) {
			FileBody filebody2 = new FileBody(new File(path[1]));
			mulentity.addPart("foodimg2", filebody2);
		}
		if (!(path[2].equals(""))) {
			FileBody filebody3 = new FileBody(new File(path[2]));
			mulentity.addPart("foodimg3", filebody3);
		}
		if (!(path[3].equals(""))) {
			FileBody filebody4 = new FileBody(new File(path[3]));
			mulentity.addPart("foodimg4", filebody4);
		}
		// mulentity.addPart("foodtab", new StringBody("123"));
		// mulentity.addPart("state", new StringBody("1"));
		httpPost.setEntity(mulentity);
		HttpResponse response = httpclient.execute(httpPost);
		HttpEntity resEntity = response.getEntity();
		String str = EntityUtils.toString(resEntity, "utf-8");
		Log.i("response", response.getEntity() + "==========�ϴ���Ϣ==========="
				+ str);
		mMap = Constants.getJsonObject(str);
		Log.i("msgggggg", mMap.get(1).get("Message").toString()
				+ "=====================");
		stopProgressDialog();
		handler.sendEmptyMessageDelayed(2, 0);
	}

	@SuppressLint("SdCardPath")
	private void saveFile(Bitmap bitmap, String photo) {
		FileOutputStream b = null;
		File file = new File("/sdcard/savephoto/");
		if (file.exists() && file.isDirectory()) {
			file.delete();
			file.mkdirs();// �����µ��ļ���
		} else {
			file.mkdirs();// �����µ��ļ���
		}
		try {
			String fileName = "/sdcard/savephoto/" + photo;
			b = new FileOutputStream(fileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bitmap.compress(Bitmap.CompressFormat.PNG, 100, b);
	}

	private void startProgressDialog() {
		if (progressDialog == null) {
			progressDialog = CustomProgressDialog.createDialog(this);
			// progressDialog.setMessage("��¼��...");
		}
		progressDialog.show();
	}

	private void stopProgressDialog() {
		if (progressDialog != null) {
			progressDialog.dismiss();
			progressDialog = null;
		}
	}

	@SuppressLint("SdCardPath")
	class RunTask extends AsyncTask<String, Integer, String> {

		@SuppressLint({ "SdCardPath", "ShowToast" })
		@Override
		protected String doInBackground(String... arg0) {
			switch (x) {
			case 1:
				try {

					Bitmap bmp1 = ((BitmapDrawable) iamge1.getDrawable())
							.getBitmap();
					Bitmap bmp2 = ((BitmapDrawable) iamge2.getDrawable())
							.getBitmap();
					Bitmap bmp3 = ((BitmapDrawable) iamge3.getDrawable())
							.getBitmap();
					Bitmap bmp4 = ((BitmapDrawable) image4.getDrawable())
							.getBitmap();
					if (bmp1 != null) {
						saveFile(bmp1, "photo1.png");
						mPath[0] = "/sdcard/savephoto/photo1.png";
					}
					if (bmp2 != null) {
						saveFile(bmp2, "photo2.png");
						mPath[1] = "/sdcard/savephoto/photo2.png";
					}
					if (bmp3 != null) {
						saveFile(bmp3, "photo3.png");
						mPath[2] = "/sdcard/savephoto/photo3.png";
					}
					if (bmp4 != null) {
						saveFile(bmp4, "photo4.png");
						mPath[3] = "/sdcard/savephoto/photo4.png";
					}
					Log.i("path", mPath[0] + "====" + mPath[1] + "==="
							+ mPath[2]);
					if (mPath[0] != null && mPath[1] != null
							&& mPath[2] != null && mPath[3] != null) {
						uploadEvaluation(mPath);
					} else {
						Toast.makeText(getApplicationContext(), "���ϴ�ͼƬ��",
								Toast.LENGTH_SHORT);
					}

					// handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 2:
				try {
					// uploadEvaluation(arg0[0]);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			return null;
		}
	}

	Runnable getmyinfo = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&mtype=" + Constants.mtype;
				String sign = Constants.sortsStr(ss);
				Log.i("sign", "================" + sign);
				String str = Constants.getmyinfo + sign + "&uid="
						+ Constants.Id + "&mtype=" + Constants.mtype;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("json", "++++++++++++++++++++=" + mMap);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mDataList", "================" + mDataList);
				Log.i("===================", mDataList.get(0).get("images2")
						+ "================");
				handler.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};

	Runnable getgroups = new Runnable() {

		@Override
		public void run() {
			try {
				long time = System.currentTimeMillis();
				String ss = "time=" + time;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getgroups + sign + "&time=" + time;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mMap", mMap + "================");
				mGroupList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mGroupList", mGroupList + "================");
				// Constants.groupid = mGroupList.get(0).get("id").toString();
				// handler.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			intent.getExtras().get("username");
			intent.getExtras().get("userpass");
			if (intent.getExtras().get("username") != null
					&& intent.getExtras().get("userpass") != null) {
				start_time_text.setText(intent.getExtras().get("username")
						.toString());
				end_time_text.setText(intent.getExtras().get("userpass")
						.toString());
			} else {

			}
		}
	};

	public void registerBoradcastReceiver() {
		IntentFilter myIntentFilter = new IntentFilter();
		myIntentFilter.addAction(ManageTimeChooseActivity.ACTION_NAME);
		// ע��㲥
		registerReceiver(mBroadcastReceiver, myIntentFilter);
	}

	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		@SuppressLint({ "HandlerLeak", "SdCardPath", "InlinedApi",
				"ClickableViewAccessibility", "InflateParams" })
		public void handleMessage(android.os.Message msg) {
			imageloader = new AsycImageLoader();
			switch (msg.what) {
			case 1:

				if (mDataList.get(0).get("username") != null) {
					merchant_acount.setText(mDataList.get(0).get("username")
							.toString());
				} else {
					merchant_acount.setText("");
				}
				if (mDataList.get(0).get("phone") != null) {
					merchant_phone.setText(mDataList.get(0).get("phone")
							.toString());
				} else {
					merchant_phone.setText("");
				}

				if (mDataList.get(0).get("address") != null) {
					merchant_address.setText(mDataList.get(0).get("address")
							.toString());
				} else {
					merchant_address.setText("");
				}
				if (mDataList.get(0).get("dcbl") != null) {
					if (mDataList.get(0).get("dcbl").toString().equals("0")) {
						set_money_no.setChecked(true);
						set_money_text.setText(mDataList.get(0).get("dcbl")
								.toString());
					} else {
						set_money_have.setChecked(true);
						set_money_text.setText(mDataList.get(0).get("dcbl")
								.toString());
					}
				}
				if (mDataList.get(0).get("iswifi") != null) {
					if (mDataList.get(0).get("iswifi").toString().equals("1")) {
						wifi_have.setChecked(true);
					} else if (mDataList.get(0).get("iswifi").toString()
							.equals("0")) {
						wifi_no.setChecked(true);
					}
				}

				if (mDataList.get(0).get("isparking") != null) {
					if (mDataList.get(0).get("isparking").toString()
							.equals("0")) {
						isparking.setChecked(true);
					} else if (mDataList.get(0).get("isparking").toString()
							.equals("1")) {
						isparking_free.setChecked(true);
					} else if (mDataList.get(0).get("isparking").toString()
							.equals("2")) {
						isparking_money.setChecked(true);
					}
				}

				if (mDataList.get(0).get("groupid") != null) {
					if (mDataList.get(0).get("groupid").toString().equals("1")) {
						food_ca_edt.setText("�в�");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("2")) {
						food_ca_edt.setText("����");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("3")) {
						food_ca_edt.setText("�պ�����");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("4")) {
						food_ca_edt.setText("����");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("5")) {
						food_ca_edt.setText("���");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("6")) {
						food_ca_edt.setText("�ưɿ���");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("7")) {
						food_ca_edt.setText("�������");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("8")) {
						food_ca_edt.setText("С��");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("9")) {
						food_ca_edt.setText("��ϯ");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("10")) {
						food_ca_edt.setText("�決");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("11")) {
						food_ca_edt.setText("�ɹ�");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("12")) {
						food_ca_edt.setText("������");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("13")) {
						food_ca_edt.setText("�տ�");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("14")) {
						food_ca_edt.setText("��ʳ");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("15")) {
						food_ca_edt.setText("����");
					} else if (mDataList.get(0).get("groupid").toString()
							.equals("16")) {
						food_ca_edt.setText("����");
					}
				}

				// food_ca_edt.setText(mDataList.get(0).get("groupid").toString());
				// // �����ͼ
				// Intent intent = getIntent();
				// // ��ȡ����
				// String name = intent.getStringExtra("username");
				// String pass = intent.getStringExtra("userpass");
				if (mDataList.get(0).get("starttime") != null) {
					start_time_text.setText(mDataList.get(0).get("starttime")
							.toString());
				}
				if (mDataList.get(0).get("closetime") != null) {
					end_time_text.setText(mDataList.get(0).get("closetime")
							.toString());
				}
				if (mDataList.get(0).get("rjxf") != null) {
					rjxf_edt.setText(mDataList.get(0).get("rjxf").toString());
				} else {
					rjxf_edt.setText("0");
				}
				if (mDataList.get(0).get("introduction") != null) {
					detail_introduction.setText(mDataList.get(0)
							.get("introduction").toString());
				} else {
					detail_introduction.setText("");
				}

				if (mDataList.get(0).get("logoimage") != null) {
					bitmap = imageloader.showImageAsyn(iamge1, mDataList.get(0)
							.get("logoimage").toString(),
							R.drawable.foods_order_photo);
					iamge1.setImageBitmap(bitmap);
					Log.i("bitmap", bitmap + "======================");
					if (bitmap != null) {
						saveFile(bitmap, "photo1.png");
						mPath[0] = "/sdcard/savephoto/photo1.png";
					}
				} else {
					mPath[0] = "";
				}

				if (mDataList.get(0).get("images1") != null) {
					bitmap = imageloader.showImageAsyn(iamge2, mDataList.get(0)
							.get("images1").toString(),
							R.drawable.foods_order_photo);
					iamge2.setImageBitmap(bitmap);
					if (bitmap != null) {
						saveFile(bitmap, "photo2.png");
						mPath[1] = "/sdcard/savephoto/photo2.png";
					}

				} else {
					mPath[1] = "";
				}
				if (mDataList.get(0).get("images2") != null) {
					bitmap = imageloader.showImageAsyn(iamge3, mDataList.get(0)
							.get("images2").toString(),
							R.drawable.foods_order_photo);
					iamge3.setImageBitmap(bitmap);
					if (bitmap != null) {
						saveFile(bitmap, "photo3.png");
						mPath[2] = "/sdcard/savephoto/photo3.png";
					}

				} else {
					mPath[2] = "";
				}
				if (mDataList.get(0).get("images3") != null) {
					bitmap = imageloader.showImageAsyn(image4, mDataList.get(0)
							.get("images3").toString(),
							R.drawable.foods_order_photo);
					iamge3.setImageBitmap(bitmap);
					if (bitmap != null) {
						saveFile(bitmap, "photo4.png");
						mPath[3] = "/sdcard/savephoto/photo4.png";
					}

				} else {
					mPath[3] = "";
				}
				break;
			case 2:
				LayoutInflater inflater1 = LayoutInflater
						.from(getApplicationContext());
				View view1 = inflater1.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view1.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view1
						.findViewById(R.id.popup_cancel_text);
				popupUpdate = new PopupWindow(view1, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupUpdate.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupUpdate.setFocusable(true);// ��ý���
				popupUpdate.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupUpdate.setAnimationStyle(R.style.AnimBottom);
				popupUpdate.showAtLocation(merchant_address, Gravity.CENTER, 0,
						0);
				popupUpdate.update();// ˢ������
				view1.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupUpdate != null && popupUpdate.isShowing()) {
							popupUpdate.dismiss();
							popupUpdate = null;
						}
						return false;
					}
				});
				if (mMap.get(1).get("Message") != null) {
					mWebView.setText(mMap.get(1).get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						popupUpdate.dismiss();
					}
				});
				break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
