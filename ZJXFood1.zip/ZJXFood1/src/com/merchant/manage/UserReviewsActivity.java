package com.merchant.manage;
/**
 * �û�����
 * 
 * @author chenwei
 * 
 * 
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class UserReviewsActivity extends Activity implements OnClickListener {
	private ListView lv;
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����
	private List<Map<String, Object>> mlistitem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_reviews);
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("�����б�");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.user_reviews_listview);
		mlistitem = getData();
		MyAdapter adapter = new MyAdapter(this);
		lv.setAdapter(adapter);

		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub

			}
		});
	}

	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		for (int i = 0; i < 10; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			// String url = "http://10.167.12.184:8080/examples/image/1.png";
			//
			// Bitmap bitmap = getImageByURL(url);

			map.put("user_reviews_imageview", R.drawable.photo3);
			map.put("user_reviews_text1", "�������");
			map.put("user_reviews_text2", "2015-08-02 12:13:12");
			map.put("user_reviews_text3", "ζ���������´λ���!");
			map.put("user_reviews_button", "�ظ�");
			list.add(map);
		}
		return list;

	}

	public void shouinfo() {
		Toast.makeText(this, "������˻ظ�", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {
		public ImageView user_reviews_imageview;
		public TextView user_reviews_text1;
		public TextView user_reviews_text2;
		public TextView user_reviews_text3;
		public Button user_reviews_button;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;

		public MyAdapter(Context context) {
			this.flater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mlistitem.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.layout_user_reviews_list,
						null);

				hodler.user_reviews_imageview = (ImageView) converView
						.findViewById(R.id.user_reviews_imageview);
				hodler.user_reviews_text1 = (TextView) converView
						.findViewById(R.id.user_reviews_text1);
				hodler.user_reviews_text2 = (TextView) converView
						.findViewById(R.id.user_reviews_text2);
				hodler.user_reviews_text3 = (TextView) converView
						.findViewById(R.id.user_reviews_text3);
				hodler.user_reviews_button = (Button) converView
						.findViewById(R.id.user_reviews_button);

				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			hodler.user_reviews_imageview
					.setBackgroundResource((Integer) mlistitem.get(position)
							.get("user_reviews_imageview"));
			hodler.user_reviews_text1.setText((String) mlistitem.get(position)
					.get("user_reviews_text1"));
			hodler.user_reviews_text2.setText((String) mlistitem.get(position)
					.get("user_reviews_text2"));
			hodler.user_reviews_text3.setText((String) mlistitem.get(position)
					.get("user_reviews_text3"));
			hodler.user_reviews_button.setText((String) mlistitem.get(position)
					.get("user_reviews_button"));
			hodler.user_reviews_button
					.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							shouinfo();
							Intent intent = new Intent();
							intent.setClass(getApplicationContext(),
									ReviewsActivity.class);
							startActivity(intent);
						}
					});
			return converView;
		}

	}
}
