package com.merchant.manage;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SetAmountActivity extends Activity implements OnClickListener {
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����
	private EditText set_amount_edit;
	private Button set_amount_btn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_set_amount);
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("���ý��");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		set_amount_btn = (Button) findViewById(R.id.set_amount_btn);
		set_amount_edit = (EditText) findViewById(R.id.set_amount_edit);
		set_amount_btn.setOnClickListener(this);
		// Intent intent = new Intent();
		// intent.putExtra("s_money", set_amount_edit.getText().toString());
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.set_amount_btn:

			if (set_amount_edit.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "��������Ҫ���õĽ�",
						Toast.LENGTH_SHORT).show();
			} else {
				intent.setClass(getApplicationContext(),
						FaceToFaceActivity.class);
				intent.putExtra("s_money", set_amount_edit.getText().toString());
				startActivity(intent);
				finish();
				Toast.makeText(getApplicationContext(), "���óɹ���",
						Toast.LENGTH_SHORT).show();
			}
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
