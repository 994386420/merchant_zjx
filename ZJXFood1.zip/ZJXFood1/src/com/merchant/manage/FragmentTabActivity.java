package com.merchant.manage;

import com.zjxfood.merchant.activity.R;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.WindowManager.BadTokenException;
import android.widget.CheckedTextView;
import android.widget.TextView;
import android.widget.Toast;

public abstract class FragmentTabActivity extends FragmentActivity implements OnClickListener{
	public boolean isAllowFullScreen;
	public boolean hasMenu;
	private ProgressDialog progressDialog;
	private TextView mBack;
	private TextView mTitleTv;
	public abstract void initTitle();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(isAllowFullScreen){
			setFullScreen(true);
		}else{
			setFullScreen(false);
		}
		setContentLayout();
		dealLogicBeforeInitView();
		initView();
		dealLogicAfterInitView();
		initTitle();
	}
	
	public abstract void setContentLayout();
	public abstract void dealLogicBeforeInitView();
	public abstract void initView();
	public abstract void dealLogicAfterInitView();
	
	public int getScreenWidth() {
		DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenWidth = dm.widthPixels;
        return screenWidth;
	}
	public int getScreenHeight() {
		DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenHeight = dm.heightPixels;
        return screenHeight;
	}
	
	public void setFullScreen(boolean fullScreen) {
		if(fullScreen) {
			requestWindowFeature(Window.FEATURE_NO_TITLE);
	        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		} else {
			requestWindowFeature(Window.FEATURE_NO_TITLE);
		}
		
	}
	public void showToast(String info) {
		Toast.makeText(this,info, Toast.LENGTH_SHORT).show();
	}
	public void showToastLong(String info) {
		Toast.makeText(this,info, Toast.LENGTH_LONG).show();
	}
	public void showToast(int resId){
		Toast.makeText(this,resId, Toast.LENGTH_SHORT).show();
	}
	public void showToastLong(int resId){
		Toast.makeText(this,resId, Toast.LENGTH_LONG).show();
	}
	abstract public void onClickEvent(View view);
	
	
	public void onClick(View v) {
		onClickEvent(v);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	
	public void showProgressDialog(){
		if(progressDialog != null && progressDialog.isShowing()){
			progressDialog.dismiss();
			progressDialog = null;
		}
		progressDialog = new ProgressDialog(FragmentTabActivity.this);
		progressDialog.setMessage("正在加载�?");
		try {
			progressDialog.show();
		}catch (BadTokenException exception) {
			exception.printStackTrace();
		}
	}
	public void showProgressDialog(String msg){
		if(progressDialog != null && progressDialog.isShowing()){
			progressDialog.dismiss();
			progressDialog = null;
		}
		progressDialog = new ProgressDialog(FragmentTabActivity.this);
		progressDialog.setMessage(msg);
		try {
			progressDialog.show();
		}catch (BadTokenException exception) {
			exception.printStackTrace();
		}
	}
	
	public void dismissProgressDialog(){
		if(null != progressDialog && progressDialog.isShowing() == true) {
			progressDialog.dismiss();
			progressDialog = null;
		}
	}
	
//	protected void initBack(){
//		mBack = (TextView) findViewById(R.id.back);
//		mBack.setVisibility(View.VISIBLE);
//		mBack.setOnClickListener(onClickListener);
//	}
	
	protected void initTitleText(String text) {
//		mTitleTv = (TextView) findViewById(R.id.title);
		mTitleTv.setVisibility(View.VISIBLE);
		mTitleTv.setText(text);
	}
	
	OnClickListener onClickListener = new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			if(v == mBack){
				onBackClick();
			}
		}
	};
	
	public  void onBackClick(){
		super.onBackPressed();
	}
	

	public interface OnTabChangeListener{
		void onTabChange(int currentSelected);
	}
	
	private OnTabChangeListener onTabChangeListener;
	public void setOnTabChangeListener(OnTabChangeListener onTabChangeListener) {
		this.onTabChangeListener = onTabChangeListener;
	}
	
}
