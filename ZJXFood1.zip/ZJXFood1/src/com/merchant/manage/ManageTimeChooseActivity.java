package com.merchant.manage;

/**
 * ʱ���趨
 * 
 * @author chenwei
 * 
 * 
 */
import java.text.NumberFormat;
import java.util.Locale;

import com.alipay.apmobilesecuritysdk.a.e;
import com.merchant.util.Utils;
import com.merchant.view.TosAdapterView;
import com.merchant.view.TosGallery;
import com.merchant.view.WheelTextView;
import com.merchant.view.WheelView;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.TextView;

public class ManageTimeChooseActivity extends Activity implements
		OnClickListener {
	private String[] hoursArray = { "00", "01", "02", "03", "04", "05", "06",
			"07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17",
			"18", "19", "20", "21", "22", "23" };
	private String[] minsArray = { "00", "01", "02", "03", "04", "05", "06",
			"07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17",
			"18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28",
			"29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
			"40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50",
			"51", "52", "53", "54", "55", "56", "57", "58", "59" };

	private WheelView mHours = null;// Сʱ
	private WheelView mMins = null;// ����
	private CheckedTextView start_TextView = null;// ��ʼʱ��
	private CheckedTextView end_TextView = null;// ����ʱ��
	private View mDecorView = null;
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����

	private NumberAdapter hourAdapter;

	private NumberAdapter minAdapter;
	private String flag = "1";
	private Button cofirm_time_choose;
	private Button dis_time_choose;
	String start_time_text;
	String end_time_text;
	public static String ACTION_NAME = "XX";
	private TosAdapterView.OnItemSelectedListener mListener = new TosAdapterView.OnItemSelectedListener() {
		@Override
		public void onItemSelected(TosAdapterView<?> parent, View view,
				int position, long id) {
			((WheelTextView) view).setTextSize(20);

			int index = Integer.parseInt(view.getTag().toString());
			int count = parent.getChildCount();
			if (index < count - 1) {
				((WheelTextView) parent.getChildAt(index + 1)).setTextSize(18);
			}
			if (index > 0) {
				((WheelTextView) parent.getChildAt(index - 1)).setTextSize(18);
			}
			if (flag.equals("1")) {
				formatDataStart();
			} else if (flag.equals("2")) {
				formatDataEnd();
			}
		}

		@Override
		public void onNothingSelected(TosAdapterView<?> parent) {

		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.manage_time_set);
		Intent intent = getIntent();
		start_time_text = intent.getStringExtra("start_time_text");
		end_time_text = intent.getStringExtra("end_time_text");
		init();

	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("ʱ���趨");
		start_TextView = (CheckedTextView) findViewById(R.id.start_password_ctext);
		start_TextView.setText(start_time_text);
		end_TextView = (CheckedTextView) findViewById(R.id.end_password_ctext);
		end_TextView.setText(end_time_text);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);

		cofirm_time_choose = (Button) findViewById(R.id.cofirm_time_choose);
		dis_time_choose = (Button) findViewById(R.id.dis_time_choose);
		dis_time_choose.setOnClickListener(this);
		manage_title_back_image.setOnClickListener(this);

		cofirm_time_choose.setOnClickListener(this);
		start_TextView.setOnClickListener(this);
		end_TextView.setOnClickListener(this);
		mHours = (WheelView) findViewById(R.id.wheel1);
		mMins = (WheelView) findViewById(R.id.wheel2);

		mHours.setScrollCycle(true);
		mMins.setScrollCycle(true);

		hourAdapter = new NumberAdapter(hoursArray);
		minAdapter = new NumberAdapter(minsArray);

		mHours.setAdapter(hourAdapter);
		mMins.setAdapter(minAdapter);

		mHours.setSelection(8, true);
		mMins.setSelection(01, true);

		((WheelTextView) mHours.getSelectedView()).setTextSize(20);
		((WheelTextView) mMins.getSelectedView()).setTextSize(20);

		mHours.setOnItemSelectedListener(mListener);
		mMins.setOnItemSelectedListener(mListener);

		mHours.setUnselectedAlpha(0.5f);
		mMins.setUnselectedAlpha(0.5f);

		mDecorView = getWindow().getDecorView();

	}

	@Override
	public void onClick(View v) {
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.start_password_ctext:
			flag = "1";
			start_TextView.setChecked(true);
			end_TextView.setChecked(false);
			choosebackground();
			break;
		case R.id.end_password_ctext:
			flag = "2";
			start_TextView.setChecked(false);
			end_TextView.setChecked(true);
			choosebackground();
			break;
		case R.id.manage_title_back_image:
			finish();
			break;
		// ȷ��
		case R.id.cofirm_time_choose:
			Intent mIntent = new Intent(ACTION_NAME);
			mIntent.putExtra("username", start_TextView.getText().toString());
			mIntent.putExtra("userpass", end_TextView.getText().toString());
			// ���͹㲥
			sendBroadcast(mIntent);
			finish();
			// intent.setClass(ManageTimeChooseActivity.this,
			// DataModificationActivity.class);
			// intent.putExtra("username", start_TextView.getText().toString());
			// intent.putExtra("userpass", end_TextView.getText().toString());
			// startActivity(intent);
			break;
		// ȡ��
		case R.id.dis_time_choose:
			finish();
			break;
		}
	}

	// ʱ��ѡ�񱳾�ͼƬ
	private void choosebackground() {
		if (flag.equals("1")) {
			start_TextView.setBackgroundResource(R.drawable.choose_time_b);
			end_TextView.setBackgroundResource(R.drawable.choose_time_a);
		} else if (flag.equals("2")) {
			start_TextView.setBackgroundResource(R.drawable.choose_time_a);
			end_TextView.setBackgroundResource(R.drawable.choose_time_b);
		}
	}

	private void formatDataStart() {
		int pos1 = mHours.getSelectedItemPosition();
		int pos2 = mMins.getSelectedItemPosition();
		// �õ�һ��NumberFormat��ʵ��
		NumberFormat nf = NumberFormat.getInstance();
		// �����Ƿ�ʹ�÷���
		nf.setGroupingUsed(false);
		// �����������λ��
		nf.setMaximumIntegerDigits(2);
		// ������С����λ��
		nf.setMinimumIntegerDigits(2);
		String t1 = nf.format(pos1);
		String t2 = nf.format(pos2);
		Log.i("tag", " " + t1);
		String text1 = String.format(Locale.CHINA, t1 + ":" + t2);
		start_TextView.setText(text1);
	}

	private void formatDataEnd() {
		int pos1 = mHours.getSelectedItemPosition();
		int pos2 = mMins.getSelectedItemPosition();
		NumberFormat nf = NumberFormat.getInstance();
		nf.setGroupingUsed(false);
		nf.setMaximumIntegerDigits(2);
		nf.setMinimumIntegerDigits(2);
		String t1 = nf.format(pos1);
		String t2 = nf.format(pos2);
		Log.i("tag", " " + pos1);
		String text1 = String.format(Locale.CHINA, t1 + ":" + t2);
		end_TextView.setText(text1);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	private class NumberAdapter extends BaseAdapter {
		int mHeight = 50;
		String[] mData = null;

		public NumberAdapter(String[] data) {
			mHeight = (int) Utils.dipToPx(ManageTimeChooseActivity.this,
					mHeight);
			this.mData = data;
		}

		@Override
		public int getCount() {
			return (null != mData) ? mData.length : 0;
		}

		@Override
		public View getItem(int arg0) {
			return getView(arg0, null, null);
		}

		@Override
		public long getItemId(int arg0) {
			return arg0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			WheelTextView textView = null;

			if (null == convertView) {
				convertView = new WheelTextView(ManageTimeChooseActivity.this);
				convertView.setLayoutParams(new TosGallery.LayoutParams(-1,
						mHeight));
				textView = (WheelTextView) convertView;
				textView.setTextSize(18);
				textView.setGravity(Gravity.CENTER);
			}

			String text = mData[position];
			if (null == textView) {
				textView = (WheelTextView) convertView;
			}

			textView.setText(text);
			return convertView;
		}
	}

}
