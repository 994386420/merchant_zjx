package com.merchant.manage;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.util.EncodingUtils;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

public class XiYiActivity extends Activity implements OnClickListener {
	private Context mContext;
	private TextView xiyi;
	private ImageView manage_title_back_image;// ����
	private TextView text_title;// ����

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layouy_xiyi);
		init();
		try {
			InputStream is = getAssets().open("xieyi.txt");
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			String text = new String(buffer, "GB2312");
			xiyi = (TextView) findViewById(R.id.xiyi);
			xiyi.setText(text);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException();
		}
	}

	private void init() {
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("��ʳ����Ů��ƽ̨�̻�Э��");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

	// // ��ȡЭ���ļ�
	// public String getFromAssets(String fileName) {
	// String result = "";
	// try {
	// InputStream in = mContext.getResources().getAssets().open(fileName);
	// // ��ȡ�ļ����ֽ���
	// int lenght = in.available();
	// // ����byte����
	// byte[] buffer = new byte[lenght];
	// // ���ļ��е����ݶ���byte������
	// in.read(buffer);
	// result = EncodingUtils.getString(buffer, "GBK");
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// return result;
	// }

}
