package com.merchant.manage;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONObject;

import com.alibaba.fastjson.JSONException;
import com.alipay.apmobilesecuritysdk.a.f;
import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.home.ChooseZhiFuActivity;
import com.merchant.json.ReadJson;
import com.merchant.my.MerchantMyActivity;
import com.merchant.pay.PayActivity;
import com.merchant.util.IdCheck;
import com.merchant.util.StringUtil;
import com.merchant.util.VerifyCheck;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 会员激活
 * 
 * @author chenwei
 * 
 * 
 */
public class ActivationMemberActivity extends Activity implements
		OnClickListener {
	private LinearLayout merchant_my_layout_huiyuan;// 我的
	private LinearLayout merchant_manage_layout_huiyuan;// 经营
	private LinearLayout merchant_home_layout_huiyuan;// 首页
	private TextView text_title;// 标题
	private ImageView manage_title_back_image;// 返回
	private Button activation_memmber_btn;
	private EditText phone_number;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	String phone_numbe = null;
	boolean isExit;
	private PopupWindow pop_window; // PopupWindow对象声明
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;
	String phone = null;

	// private LinearLayout

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activation_member);
		ExitApplication.getInstance().addActivity(this);
		ExitApplication.getInstance().addMyActivity(this);
		init();
		// new Thread(getuidforjh).start();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("会员激活");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		activation_memmber_btn = (Button) findViewById(R.id.activation_memmber_btn);
		phone_number = (EditText) findViewById(R.id.phone_number_edit);
		merchant_my_layout_huiyuan = (LinearLayout) findViewById(R.id.merchant_my_layout_huiyuan);
		merchant_manage_layout_huiyuan = (LinearLayout) findViewById(R.id.merchant_manage_layout_huiyuan);
		merchant_home_layout_huiyuan = (LinearLayout) findViewById(R.id.merchant_home_layout_huiyuan);
		merchant_manage_layout_huiyuan.setVisibility(View.GONE);
		manage_title_back_image.setVisibility(View.GONE);
		activation_memmber_btn.setOnClickListener(this);
		if (Constants.mtype.equals("2")) {
			merchant_my_layout_huiyuan.setOnClickListener(this);
			merchant_home_layout_huiyuan.setOnClickListener(this);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		// case R.id.manage_title_back_image:
		// finish();
		// break;
		case R.id.merchant_my_layout_huiyuan:
			intent.setClass(getApplicationContext(), MerchantMyActivity.class);
			startActivity(intent);
			break;
		case R.id.merchant_home_layout_huiyuan:
			ExitApplication.getInstance().finishMy();
			break;
		case R.id.activation_memmber_btn:
			if (validateMessage()) {
				new Thread(getuidforjh).start();
			}
			break;
		}
	}

	private Boolean validateMessage() {
		phone = phone_number.getText().toString();
		// 检测手机号码
		if (VerifyCheck.isMobilePhoneVerify(phone)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_phone_number), 0).show();
			return false;
		}
		return true;
	}

	Runnable getuidforjh = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "username=" + phone_number.getText().toString();
				String sign = Constants.sortsStr(ss);
				// Log.i("sign", "================" + sign);
				String str = Constants.getuidforjh + sign + "&username="
						+ phone_number.getText().toString();
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				// mDataList = Constants.getJsonObject(mMap.get(0).get("Data")
				// .toString());
				Log.i("mDataList", "================" + mUserMapLists);
				mDataList = getJsonLists(mUserMapLists.get("Data").toString());
				handler1.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (mUserMapLists.get("Code").equals("201")) {
				handler1.sendEmptyMessageDelayed(2, 0);
			}
		}
	};
	Handler handler1 = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				Intent intent = new Intent();
				intent.setClass(getApplicationContext(),
						ChooseZhiFuActivity.class);
				intent.putExtra("money", mDataList.get(0).get("money")
						.toString());
				intent.putExtra("username", mDataList.get(0).get("uid")
						.toString());
				startActivity(intent);
				break;
			case 2:

				LayoutInflater inflater1 = LayoutInflater
						.from(getApplicationContext());
				View view1 = inflater1.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view1.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view1
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view1, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// 设置背景透明
				popupW.setFocusable(true);// 获得焦点
				popupW.setOutsideTouchable(true);// 设置点击窗口外，popupWindow消失
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(merchant_my_layout_huiyuan,
						Gravity.CENTER, 0, 0);
				popupW.update();// 刷新内容
				view1.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						popupW.dismiss();
					}
				});
				// Toast.makeText(getApplicationContext(),
				// mMap.get(1).get("Message").toString(), 0).show();
				break;
			// Toast.makeText(getApplicationContext(),
			// mUserMapLists.get("Message").toString(), 0).show();
			// break;
			}
		};
	};

	public ArrayList<HashMap<String, Object>> getJsonLists(String json)
			throws JSONException, org.json.JSONException {
		JSONObject jsonObject = new JSONObject(json);
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("money", jsonObject.getString("money"));
		map.put("uid", jsonObject.getString("uid"));
		list.add(map);
		return list;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "再按一次退出程序",
					Toast.LENGTH_SHORT).show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};
}
