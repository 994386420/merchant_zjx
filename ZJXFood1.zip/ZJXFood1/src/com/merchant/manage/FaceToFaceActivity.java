package com.merchant.manage;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Hashtable;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.merchant.constant.Constants;
import com.merchant.util.DensityUtils;
import com.zjxfood.merchant.activity.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

@SuppressLint("SdCardPath")
public class FaceToFaceActivity extends Activity implements OnClickListener {
	private TextView text_title;// 标题
	private Button face_set_amount_btn;// 设置金额
	private ImageView manage_title_back_image;// 返回
	String s_money = null;
	private TextView smoney;
	private ImageView erw;
	private Bitmap mBitmap;
	private String mFileName;
	private String path = "";
	String text = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_face_to_face);
		init();
	}

	@SuppressLint("SdCardPath")
	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("当面收款");
		face_set_amount_btn = (Button) findViewById(R.id.face_set_amount_btn);
		face_set_amount_btn.setOnClickListener(this);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		erw = (ImageView) findViewById(R.id.ERW);
		smoney = (TextView) findViewById(R.id.s_money);
		Intent intent = getIntent();
		s_money = intent.getStringExtra("s_money");
		if (intent.getStringExtra("s_money") != null) {
			smoney.setText("¥" + s_money);
			text = Constants.Id + "," + s_money;
		} else {
			smoney.setText("¥" + 22.5);
			text = Constants.Id;
		}
		final int QR_WIDTH = DensityUtils.dp2px(getApplicationContext(), 200);
		final int QR_HEIGHT = DensityUtils.dp2px(getApplicationContext(), 200);
		try {
			QRCodeWriter writer = new QRCodeWriter();
			// 二维码内容 商家id或id+支付金额

			if (text == null || "".equals(text) || text.length() < 1) {
				return;
			}
			// 把输入的文本转为二维码
			BitMatrix martix = writer.encode(text, BarcodeFormat.QR_CODE,
					QR_WIDTH, QR_HEIGHT);

			System.out.println("w:" + martix.getWidth() + "h:"
					+ martix.getHeight() + "二维码文本是" + text);

			Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
			hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
			BitMatrix bitMatrix = new QRCodeWriter().encode(text,
					BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT, hints);
			int[] pixels = new int[QR_WIDTH * QR_HEIGHT];
			for (int y = 0; y < QR_HEIGHT; y++) {
				for (int x = 0; x < QR_WIDTH; x++) {
					if (bitMatrix.get(x, y)) {
						pixels[y * QR_WIDTH + x] = 0xff000000;
					} else {
						pixels[y * QR_WIDTH + x] = 0xffffffff;
					}
				}
			}
			mBitmap = Bitmap.createBitmap(QR_WIDTH, QR_HEIGHT,
					Bitmap.Config.ARGB_8888);

			mBitmap.setPixels(pixels, 0, QR_WIDTH, 0, 0, QR_WIDTH, QR_HEIGHT);
			// 显示二维码
			erw.setImageBitmap(mBitmap);

			File dir = new File("/mnt/sdcard/zjx/qrImage/");
			if (!dir.exists()) {
				dir.mkdirs();
			}
			File bitmapFile = new File("/mnt/sdcard/zjx/qrImage/my_qr_code.png");
			if (!bitmapFile.exists()) {
				try {
					bitmapFile.createNewFile();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			FileOutputStream fos;
			// 把二维码生成的图片保存到本地 路径自己定义
			try {
				fos = new FileOutputStream(bitmapFile);
				mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
				path = "/mnt/sdcard/ZjxProject/qrImage/my_code.png";
				fos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (WriterException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.face_set_amount_btn:
			intent.setClass(getApplicationContext(), SetAmountActivity.class);
			startActivity(intent);
			finish();
			break;
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // 按下的如果是BACK，同时没有重复
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
