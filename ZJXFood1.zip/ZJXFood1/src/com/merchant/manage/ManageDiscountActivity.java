package com.merchant.manage;

import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONObject;
import com.alibaba.fastjson.JSONException;
import com.merchant.adapter.ListViewAdapter;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.merchant.util.DensityUtils;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

/**
 * Ӷ������
 * 
 * @author chenwei
 * 
 * 
 */
@SuppressLint({ "InflateParams", "HandlerLeak" })
public class ManageDiscountActivity extends Activity implements OnClickListener {
	private TextView text_title;// ����
	private ImageButton reduce_image_btn;
	private ImageButton add_image_btn;
	private TextView discount_edt;// ����Ӷ�����
	private int num = 15;
	private ImageView manage_title_back_image;// ����
	private TextView now_discount_text;// ��ǰӶ�����
	private TextView normal_percent;// �������
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> getyjbllistDataList;
	private Button discount_save;
	private FrameLayout discount_frame_layout;
	private ArrayList<String> list_money;
	private PopupWindow pop_window_money; // PopupWindow��������
	// ��ǰѡ�е��б���λ��
	int clickPsition = -1;
	private TextView btn_cancel;
	private PopupWindow popupW = null;
	private TextView mWebView;
	private PopupWindow popupUpdate = null;

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_manage_discount);
		init();
		new Thread(getyjbl).start();
		new Thread(getyjbllist).start();
	}

	private void init() {
		list_money = getListMoney();
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("Ӷ������");
		// reduce_image_btn = (ImageButton) findViewById(R.id.reduce_image_btn);
		// add_image_btn = (ImageButton) findViewById(R.id.add_image_btn);
		discount_edt = (TextView) findViewById(R.id.discount_text);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		now_discount_text = (TextView) findViewById(R.id.now_discount_text);
		normal_percent = (TextView) findViewById(R.id.normal_percent);
		discount_save = (Button) findViewById(R.id.discount_save);
		discount_frame_layout = (FrameLayout) findViewById(R.id.discount_frame_layout);
		// reduce_image_btn.setTag("+");
		// add_image_btn.setTag("-");
		// reduce_image_btn.setOnClickListener(this);
		// add_image_btn.setOnClickListener(this);
		discount_edt.setOnClickListener(this);
		manage_title_back_image.setOnClickListener(this);
		discount_save.setOnClickListener(this);
		discount_frame_layout.setOnClickListener(this);
	}

	@SuppressLint("InflateParams")
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		// String numString = discount_edt.getText().toString();
		Intent intent = new Intent();

		switch (v.getId()) {
		// case R.id.reduce_image_btn:
		// // if (numString == null || numString.equals("")) {
		// // num = 95;
		// // discount_edt.setText("95");
		// // } else {
		// if (v.getTag().equals("-")) {
		// if (++num < 0) // �ȼӣ����ж�
		// {
		// num--;
		//
		// } else {
		// discount_edt.setText(String.valueOf(num) + "%");
		//
		// }
		// } else if (v.getTag().equals("+")) {
		// if (--num < 0) // �ȼ������ж�
		// {
		// num++;
		//
		// } else {
		// discount_edt.setText(String.valueOf(num) + "%");
		//
		// }
		// }
		//
		// break;
		//
		// case R.id.add_image_btn:
		//
		// if (v.getTag().equals("-")) {
		// if (++num < 0) // �ȼӣ����ж�
		// {
		// num--;
		//
		// } else {
		// discount_edt.setText(String.valueOf(num) + "%");
		//
		// }
		// } else if (v.getTag().equals("+")) {
		// if (--num < 0) // �ȼ������ж�
		// {
		// num++;
		// } else {
		// discount_edt.setText(String.valueOf(num) + "%");
		// }
		// }
		// // }
		//
		// break;
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.discount_frame_layout:
			View myViewm = getLayoutInflater().inflate(R.layout.pop, null);
			pop_window_money = new PopupWindow(myViewm, DensityUtils.dp2px(
					getApplicationContext(), 100), 240, true);
			pop_window_money.setBackgroundDrawable(getResources().getDrawable(
					R.color.no));
			pop_window_money.setFocusable(true);
			pop_window_money.showAsDropDown(discount_frame_layout);
			ListView lvm = (ListView) myViewm.findViewById(R.id.lv_pop);
			lvm.setAdapter(new ListViewAdapter(ManageDiscountActivity.this,
					list_money));
			lvm.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,

				int position, long id) {

					discount_edt.setText(list_money.get(position));

					if (clickPsition != position) {

						clickPsition = position;
					}
					if (discount_edt.getText().toString().equals("8")) {
						now_discount_text.setText("40%");
					} else if (discount_edt.getText().toString().equals("10")) {
						now_discount_text.setText("60%");
					} else if (discount_edt.getText().toString().equals("15")) {
						now_discount_text.setText("80%");
					} else if (discount_edt.getText().toString().equals("20")) {
						now_discount_text.setText("100%");
					} else if (discount_edt.getText().toString().equals("25")) {
						now_discount_text.setText("120%");
					} else if (discount_edt.getText().toString().equals("30")) {
						now_discount_text.setText("140%");
					} else if (discount_edt.getText().toString().equals("35")) {
						now_discount_text.setText("150%");
					}
					pop_window_money.dismiss();
				}
			});
			break;
		case R.id.discount_save:
			new Thread(updateyjbl).start();
			break;
		}
	}

	public ArrayList<String> getListMoney() {
		ArrayList<String> list_money = new ArrayList<String>();
		list_money.add("8");
		list_money.add("10");
		list_money.add("15");
		list_money.add("20");
		list_money.add("25");
		list_money.add("30");
		list_money.add("35");
		return list_money;
	}

	Runnable updateyjbl = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&yjbl="
						+ discount_edt.getText().toString();
				String sign = Constants.sortsStr(ss);
				// Log.i("sign", "================" + sign);
				String str = Constants.updateyjbl + sign + "&uid="
						+ Constants.Id + "&yjbl="
						+ discount_edt.getText().toString();
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mUserMapLists", "================" + mUserMapLists);
				mDataList = Constants.getJsonObject(mUserMapLists.get("Data")
						.toString());
				// mDataList = getJsonLists(mMap.get(0).get("Data").toString());
				// Log.i("mDataList", "================" + mDataList);
				Log.i("mDataList",
						"================"
								+ mUserMapLists.get("Message").toString());
				// handler1.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler1.sendEmptyMessageDelayed(3, 0);
		}
	};

	Runnable getyjbl = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getyjbl + sign + "&uid=" + Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = getJsonLists(mUserMapLists.get("Data").toString());
				handler1.sendEmptyMessageDelayed(2, 0);
				Log.i("mDataList", "================" + mDataList);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	};
	Runnable getyjbllist = new Runnable() {

		@Override
		public void run() {
			try {
				// long time = System.currentTimeMillis();
				// String ss = "time=" + time;
				// String sign = Constants.sortsStr(ss);
				String str = Constants.getyjbllist;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				getyjbllistDataList = Constants.getJsonObject(mUserMapLists
						.get("Data").toString());
				Log.i("getyjbllistDataList", "================"
						+ mUserMapLists.get("Data").toString());
				Log.i("getyjbllistDataList", "================"
						+ getyjbllistDataList.get(0).get("35").toString());
				handler1.sendEmptyMessageDelayed(4, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler1 = new Handler() {
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@SuppressLint({ "InlinedApi", "ClickableViewAccessibility" })
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:

				break;
			case 2:
				discount_edt.setText(mDataList.get(0).get("yjbl").toString());
				normal_percent.setText(mDataList.get(0).get("normal")
						.toString()
						+ "%");
				// discount_edt.setText(mDataList.get(0).get("yjbl").toString()
				// + "%");
				if (mDataList.get(0).get("yjbl").toString().equals("8")) {
					now_discount_text.setText("40%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("10")) {
					now_discount_text.setText("60%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("15")) {
					now_discount_text.setText("80%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("20")) {
					now_discount_text.setText("100%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("25")) {
					now_discount_text.setText("120%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("30")) {
					now_discount_text.setText("140%");
				} else if (mDataList.get(0).get("yjbl").toString().equals("35")) {
					now_discount_text.setText("150%");
				}
				break;
			case 3:
				LayoutInflater inflater1 = LayoutInflater
						.from(getApplicationContext());
				View view1 = inflater1.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view1.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view1
						.findViewById(R.id.popup_cancel_text);
				popupUpdate = new PopupWindow(view1, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupUpdate.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupUpdate.setFocusable(true);// ��ý���
				popupUpdate.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupUpdate.setAnimationStyle(R.style.AnimBottom);
				popupUpdate.showAtLocation(text_title, Gravity.CENTER, 0, 0);
				popupUpdate.update();// ˢ������
				view1.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupUpdate != null && popupUpdate.isShowing()) {
							popupUpdate.dismiss();
							popupUpdate = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						popupUpdate.dismiss();
					}
				});
				break;
			case 4:
				break;
			}
		};
	};

	public ArrayList<HashMap<String, Object>> getJsonLists(String json)
			throws JSONException, org.json.JSONException {
		JSONObject jsonObject = new JSONObject(json);
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("yjbl", jsonObject.getString("yjbl"));
		map.put("normal", jsonObject.getString("normal"));
		list.add(map);
		return list;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
