package com.merchant.manage;

import com.merchant.fragment.FragmentAllOrders;
import com.merchant.view.SlidingView;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;

public class ManageFoodsOrder extends FragmentTabActivity {
	private Fragment fragments[] = new Fragment[2];
	private FragmentManager fragmentManager;
	private FragmentTransaction fragmentTransaction;
	private CheckedTextView tab_all, tab_collect;
	private SlidingView mSlidingView;
	private CheckedTextView mCurrentCheckedTv = null;
	private int mTagWidth;
	private TextView text_title;// ����
	@Override
	public void initTitle() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setContentLayout() {
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_foods_order);
	}

	@Override
	public void dealLogicBeforeInitView() {
		// TODO Auto-generated method stub
		fragmentManager = this.getSupportFragmentManager();
		fragments[0] = fragmentManager.findFragmentById(R.id.fragement_all_orders);
		fragments[1] = fragmentManager.findFragmentById(R.id.fragement_no_cl_orders);
	}

	@Override
	public void initView() {
		// TODO Auto-generated method stub
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("Ԥ������");
		// ������tag��ǩ ��ʼ�������ü���
		tab_all = (CheckedTextView) findViewById(R.id.tab_all);
		tab_all.setOnClickListener(this);
		tab_collect = (CheckedTextView) findViewById(R.id.tab_collect);
		tab_collect.setOnClickListener(this);
		mSlidingView = (SlidingView) findViewById(R.id.slidingView);
		mTagWidth = getScreenWidth() / 2;
	}

	@Override
	public void dealLogicAfterInitView() {
		// TODO Auto-generated method stub
		// �Ե�һ��Fragment ��������
		FragmentAllOrders fragment = (FragmentAllOrders) fragments[0];
		// �������е�Fragment
		fragmentTransaction = fragmentManager.beginTransaction()
				.hide(fragments[0]).hide(fragments[1]);
		// ��ʾ��һ��Fragment
		fragmentTransaction.show(fragments[0]).commit();
		// ���ú����ƶ��ļ���
		setOnTabChangeListener(onTabChangeListener);
	}

	// ���� �ı�tag��ǩ ��ʾ�ƶ����� �͸ı����������
	@Override
	public void onClickEvent(View view) {
		// ����һ����ʱ����View
		mCurrentCheckedTv = (CheckedTextView) view;
		// ��������Fragment
		fragmentTransaction = fragmentManager.beginTransaction()
				.hide(fragments[0]).hide(fragments[1]);
		switch (view.getId()) {
		case R.id.tab_all:
			// ��ʾ��һ��
			fragmentTransaction.show(fragments[0]).commit();
			// ��һ��tagΪѡ��״̬ Ϊ��ʯ ����Ϊfalse Ϊ��ɫ
			tab_all.setChecked(true);
			tab_collect.setChecked(false);

			// ���� ���߻����ķ���
			if (onTabChangeListener != null) {
				onTabChangeListener.onTabChange(0);
			}
			break;

		case R.id.tab_collect:
			fragmentTransaction.show(fragments[1]).commit();
			tab_all.setChecked(false);
			tab_collect.setChecked(true);

			if (onTabChangeListener != null) {
				onTabChangeListener.onTabChange(1);
			}
			break;
		}
	}

	private OnTabChangeListener onTabChangeListener = new OnTabChangeListener() {

		@Override
		public void onTabChange(int currentSelected) {
			moveTagView(currentSelected);
		}
	};

	/**
	 * �ƶ�����
	 * 
	 * @param index
	 */
	private void moveTagView(int index) {
		mSlidingView.smoothScrollTo(-index * mTagWidth, 0);
	}

}
