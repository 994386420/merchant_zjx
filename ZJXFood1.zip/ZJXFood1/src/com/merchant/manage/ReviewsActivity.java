package com.merchant.manage;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

public class ReviewsActivity extends Activity implements OnClickListener {
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_reviews);
		init();
	}
	
	private void init(){
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("�����б�");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

}
