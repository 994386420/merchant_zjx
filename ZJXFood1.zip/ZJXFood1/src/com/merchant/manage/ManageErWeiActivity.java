package com.merchant.manage;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.merchant.constant.Constants;
import com.merchant.util.DensityUtils;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
/**
 * ʳ����Ů�̼Ҷ�ά��
 * 
 * @author chenwei
 * 
 * 
 */
public class ManageErWeiActivity extends Activity implements OnClickListener {
	
	private final static String TAG = "IcsTestActivity";
	private final static String ALBUM_PATH = Environment
			.getExternalStorageDirectory() + "/download/";
	private ImageView mImageView;
	private ImageButton mBtnSave;
	private ProgressDialog mSaveDialog = null;
	private Bitmap mBitmap;
	private String mFileName;
	private String mSaveMessage;
	private ImageView manage_title_back_image;//����
	private String path = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_manage_erwei);
		init();
	}

	private void init() {
		mBtnSave = (ImageButton) findViewById(R.id.erwei_imamge_btn);
		mImageView = (ImageView) findViewById(R.id.erwei_imageview);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		mBtnSave.setOnClickListener(this);
		manage_title_back_image.setOnClickListener(this);
		
		final int QR_WIDTH= DensityUtils.dp2px(getApplicationContext(), 200);
    	final int QR_HEIGHT=DensityUtils.dp2px(getApplicationContext(), 200);
    	 try {
             QRCodeWriter writer = new QRCodeWriter();
             //��ά������ �̼�id��id+֧�����
             String text = Constants.Id;
             if (text == null || "".equals(text) || text.length() < 1) {
                 return;
             }
             // ��������ı�תΪ��ά��
             BitMatrix martix = writer.encode(text, BarcodeFormat.QR_CODE,
                     QR_WIDTH, QR_HEIGHT);

             System.out.println("w:" + martix.getWidth() + "h:"
                     + martix.getHeight()+"��ά���ı���"+text);

             Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
             hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
             BitMatrix bitMatrix = new QRCodeWriter().encode(text,
                     BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT, hints);
             int[] pixels = new int[QR_WIDTH * QR_HEIGHT];
             for (int y = 0; y < QR_HEIGHT; y++) {
                 for (int x = 0; x < QR_WIDTH; x++) {
                     if (bitMatrix.get(x, y)) {
                         pixels[y * QR_WIDTH + x] = 0xff000000;
                     } else {
                         pixels[y * QR_WIDTH + x] = 0xffffffff;
                     }
                 }
             }
             mBitmap = Bitmap.createBitmap(QR_WIDTH, QR_HEIGHT,
                     Bitmap.Config.ARGB_8888);

             mBitmap.setPixels(pixels, 0, QR_WIDTH, 0, 0, QR_WIDTH, QR_HEIGHT);
             //��ʾ��ά��
             mImageView.setImageBitmap(mBitmap);
             
             File dir = new File("/mnt/sdcard/zjx/qrImage/");
 			if (!dir.exists()) {
 				dir.mkdirs();
 			}
 			File bitmapFile = new File("/mnt/sdcard/zjx/qrImage/my_qr_code.png");
 			if (!bitmapFile.exists()) {
 				try {
 					bitmapFile.createNewFile();

 				} catch (Exception e) {
 					e.printStackTrace();
 				}
 			}
 			FileOutputStream fos;
 			//�Ѷ�ά�����ɵ�ͼƬ���浽����  ·���Լ�����
 			try {
 				fos = new FileOutputStream(bitmapFile);
 				mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
 				path = "/mnt/sdcard/ZjxProject/qrImage/my_code.png";
 				fos.close();
 			} catch (Exception e) {
 				e.printStackTrace();
 			}

         } catch (WriterException e) {
             e.printStackTrace();
         }
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.erwei_imamge_btn:
			mSaveDialog = ProgressDialog.show(ManageErWeiActivity.this, "����ͼƬ",
					"ͼƬ���ڱ����У����Ե�...", true);
			new Thread(saveFileRunnable).start();
			break;
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

	/**
	 * �����ļ�
	 * 
	 * @param bm
	 * @param fileName
	 * @throws IOException
	 */
	public void saveFile(Bitmap bm, String fileName) throws IOException {
		File dirFile = new File(ALBUM_PATH);
		if (!dirFile.exists()) {
			dirFile.mkdir();
		}
		File myCaptureFile = new File(ALBUM_PATH + fileName);
		BufferedOutputStream bos = new BufferedOutputStream(
				new FileOutputStream(myCaptureFile));
//		bm.compress(Bitmap.CompressFormat.JPEG, 80, bos);
		bos.flush();
		bos.close();
	}

	private Runnable saveFileRunnable = new Runnable() {
		@Override
		public void run() {
			try {
				saveFile(mBitmap, mFileName);
				mSaveMessage = "ͼƬ����ɹ���";
			} catch (IOException e) {
				mSaveMessage = "ͼƬ����ʧ�ܣ�";
				e.printStackTrace();
			}
			messageHandler.sendMessage(messageHandler.obtainMessage());
		}

	};

	private Handler messageHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			mSaveDialog.dismiss();
			Log.d(TAG, mSaveMessage);
			Toast.makeText(ManageErWeiActivity.this, mSaveMessage,
					Toast.LENGTH_SHORT).show();
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
