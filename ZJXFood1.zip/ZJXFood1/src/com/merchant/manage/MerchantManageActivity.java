package com.merchant.manage;

import java.net.URLEncoder;

import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.home.AgentHomeActivity;
import com.merchant.home.BeautySalouHomeActivity;
import com.merchant.home.MyHomeActivity;
import com.merchant.json.ReadJson;
import com.merchant.my.MerchantMyActivity;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * ʳ����Ů�̼Ұ� ��Ӫ
 * 
 * @author chenwei
 * 
 * 
 */
public class MerchantManageActivity extends Activity implements OnClickListener {

	private LinearLayout merchant_home_layout;// �̼Ұ���ҳ
	private LinearLayout merchant_my_layout;// �ҵ�
	private LinearLayout manage_erwei_layout;// �ҵĶ�ά��
	private LinearLayout manage_discount_layout;// �ۿ�����
	private LinearLayout manage_data_modification;// �����޸�
	private LinearLayout manage_face_to_face;// �����տ�
	private LinearLayout activation_member_home;// �û���Ʒ
	private LinearLayout manage_contact_customer_service;// ��ϵ�ͷ�
	// private LinearLayout manage_foods_order;// Ԥ�����
	private TextView my_title_text;
	boolean isExit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_manage);
		ExitApplication.getInstance().addActivity(this);
		ExitApplication.getInstance().addMyActivity(this);
		init();
	}

	private void init() {
		merchant_home_layout = (LinearLayout) findViewById(R.id.merchant_home_layout1);
		merchant_my_layout = (LinearLayout) findViewById(R.id.merchant_my_layout1);
		manage_erwei_layout = (LinearLayout) findViewById(R.id.manage_erwei_layout);
		manage_discount_layout = (LinearLayout) findViewById(R.id.manage_discount_layout);
		manage_data_modification = (LinearLayout) findViewById(R.id.manage_data_modification);
		manage_face_to_face = (LinearLayout) findViewById(R.id.manage_face_to_face);
		activation_member_home = (LinearLayout) findViewById(R.id.activation_member_home);
		manage_contact_customer_service = (LinearLayout) findViewById(R.id.manage_contact_customer_service);
		// manage_foods_order = (LinearLayout)
		// findViewById(R.id.manage_foods_order);
		my_title_text = (TextView) findViewById(R.id.my_title_text);
		my_title_text.setText(Constants.merchantname);
		merchant_my_layout.setOnClickListener(this);
		manage_erwei_layout.setOnClickListener(this);
		merchant_home_layout.setOnClickListener(this);
		manage_discount_layout.setOnClickListener(this);
		manage_data_modification.setOnClickListener(this);
		manage_face_to_face.setOnClickListener(this);
		activation_member_home.setOnClickListener(this);
		manage_contact_customer_service.setOnClickListener(this);
		// manage_foods_order.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.merchant_home_layout1:
			new Thread(Run).start();
			break;
		case R.id.merchant_my_layout1:
			intent.setClass(getApplicationContext(), MerchantMyActivity.class);
			startActivity(intent);
			finish();
			break;
		case R.id.manage_erwei_layout:
			intent.setClass(getApplicationContext(), ManageErWeiActivity.class);
			startActivity(intent);
			break;
		case R.id.manage_discount_layout:
			intent.setClass(getApplicationContext(),
					ManageDiscountActivity.class);
			startActivity(intent);
			break;
		case R.id.manage_data_modification:
			intent.setClass(getApplicationContext(),
					DataModificationActivity.class);
			startActivity(intent);
			break;
		case R.id.manage_face_to_face:
			intent.setClass(getApplicationContext(), SetAmountActivity.class);
			startActivity(intent);
			break;
		// �����Ա
		case R.id.activation_member_home:
			Toast.makeText(getApplicationContext(), "�������������У������ڴ���",
					Toast.LENGTH_SHORT).show();
			break;
		case R.id.manage_contact_customer_service:
			intent.setAction("android.intent.action.CALL");

			intent.setData(Uri.parse("tel:" + "400-012-0012"));

			startActivity(intent);
			break;
		// case R.id.manage_foods_order:
		// intent.setClass(getApplicationContext(), ManageFoodsOrder.class);
		// startActivity(intent);
		// break;
		default:
			break;
		}
	}

	Runnable Run = new Runnable() {

		@Override
		public void run() {
			try {
				if (Constants.mtype.equals("1")) {
					handler.sendEmptyMessageDelayed(1, 1);
				} else if (Constants.mtype.toString().equals("2")) {
					handler.sendEmptyMessageDelayed(2, 1);
				} else if (Constants.mtype.toString().equals("3")) {
					handler.sendEmptyMessageDelayed(3, 1);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",
					Toast.LENGTH_SHORT).show();
			// ����handler�ӳٷ��͸���״̬��Ϣ
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				// ������
				ExitApplication.getInstance().finishMy();
				break;
			case 2:
				// ����Ժ
				ExitApplication.getInstance().finishMy();
				break;
			case 3:
				// ������
				ExitApplication.getInstance().finishMy();
				break;
			}
		};
	};
}
