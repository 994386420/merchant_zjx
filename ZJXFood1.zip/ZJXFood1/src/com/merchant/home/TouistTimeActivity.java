package com.merchant.home;

import com.merchant.util.DateTimePickDialogUtil;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * ʱ��ѡ�����
 * 
 * @author chenwei
 * 
 */
public class TouistTimeActivity extends Activity implements OnClickListener {

	private EditText startDateTime;
	private EditText endDateTime;

	private String initStartDateTime = "2015��8��25�� ";
	private String initEndDateTime = "2015��8��25�� ";
	private TextView tousist_list;// �ο��б�
	private ImageView touist_time_back_image;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// �����ޱ���
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tourist_time);
		init();
	}

	private void init() {
		startDateTime = (EditText) findViewById(R.id.time_edit1);
		endDateTime = (EditText) findViewById(R.id.time_edit2);
		tousist_list = (TextView) findViewById(R.id.tourist_time_list);
		startDateTime.setText(initStartDateTime);
		endDateTime.setText(initEndDateTime);
		tousist_list.setOnClickListener(this);
		
		touist_time_back_image = (ImageView) findViewById(R.id.touist_time_back_image);
		touist_time_back_image.setOnClickListener(this);

		startDateTime.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

				DateTimePickDialogUtil dateTimePicKDialog = new DateTimePickDialogUtil(
						TouistTimeActivity.this, initEndDateTime);
				dateTimePicKDialog.dateTimePicKDialog(startDateTime);

			}
		});

		endDateTime.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				DateTimePickDialogUtil dateTimePicKDialog = new DateTimePickDialogUtil(
						TouistTimeActivity.this, initEndDateTime);
				dateTimePicKDialog.dateTimePicKDialog(endDateTime);
			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.tourist_time_list:
			finish();
			break;
		case R.id.touist_time_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
