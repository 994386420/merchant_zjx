package com.merchant.home;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

/**
 * �޸����п�
 * 
 * @author chenwei
 * 
 * 
 */
public class ModifyBankCardActivity extends Activity implements OnClickListener {

	private ImageView modify_bankcard_back_image;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private EditText user_name_edt;
	private EditText user_phone_edt;
	private EditText user_kaohao_edt;
	private EditText bank;
	private Button bank_save_submit;
	private PopupWindow pop_window;
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;
	public static String ACTION_NAME = "XX";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_modify_bankcard_number);
		init();
		// new Thread(updatebank).start();
	}

	private void init() {
		modify_bankcard_back_image = (ImageView) findViewById(R.id.modify_bankcard_back_image);
		modify_bankcard_back_image.setOnClickListener(this);
		user_name_edt = (EditText) findViewById(R.id.user_name);
		user_phone_edt = (EditText) findViewById(R.id.user_phone);
		user_kaohao_edt = (EditText) findViewById(R.id.user_kahao);
		bank = (EditText) findViewById(R.id.user_bank);
		bank_save_submit = (Button) findViewById(R.id.bank_save_submit);
		bank_save_submit.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.modify_bankcard_back_image:
			finish();
			break;
		case R.id.bank_save_submit:
			if (user_name_edt.getText().toString().equals("")) {
				Toast.makeText(this, "����������Ԥ������!", 0).show();
			} else if (user_phone_edt.getText().toString().equals("")) {
				Toast.makeText(this, "����������Ԥ���绰!", 0).show();
			} else if (user_kaohao_edt.getText().toString().equals("")) {
				Toast.makeText(this, "���������п���!", 0).show();
			} else if (user_kaohao_edt.getText().toString().equals("")) {
				Toast.makeText(this, "�����뿪������!", 0).show();
			} else {
				new Thread(updatebank).start();
			}
			break;
		}
	}

	Runnable updatebank = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&personname="
						+ user_name_edt.getText().toString() + "&mobile="
						+ user_phone_edt.getText().toString() + "&bank="
						+ bank.getText().toString() + "&cardno="
						+ user_kaohao_edt.getText().toString();
				String sign = Constants.sortsStr(ss);
				String strr = Constants.updatebank
						+ sign
						+ "&uid="
						+ Constants.Id
						+ "&personname="
						+ URLEncoder.encode(user_name_edt.getText().toString(),
								"UTF-8") + "&mobile="
						+ user_phone_edt.getText().toString() + "&bank="
						+ URLEncoder.encode(bank.getText().toString(), "UTF-8")
						+ "&cardno=" + user_kaohao_edt.getText().toString();
				String json = ReadJson.readParse(strr);
				mUserMapLists = Constants.getJson2Object(json);
				// Log.i("mMap", "================" + mMap.get(2).get("Code"));
				Log.i("mMap", "================" + mMap);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mDataList", "================" + mDataList);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler.sendEmptyMessageDelayed(1, 0);
		}
	};
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				LayoutInflater inflater = LayoutInflater
						.from(getApplicationContext());
				View view = inflater.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(user_kaohao_edt, Gravity.CENTER, 0, 0);
				popupW.update();// ˢ������
				view.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						Intent mIntent = new Intent(ACTION_NAME);
						mIntent.putExtra("name", user_name_edt.getText()
								.toString());
						mIntent.putExtra("phone", user_phone_edt.getText()
								.toString());
						mIntent.putExtra("card", user_kaohao_edt.getText()
								.toString());
						sendBroadcast(mIntent);
						finish();
						popupW.dismiss();
					}
				});
				break;
			// Toast.makeText(getApplicationContext(),
			// mUserMapLists.get("Message").toString(), 0).show();
			// break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}
}
