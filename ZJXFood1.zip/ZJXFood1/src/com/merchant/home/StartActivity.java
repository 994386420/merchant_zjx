package com.merchant.home;

import java.util.Timer;
import java.util.TimerTask;

import com.merchant.base.ExitApplication;
import com.merchant.constant.MyApplication;
import com.merchant.log.MyLogActivity;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

//导航界面
public class StartActivity extends Activity {

	private Timer mTimer;
	private SharedPreferences mPreferences;
	private Editor editor;
	private MyApplication MyApplication;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.start_log);
		ExitApplication.getInstance().addActivity(this);
		mPreferences = getSharedPreferences("app_log", Context.MODE_PRIVATE);
		mTimer = new Timer();
		//
		// if (!(isNetworkConnected(getApplicationContext()))
		// && !(isWifiConnected(getApplicationContext()))) {
		// Toast.makeText(getApplicationContext(), "网络不可用，请检查后重试",
		// Toast.LENGTH_SHORT).show();
		// handler.sendEmptyMessageDelayed(2, 1500);
		// } else {
		mTimer.schedule(task, 300);
		// }
	}

	TimerTask task = new TimerTask() {
		@Override
		public void run() {
			handler.sendEmptyMessageDelayed(1, 1000);
		}
	};

	Handler handler = new Handler() {
		Intent intent = new Intent();

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				Log.i("mPreferences", mPreferences.getString("flag", null)
						+ "============mPreferences=======");
				// if (mPreferences != null) {
				// if (mPreferences.getString("flag", null)==null) {
				// Log.i("mPreferences", "============true=======");
				// editor = mPreferences.edit();
				// // 将登录标志位设置为false，下次登录时不在显示首次登录界面
				// editor.putString("flag", "false");
				// editor.commit();
				// intent.setClass(getApplicationContext(),
				// GuideActivity.class);
				// startActivity(intent);
				// } else {
				// Log.i("mPreferences", "============false=======");
				intent.setClass(getApplicationContext(), MyLogActivity.class);
				// Bundle bundle = new Bundle();
				// bundle.putString("can", "1");
				// intent.putExtras(bundle);
				MyApplication = (MyApplication) getApplication();
				MyApplication.setName("1");
				startActivity(intent);
				// overridePendingTransition(R.anim.slide_left,
				// R.anim.slide_right);
				// }
				// }
				finish();
				break;

			case 2:
				ExitApplication.getInstance().exit();
				break;
			}
		};
	};

	// /**
	// * 判断网络是否打开
	// *
	// * @param context
	// * @return
	// */
	// public boolean isNetworkConnected(Context context) {
	// if (context != null) {
	// ConnectivityManager mConnectivityManager = (ConnectivityManager) context
	// .getSystemService(Context.CONNECTIVITY_SERVICE);
	// NetworkInfo mNetworkInfo = mConnectivityManager
	// .getActiveNetworkInfo();
	// if (mNetworkInfo != null) {
	// return mNetworkInfo.isAvailable();
	// }
	// }
	// return false;
	// }
	//
	// /**
	// * 判断wifi是否可用
	// *
	// * @param context
	// * @return
	// */
	// public boolean isWifiConnected(Context context) {
	// if (context != null) {
	// ConnectivityManager mConnectivityManager = (ConnectivityManager) context
	// .getSystemService(Context.CONNECTIVITY_SERVICE);
	// NetworkInfo mWiFiNetworkInfo = mConnectivityManager
	// .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
	// if (mWiFiNetworkInfo != null) {
	// return mWiFiNetworkInfo.isAvailable();
	// }
	// }
	// return false;
	// }
}
