package com.merchant.home;
/**
 * 商户列表
 * 
 * @author chenwei
 * 
 */
import java.util.ArrayList;
import java.util.HashMap;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

public class SalonShangHuDeatilActivity extends Activity implements
		OnClickListener {
	private ListView lv;
	private ProgressBar progressBar_shanghu;
	private ImageView shanghu_accumulation_back_image;// 返回
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> addDataList;
	private TextView shanghu_number_t;
	String shanghu_number = null;
	private MyAdapter adapter;
	private String page = "1";
	private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;
	private TextView touist_accumulation_text;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shanghu);
		Intent intent = getIntent();
		shanghu_number = intent.getStringExtra("shanghu_number");
		init();
		mRunTask = new RunTask();
		mRunTask.execute("");
	}

	private void init() {
		shanghu_accumulation_back_image = (ImageView) findViewById(R.id.touist_accumulation_back_image);
		shanghu_accumulation_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.shanghu_listview);
		progressBar_shanghu = (ProgressBar) findViewById(R.id.progressBar_shanghu);
		shanghu_number_t = (TextView) findViewById(R.id.shanghu_number_t);
		touist_accumulation_text = (TextView) findViewById(R.id.touist_accumulation_text);
		touist_accumulation_text.setText("商户列表");
		shanghu_number_t.setText(shanghu_number);
		lv.setOnScrollListener(mScrollListener);
		progressBar_shanghu.setVisibility(View.VISIBLE);
		lv.setVisibility(View.GONE);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.touist_accumulation_back_image:
			finish();
			break;
		}
	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&page=" + page
							+ "&pagesize=10";
					String sign = Constants.sortsStr(ss);
					String str = Constants.getcydetailformry + sign + "&uid="
							+ Constants.Id + "&page=" + page + "&pagesize=10";
					String json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					Log.i("mUserMapLists", "================" + mUserMapLists);
					mDataList = Constants.getJsonArray(mUserMapLists
							.get("Data").toString());
					Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				String ss = "uid=" + Constants.Id + "&page=" + page
						+ "&pagesize=10";
				String sign = Constants.sortsStr(ss);
				String str = Constants.getcydetailformry + sign + "&uid="
						+ Constants.Id + "&page=" + page + "&pagesize=10";
				String json;

				try {
					json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get(
							"Data").toString());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv.setAdapter(adapter);
				progressBar_shanghu.setVisibility(View.GONE);
				lv.setVisibility(View.VISIBLE);
				break;
			case 2:
				adapter.nofity(addDataList);
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount() - 1) {
				x = 2;
				page = Integer.parseInt(page) + 1 + "";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// 计算最后可见条目的索引
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // 按下的如果是BACK，同时没有重复
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {
		public TextView service_shanghu_time;
		public TextView service_shanghu_text;
		public TextView service_shanghu_phone;
		public TextView service_shanghu_ca;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		public void nofity(ArrayList<HashMap<String, Object>> list) {
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(
						R.layout.layout_shanghu_service_item, null);

				hodler.service_shanghu_time = (TextView) converView
						.findViewById(R.id.service_shanghu_time);
				hodler.service_shanghu_text = (TextView) converView
						.findViewById(R.id.service_shanghu_text);
				hodler.service_shanghu_phone = (TextView) converView
						.findViewById(R.id.service_shanghu_phone);
				hodler.service_shanghu_ca = (TextView) converView
						.findViewById(R.id.service_shanghu_ca);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			hodler.service_shanghu_ca.setVisibility(View.GONE);
			hodler.service_shanghu_time.setText(mList.get(position)
					.get("createtime").toString());
			hodler.service_shanghu_text.setText(mList.get(position)
					.get("merchantname").toString());
			hodler.service_shanghu_phone.setText(mList.get(position)
					.get("username").toString());
			return converView;
		}

	}
}
