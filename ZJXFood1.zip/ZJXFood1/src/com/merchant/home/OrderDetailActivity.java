package com.merchant.home;

import java.util.ArrayList;
import java.util.HashMap;
import com.merchant.constant.Constants;
import com.merchant.home.OrderDetailConsumptionActivity.RunTask;
import com.merchant.home.OrderDetailConsumptionActivity.ViewHolder;
import com.merchant.home.TouistAccumulationActivity.MyAdapter;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

public class OrderDetailActivity extends Activity implements OnClickListener {
	private TextView title_text;// 标题
	// private TextView time;
	private ImageView cumulative_gain_back_image;// 返回
	private TextView order_deteil_text2;// 消费时间
	private TextView order_deteil_text3;// 消费金额
	private TextView order_deteil_text4;// 消费游客
	private TextView order_deteil_text5;// 消费商家
	private TextView order_deteil_text6;// 返时尚币
	private TextView order_deteil_text7;// 营业收入
	private TextView order_deteil_text8;// 收益
	private TextView order_deteil_text1;// 订单�?
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	String str = null;
	private ArrayList<HashMap<String, Object>> addDataList;
	private MyAdapter adapter;
	private String page = "1";
	private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;
	private ListView lv;
	private ProgressBar progressBar_chun_sr_detail;
	private TextView yycshouru_mingxi;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_order_detail);
		Bundle bundle = getIntent().getExtras();
		str = bundle.getString("time");
		init();
		mRunTask = new RunTask();
		mRunTask.execute("");
		// new Thread(getbusinessdetailbydate).start();
	}

	private void init() {
		title_text = (TextView) findViewById(R.id.cumulative_gain_text);
		// time = (TextView) findViewById(R.id.cumulative_time);
		// time.setVisibility(View.GONE);
		title_text.setText("收入详情");
		yycshouru_mingxi = (TextView) findViewById(R.id.yycshouru_mingxi);
		yycshouru_mingxi.setText("收入明细");
		cumulative_gain_back_image = (ImageView) findViewById(R.id.cumulative_gain_back_image);
		cumulative_gain_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.list_detail1);
		lv.setOnScrollListener(mScrollListener);
		progressBar_chun_sr_detail = (ProgressBar) findViewById(R.id.progressBar_chun_sr_detail);
		progressBar_chun_sr_detail.setVisibility(View.VISIBLE);
		lv.setVisibility(View.GONE);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.cumulative_gain_back_image:
			finish();
			break;
		}
	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&isjh=" + false
							+ "&page=" + page + "&pagesize=10" + "&time=" + str;
					String sign = Constants.sortsStr(ss);
					String strr = Constants.getbusinessdetailbydate + sign
							+ "&uid=" + Constants.Id + "&isjh=" + false
							+ "&page=" + page + "&pagesize=10" + "&time=" + str;
					String json = ReadJson.readParse(strr);
					mUserMapLists = Constants.getJson2Object(json);
					mDataList = Constants.getJsonArray(mUserMapLists
							.get("Data").toString());
					Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
						+ page + "&pagesize=10" + "&time=" + str;
				String sign = Constants.sortsStr(ss);
				String strr = Constants.getbusinessdetailbydate + sign
						+ "&uid=" + Constants.Id + "&isjh=" + false + "&page="
						+ page + "&pagesize=10" + "&time=" + str;
				String json;

				try {
					json = ReadJson.readParse(strr);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get(
							"Data").toString());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}

	// Runnable getbusinessdetailbydate = new Runnable() {
	//
	// @Override
	// public void run() {
	// try {
	// String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
	// + 1 + "&pagesize=" + 10 + "&time=" + str;
	// String sign = Constants.sortsStr(ss);
	// String strr = Constants.getbusinessdetailbydate + sign
	// + "&uid=" + Constants.Id + "&isjh=" + false + "&page="
	// + 1 + "&pagesize=" + 10 + "&time=" + str;
	// String json = ReadJson.readParse(strr);
	// mMap = Constants.getJsonObject(json);
	// mDataList = Constants.getJsonArray(mMap.get(0).get("Data")
	// .toString());
	// Log.i("mDataList", "================" + mDataList);
	// handler.sendEmptyMessageDelayed(1, 0);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	// };
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv.setAdapter(adapter);
				progressBar_chun_sr_detail.setVisibility(View.GONE);
				lv.setVisibility(View.VISIBLE);
				break;
			case 2:
				adapter.nofity(addDataList);
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount() - 1) {
				x = 2;
				page = Integer.parseInt(page) + 1 + "";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// 计算最后可见条目的索引
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public class ViewHolder {
		private TextView order_deteil_text2;// 消费时间
		private TextView order_deteil_text3;// 消费金额
		private TextView order_deteil_text4;// 消费游客
		private TextView order_deteil_text5;// 消费商家
		private TextView order_deteil_text6;// 返时尚币
		private TextView order_deteil_text7;// 营业收入
		private TextView order_deteil_text1;// 订单�?
		private TextView order_deteil_text8;// 收益
		private TextView shouyi_or_yjzc;
		private LinearLayout order_deteil_consumption_text8_ll;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		public void nofity(ArrayList<HashMap<String, Object>> list) {
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.layout_detail, null);
				hodler.order_deteil_text1 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text1);
				hodler.order_deteil_text2 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text2);
				hodler.order_deteil_text3 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text3);
				hodler.order_deteil_text4 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text4);
				hodler.order_deteil_text5 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text5);
				hodler.order_deteil_text6 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text6);
				hodler.order_deteil_text7 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text7);
				hodler.order_deteil_text8 = (TextView) converView
						.findViewById(R.id.order_deteil_consumption_text8);
				hodler.order_deteil_consumption_text8_ll = (LinearLayout) converView
						.findViewById(R.id.order_deteil_consumption_text8_ll);
				hodler.shouyi_or_yjzc = (TextView) converView
						.findViewById(R.id.shouyi_or_yjzc);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			Log.i("msg", "++++++++++++++++++++++++++++" + mList);
			if (Constants.mtype.equals("3")) {
				hodler.shouyi_or_yjzc.setText("收       益:");
				hodler.order_deteil_consumption_text8_ll
						.setVisibility(View.GONE);
			} else {
				hodler.shouyi_or_yjzc.setText("佣金支出:");
			}
			if (mList.get(position).get("orderid") != null) {
				hodler.order_deteil_text1.setText(mList.get(position)
						.get("orderid").toString());
			} else {
				hodler.order_deteil_text1.setText("");
			}
			if (mList.get(position).get("createtime") != null) {
				hodler.order_deteil_text2.setText(mList.get(position)
						.get("createtime").toString());
			} else {
				hodler.order_deteil_text2.setText("");
			}
			if (mList.get(position).get("money") != null) {
				hodler.order_deteil_text3.setText("¥"
						+ mList.get(position).get("money").toString());
			} else {
				hodler.order_deteil_text3.setText("");
			}
			if (mList.get(position).get("username") != null) {
				hodler.order_deteil_text4.setText(mList.get(position)
						.get("username").toString());
			} else {
				hodler.order_deteil_text4.setText("");
			}
			if (mList.get(position).get("merchantname") != null) {
				hodler.order_deteil_text5.setText(mList.get(position)
						.get("merchantname").toString());
			} else {
				hodler.order_deteil_text5.setText("");
			}
			if (mList.get(position).get("shmoney") != null) {
				hodler.order_deteil_text6.setText("¥"
						+ mList.get(position).get("shmoney").toString());
			} else {
				hodler.order_deteil_text6.setText("");
			}
			if (mList.get(position).get("realmoney") != null) {
				hodler.order_deteil_text7.setText("¥"
						+ mList.get(position).get("realmoney").toString());
			} else {
				hodler.order_deteil_text7.setText("");
			}
			if (mList.get(position).get("income") != null) {
				hodler.order_deteil_text8.setText("¥"
						+ mList.get(position).get("income").toString());
			} else {
				hodler.order_deteil_text8.setText("");
			}
			return converView;
		}

	}
}
