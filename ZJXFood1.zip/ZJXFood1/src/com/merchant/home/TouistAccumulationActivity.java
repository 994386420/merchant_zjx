package com.merchant.home;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.merchant.constant.Constants;
import com.merchant.dialog.CustomProgressDialog;
import com.merchant.json.ReadJson;
import com.merchant.log.MyLogActivity;
import com.merchant.log.MyLogActivity.MainFrameTask;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

/**
 * �ο�
 * 
 * @author chenwei
 * 
 * 
 */
public class TouistAccumulationActivity extends Activity implements
		OnClickListener {

//	private TextView tourist_time;
	private ListView lv;
	private ProgressBar progressBar_tourist;
	private List<Map<String, Object>> mlistitem;
	private ImageView touist_accumulation_back_image;// ����
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> addDataList;
	private TextView tourist_number_t;
	String touist_number = null;
	// private ArrayAdapter<String> mAdapter;
	// private ArrayList<String> items = new ArrayList<String>();
//	private Handler mHandler;
//	private int start = 0;
//	private static int refreshCnt = 0;
	private MyAdapter adapter;
    private String page = "1";
    private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;
	private MainFrameTask mMainFrameTask = null;
	private CustomProgressDialog progressDialog = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_touist_accumulation);
		Intent intent = getIntent();
		touist_number = intent.getStringExtra("touist_number");
		init();
		// geneItems();
//		mMainFrameTask = new MainFrameTask(this);
//		mMainFrameTask.execute();
		mRunTask = new RunTask();
		mRunTask.execute("");
	}

	private void init() {
//		tourist_time = (TextView) findViewById(R.id.tourist_time);
		touist_accumulation_back_image = (ImageView) findViewById(R.id.touist_accumulation_back_image);
		tourist_number_t = (TextView) findViewById(R.id.tourist_number_t);
		tourist_number_t.setText(touist_number + "��");
//		tourist_time.setOnClickListener(this);
		touist_accumulation_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.touist_listview);
		progressBar_tourist = (ProgressBar) findViewById(R.id.progressBar_tourist);
        lv.setOnScrollListener(mScrollListener);
        progressBar_tourist.setVisibility(View.VISIBLE);
        lv.setVisibility(View.GONE);
		// ((XListView) lv).setPullLoadEnable(true);
//		((XListView) lv).setXListViewListener(this);
//		mHandler = new Handler();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		// ����
//		case R.id.tourist_time:
//			intent.setClass(getApplicationContext(), TouistTimeActivity.class);
//			startActivity(intent);
//			break;
		// ������ҳ
		case R.id.touist_accumulation_back_image:
			finish();
			break;
		}
	}	
	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
							+ page + "&pagesize=10";
					String sign = Constants.sortsStr(ss);
					String str = Constants.getDateNumber + sign + "&uid="
							+ Constants.Id + "&isjh=" + false + "&page=" + page
							+ "&pagesize=10";
					String json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
							.toString());
					// Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
						+ page + "&pagesize=10";
				String sign = Constants.sortsStr(ss);
				String str = Constants.getDateNumber + sign + "&uid="
						+ Constants.Id + "&isjh=" + false + "&page=" + page
						+ "&pagesize=10";
				String json;
				
				try {				
					json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get("Data")
							.toString());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				// mDataList.get(0).get("num").toString();
				// mDataList.get(0).get("time").toString();
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv.setAdapter(adapter);		
			    progressBar_tourist.setVisibility(View.GONE);
		        lv.setVisibility(View.VISIBLE);
				lv.setOnItemClickListener(new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getApplicationContext(),
								TouristDetailActivity.class);
						Bundle bundle = new Bundle();
						bundle.putString("time", mDataList.get(arg2)
								.get("time").toString());
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
				break;
			case 2:
				adapter.nofity(addDataList);
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount()-1) {
				x = 2;
				page = Integer.parseInt(page) + 1+"";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// �������ɼ���Ŀ������
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};
	@Override
	protected void onDestroy() {
		stopProgressDialog();
		if (mMainFrameTask != null && !mMainFrameTask.isCancelled()) {
			mMainFrameTask.cancel(true);
		}
		super.onDestroy();
	}
	private void startProgressDialog() {
		if (progressDialog == null) {
			progressDialog = CustomProgressDialog.createDialog(this);
//			progressDialog.setMessage("������...");
		}
		progressDialog.show();
	}
	private void stopProgressDialog() {
		if (progressDialog != null) {
			progressDialog.dismiss();
			progressDialog = null;
		}
	}

	public class MainFrameTask extends AsyncTask<Integer, String, Integer> {
		private TouistAccumulationActivity log = null;

		public MainFrameTask(TouistAccumulationActivity touistAccumulationActivity) {
			this.log = touistAccumulationActivity;
		}

		@Override
		protected void onCancelled() {
			stopProgressDialog();
			super.onCancelled();
		}

		@Override
		protected Integer doInBackground(Integer... params) {

			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPreExecute() {
			startProgressDialog();
		}

		@Override
		protected void onPostExecute(Integer result) {
			stopProgressDialog();
		}

	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {
		public ImageView ItemImage;
		public TextView ItemText;
		public TextView ItemTitle;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		public void nofity(ArrayList<HashMap<String, Object>> list){
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.listview, null);

				hodler.ItemImage = (ImageView) converView
						.findViewById(R.id.ItemImage);
				hodler.ItemText = (TextView) converView
						.findViewById(R.id.ItemText);
				hodler.ItemTitle = (TextView) converView
						.findViewById(R.id.ItemTitle);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			hodler.ItemImage.setBackgroundResource(R.drawable.zzz);
			hodler.ItemText.setText(mList.get(position).get("num").toString());
			hodler.ItemTitle
					.setText(mList.get(position).get("time").toString());
			return converView;
		}

	}

}
