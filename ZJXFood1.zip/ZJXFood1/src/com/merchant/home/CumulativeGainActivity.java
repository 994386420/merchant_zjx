package com.merchant.home;

import java.util.ArrayList;
import java.util.HashMap;
import com.merchant.constant.Constants;
import com.merchant.home.CumulativeBackMoneyActivity.MyAdapter;
import com.merchant.home.CumulativeBackMoneyActivity.RunTask;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

/**
 * 非营业收入
 * 
 * @author chenwei
 * 
 * 
 */
public class CumulativeGainActivity extends Activity implements OnClickListener {
	private ImageView cumulative_gain_back_image;// 返回
	// private TextView cumulative_time;
	private ListView lv_gain;
	private ProgressBar progressBar_feiyingyesr;
	private TextView cumulative_ggain;
	private TextView cumulative_gain_text;
	private TextView canying_text;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	String ggain = null;
	private ArrayList<HashMap<String, Object>> addDataList;
	private MyAdapter adapter;
	private String page = "1";
	private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;
	private HashMap<String, Object> mUserMapLists;
	private LinearLayout help_ll_gain;
	private PopupWindow popupWindow = null;
	private View popView = null;
	private ImageButton gain_help_selector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cumulative_gain);
		Intent intent = getIntent();
		ggain = intent.getStringExtra("ggain");
		init();
		mRunTask = new RunTask();
		mRunTask.execute("");
		// new Thread(getincomegroupbydate).start();
	}

	private void init() {
		// DecimalFormat df =new DecimalFormat("#.00");
		cumulative_gain_back_image = (ImageView) findViewById(R.id.cumulative_gain_back_image);
		// cumulative_time = (TextView) findViewById(R.id.cumulative_time);
		lv_gain = (ListView) findViewById(R.id.cumulative_gain_listview);
		cumulative_ggain = (TextView) findViewById(R.id.cumulative_ggain);
		cumulative_ggain.setText("¥" + ggain);
		cumulative_gain_back_image.setOnClickListener(this);
		// cumulative_time.setOnClickListener(this);
		// lv_gain.setOnScrollListener(mScrollListener);
		help_ll_gain = (LinearLayout) findViewById(R.id.help_ll_gain);
		cumulative_gain_text = (TextView) findViewById(R.id.cumulative_gain_text);
		canying_text = (TextView) findViewById(R.id.canying_text);
		progressBar_feiyingyesr = (ProgressBar) findViewById(R.id.progressBar_feiyingyesr);
		progressBar_feiyingyesr.setVisibility(View.VISIBLE);
		lv_gain.setVisibility(View.GONE);
		gain_help_selector = (ImageButton) findViewById(R.id.gain_help_selector);
		gain_help_selector.setOnClickListener(this);
		if (Constants.mtype.equals("3")) {
			cumulative_gain_text.setText("非营业收入");
			canying_text.setText("非营业收入");
		} else {
			cumulative_gain_text.setText("用户收益");
			canying_text.setText("用户收益");
		}
		help_ll_gain.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.cumulative_gain_back_image:
			finish();
			break;
		case R.id.gain_help_selector:
			showPopupWindow(v);
			break;
		}
	}

	/**
	 * 显示PopupWindow
	 */
	private void showPopupWindow(View anchor) {
		if (Constants.mtype.equals("3")) {
			popView = LayoutInflater.from(this).inflate(R.layout.pop_help_gain,
					null);
		} else if (Constants.mtype.equals("2")) {
			popView = LayoutInflater.from(this).inflate(
					R.layout.pop_help_back_salon, null);
		} else if (Constants.mtype.equals("1")) {
			popView = LayoutInflater.from(this).inflate(R.layout.pop_help_back,
					null);
		}
		popupWindow = new PopupWindow(popView, LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);
		popupWindow.setBackgroundDrawable(new ColorDrawable(-00000000));// 设置背景透明
		popupWindow.setFocusable(true);// 获得焦点
		popupWindow.setOutsideTouchable(true);// 设置点击窗口外，popupWindow消失
		popupWindow.setAnimationStyle(R.style.AnimBottom);
		popupWindow.showAsDropDown(help_ll_gain);
		popupWindow.showAtLocation(anchor, Gravity.BOTTOM, 0, 0);
		popView.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (popupWindow != null && popupWindow.isShowing()) {
					popupWindow.dismiss();
					popupWindow = null;
				}
				return false;
			}
		});
	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&page=" + page
							+ "&pagesize=10";
					String sign = Constants.sortsStr(ss);
					String str = Constants.getincomegroupbydate + sign
							+ "&uid=" + Constants.Id + "&page=" + page
							+ "&pagesize=10";
					String json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					Log.i("mMap", "================" + mUserMapLists);
					mDataList = Constants.getJsonArray(mUserMapLists
							.get("Data").toString());
					Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				String ss = "uid=" + Constants.Id + "&page=" + page
						+ "&pagesize=10";
				String sign = Constants.sortsStr(ss);
				String str = Constants.getincomegroupbydate + sign + "&uid="
						+ Constants.Id + "&page=" + page + "&pagesize=10";
				String json;

				try {
					json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get(
							"Data").toString());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}

	// Runnable getincomegroupbydate = new Runnable() {
	//
	// @Override
	// public void run() {
	// try {
	// String ss = "uid=" + Constants.Id + "&page=" + 1 + "&pagesize="
	// + 10;
	// String sign = Constants.sortsStr(ss);
	// String str = Constants.getincomegroupbydate + sign + "&uid="
	// + Constants.Id + "&page=" + 1 + "&pagesize=" + 10;
	// String json = ReadJson.readParse(str);
	// mMap = Constants.getJsonObject(json);
	// Log.i("mMap", "================" + mMap);
	// mDataList = Constants.getJsonArray(mMap.get(0).get("Data")
	// .toString());
	// Log.i("mDataList", "================" + mDataList);
	// handler.sendEmptyMessageDelayed(1, 0);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	// };
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				// lv_gain.setAdapter(new MyAdapter(getApplicationContext(),
				// mDataList));
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv_gain.setAdapter(adapter);
				progressBar_feiyingyesr.setVisibility(View.GONE);
				lv_gain.setVisibility(View.VISIBLE);
				lv_gain.setOnScrollListener(mScrollListener);
				lv_gain.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getApplicationContext(),
								OrderDetailGainActivity.class);
						Bundle bundle = new Bundle();
						bundle.putString("time", mDataList.get(arg2)
								.get("time").toString());
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
				break;
			case 2:
				adapter.nofity(addDataList);
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount() - 1) {
				x = 2;
				page = Integer.parseInt(page) + 1 + "";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// 计算最后可见条目的索引
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};

	public final class ViewHolder {
		public ImageView ItemImage;
		public TextView ItemText;
		public TextView ItemTitle;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		public void nofity(ArrayList<HashMap<String, Object>> list) {
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.listview, null);

				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.listview, null);

				hodler.ItemImage = (ImageView) converView
						.findViewById(R.id.ItemImage);
				hodler.ItemText = (TextView) converView
						.findViewById(R.id.ItemText);
				hodler.ItemTitle = (TextView) converView
						.findViewById(R.id.ItemTitle);
				converView.setTag(hodler);

				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			hodler.ItemImage.setBackgroundResource(R.drawable.zzz);
			hodler.ItemText
					.setText(mList.get(position).get("money").toString());
			hodler.ItemTitle
					.setText(mList.get(position).get("time").toString());
			return converView;
		}

	}
}
