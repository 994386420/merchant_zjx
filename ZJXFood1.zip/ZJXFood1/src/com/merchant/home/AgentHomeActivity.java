package com.merchant.home;

import java.net.URLEncoder;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.merchant.manage.MerchantManageActivity;
import com.merchant.my.MerchantMyActivity;
import com.merchant.popupwindow.NoticePopupWindow;
import com.merchant.util.UpdateVersionService;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView.ScaleType;

/**
 * 代理商
 * 
 * @author chenwei
 * 
 * 
 */
public class AgentHomeActivity extends Activity implements OnClickListener {
	private ViewPager viewPager; // android-support-v4中的滑动组件
	private List<ImageView> imageViews; // 滑动的图片集�?
	private int[] imageResId; // 图片ID
	private List<View> dots; // 图片标题正文的那些点
	private int currentItem = 0; // 当前图片的索引号
	private ScheduledExecutorService scheduledExecutorService;
	// private ImageButton merchant_home_takemoney;
	private FrameLayout touist_home;// 游客
	private FrameLayout member_home;// 会员
	private FrameLayout service_agent_frame_layout;
	private FrameLayout shanghu_agent_frame_layout;
	// private FrameLayout cumulative_consumption_home;// 累计消费金额
	private FrameLayout cumulative_back_money;// 累计返现
	private LinearLayout merchant_manage_layout;// 经营
	private LinearLayout merchant_my_layout;// 我的
	private FrameLayout cumulative_gain_home;// 累计收益
	private LinearLayout huiyuan;// 会员
	// private FrameLayout agent_gain_fl;
	// private FrameLayout agent_income_fl;
	private String tourist = "0";// 游客数量
	private TextView touist_number;
	private TextView member_number;
	private TextView cumulative_consumption_income;
	private TextView cumulative_back;
	private TextView my_title_text;
	private ImageButton agent_gain_ibt;
	private ImageButton agent_income_ibt;
	// private TextView agent_home_take_money;
	private TextView agent_can_raise_cash_income;// 可提现营业收入
	private TextView agent_can_carry_cash_proceeds;// 可提现收益金额
	private TextView cumulative_gain;// 累计收益
	private TextView agent_service_number;//
	private TextView agent_shanghu_number;// 商户
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	public ArrayList<HashMap<String, Object>> DataList;
	private ArrayList<HashMap<String, Object>> DDataList;
	private ArrayList<HashMap<String, Object>> CuurrentDataList;
	private ArrayList<HashMap<String, Object>> merchantnumforagentlist;
	private NoticePopupWindow mNoticePopupWindow;
	boolean isExit;
	private UpdateVersionService updateVersionService;
	// 切换当前显示的图�?
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			viewPager.setCurrentItem(currentItem);// 切换当前显示的图�?

		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		ExitApplication.getInstance().addActivity(this);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_agent_home);
		init();
		new Thread(signsRun).start();
		// new Thread(getcymoney).start();
		new Thread(getincome).start();
		new Thread(getcurrentmoney).start();
		new Thread(getnotice).start();
		new Thread(getmerchantnumforagent).start();
		// new Thread(startUpdateRun).start();
		imageResId = new int[] { R.drawable.title_1, R.drawable.title2,
				R.drawable.title3 };
		imageViews = new ArrayList<ImageView>();
		// 初始化图片资�?
		for (int i = 0; i < imageResId.length; i++) {
			ImageView imageView = new ImageView(this);
			imageView.setImageResource(imageResId[i]);
			imageView.setScaleType(ScaleType.CENTER_CROP);
			imageViews.add(imageView);
		}
		dots = new ArrayList<View>();
		dots.add(findViewById(R.id.v_dt0));
		dots.add(findViewById(R.id.v_dt1));
		dots.add(findViewById(R.id.v_dt2));

		viewPager = (ViewPager) findViewById(R.id.vp);
		viewPager.setAdapter(new MyAdapter());// 设置填充ViewPager页面的�?�配�?
		// 设置�?个监听器，当ViewPager中的页面改变时调�?
		viewPager.setOnPageChangeListener(new MyPageChangeListener());

	}

	private void init() {
		// merchant_home_takemoney = (ImageButton)
		// findViewById(R.id.merchant_agent_takemoney_ib);
		merchant_my_layout = (LinearLayout) findViewById(R.id.merchant_my_layout);
		touist_home = (FrameLayout) findViewById(R.id.touist_agent_frame_layout);
		member_home = (FrameLayout) findViewById(R.id.member_agent_frame_layout);
		cumulative_gain_home = (FrameLayout) findViewById(R.id.cumulative_gain_agent_layout);
		// cumulative_consumption_home = (FrameLayout)
		// findViewById(R.id.cumulative_consumption_agent_frame_layout);
		cumulative_back_money = (FrameLayout) findViewById(R.id.cumulative_backmoney_agent_frame_layout);
		merchant_manage_layout = (LinearLayout) findViewById(R.id.merchant_manage_layout);
		touist_number = (TextView) findViewById(R.id.agent_tourist_number);
		member_number = (TextView) findViewById(R.id.agent_member_number);
		// cumulative_consumption_income = (TextView)
		// findViewById(R.id.cumulative_consumption_income);
		cumulative_back = (TextView) findViewById(R.id.cumulative_back_money);
		my_title_text = (TextView) findViewById(R.id.my_title_text);
		my_title_text.setText(Constants.merchantname);
		agent_can_raise_cash_income = (TextView) findViewById(R.id.agent_can_raise_cash_income);
		agent_can_carry_cash_proceeds = (TextView) findViewById(R.id.agent_can_carry_cash_proceeds);
		cumulative_gain = (TextView) findViewById(R.id.cumulative_agent_gain);
		// agent_gain_fl = (FrameLayout) findViewById(R.id.agent_gain_fl);
		// agent_income_fl = (FrameLayout) findViewById(R.id.agent_income_fl);
		huiyuan = (LinearLayout) findViewById(R.id.merchant_huiyuan_layout);
		agent_gain_ibt = (ImageButton) findViewById(R.id.agent_gain_ibt);
		agent_income_ibt = (ImageButton) findViewById(R.id.agent_income_ibt);
		agent_service_number = (TextView) findViewById(R.id.agent_service_number);
		agent_shanghu_number = (TextView) findViewById(R.id.agent_shanghu_number);
		shanghu_agent_frame_layout = (FrameLayout) findViewById(R.id.shanghu_agent_frame_layout);
		service_agent_frame_layout = (FrameLayout) findViewById(R.id.service_agent_frame_layout);
		agent_income_ibt.setOnClickListener(this);
		agent_gain_ibt.setOnClickListener(this);
		merchant_manage_layout.setOnClickListener(this);
		member_home.setOnClickListener(this);
		touist_home.setOnClickListener(this);
		// cumulative_consumption_home.setOnClickListener(this);
		cumulative_back_money.setOnClickListener(this);
		// merchant_home_takemoney.setOnClickListener(this);
		merchant_my_layout.setOnClickListener(this);
		cumulative_gain_home.setOnClickListener(this);
		// agent_gain_fl.setOnClickListener(this);
		// agent_income_fl.setOnClickListener(this);
		shanghu_agent_frame_layout.setOnClickListener(this);
		service_agent_frame_layout.setOnClickListener(this);
		if (Constants.mtype.equals("1")) {
			huiyuan.setVisibility(View.GONE);
			merchant_manage_layout.setVisibility(View.GONE);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.agent_income_ibt:
			intent.setClass(getApplicationContext(),
					BussnessTakeMoneyActivity.class);
			if (CuurrentDataList.get(0).get("money2") != null) {
				intent.putExtra("money2", CuurrentDataList.get(0).get("money2")
						.toString());
			} else {
				intent.putExtra("money2", "0.00");
			}
			startActivity(intent);
			break;

		case R.id.agent_gain_ibt:
			intent.setClass(getApplicationContext(),
					GainTakeMoneyActivity.class);
			if (CuurrentDataList.get(0).get("money3") != null) {
				intent.putExtra("money3", CuurrentDataList.get(0).get("money3")
						.toString());
			} else {
				intent.putExtra("money3", "0.00");
			}
			startActivity(intent);
			break;
		// 游客
		case R.id.touist_agent_frame_layout:
			intent.setClass(getApplicationContext(),
					TouistAccumulationActivity.class);
			if (mDataList.get(0).get("nojhnum") != null) {
				intent.putExtra("touist_number", mDataList.get(0)
						.get("nojhnum").toString());
			} else {
				intent.putExtra("touist_number", "0");
			}

			startActivity(intent);
			break;
		// 会员
		case R.id.member_agent_frame_layout:
			intent.setClass(getApplicationContext(),
					MemberAccumulationActivity.class);
			if (mDataList.get(0).get("jhnum") != null) {
				intent.putExtra("member_number", mDataList.get(0).get("jhnum")
						.toString());
			} else {
				intent.putExtra("member_number", "0");
			}

			startActivity(intent);
			break;
		// 累计收益
		case R.id.cumulative_gain_agent_layout:
			intent.setClass(getApplicationContext(),
					CumulativeGainActivity.class);
			if (DDataList.get(0).get("flmoney") != null) {
				intent.putExtra("ggain", DDataList.get(0).get("flmoney")
						.toString());
			} else {
				intent.putExtra("ggain", "0.00");
			}
			startActivity(intent);
			break;
		// 累计返现
		case R.id.cumulative_backmoney_agent_frame_layout:
			intent.setClass(getApplicationContext(),
					CumulativeBackMoneyActivity.class);
			if (DDataList.get(0).get("jhmoney") != null) {
				intent.putExtra("back_money", DDataList.get(0).get("jhmoney")
						.toString());
			} else {
				intent.putExtra("back_money", "0.00");
			}
			startActivity(intent);
			break;
		case R.id.service_agent_frame_layout:
			intent.setClass(getApplicationContext(),
					ServiceDeatilActivity.class);
			if (merchantnumforagentlist.get(0).get("mrynum") != null) {
				intent.putExtra("service_number", merchantnumforagentlist
						.get(0).get("mrynum").toString());
			} else {
				intent.putExtra("service_number", "0");
			}
			startActivity(intent);
			break;
		case R.id.shanghu_agent_frame_layout:
			intent.setClass(getApplicationContext(),
					ShangHuDeatilActivity.class);
			if (merchantnumforagentlist.get(0).get("cynum") != null) {
				intent.putExtra("shanghu_number", merchantnumforagentlist
						.get(0).get("cynum").toString());
			} else {
				intent.putExtra("shanghu_number", "0");
			}
			startActivity(intent);
			break;
		case R.id.merchant_manage_layout:
			intent.setClass(getApplicationContext(),
					MerchantManageActivity.class);
			startActivity(intent);
			this.finish();
			break;
		case R.id.merchant_my_layout:
			intent.setClass(getApplicationContext(), MerchantMyActivity.class);
			startActivity(intent);
			break;
		}
	}

	// 更新
	Runnable startUpdateRun = new Runnable() {
		@Override
		public void run() {
			Looper.prepare();
			updateVersionService = new UpdateVersionService(Constants.update,
					AgentHomeActivity.this);// 创建更新业务对象
			updateVersionService.checkUpdate();// 调用检查更新的方法,如果可以更新.就更新.不能更新就提示已经是最新的版本了
			Looper.loop();
		}
	};
	// 获取游客和会员数
	Runnable signsRun = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.touist + sign + "&uid=" + Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("json", "================" + mDataList);
				handler1.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	// // 获取累计消费金额
	// Runnable getcymoney = new Runnable() {
	//
	// @Override
	// public void run() {
	// try {
	// String ss = "uid=" + Constants.Id;
	// String sign = Constants.sortsStr(ss);
	// String str = Constants.getcymoney + sign + "&uid="
	// + Constants.Id;
	// String json = ReadJson.readParse(str);
	// mMap = Constants.getJsonObject(json);
	// DataList = Constants.getJsonArray(mMap.get(0).get("Data")
	// .toString());
	//
	// handler1.sendEmptyMessageDelayed(2, 0);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	// };
	// 获取用户累计收益和累计返现
	Runnable getincome = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getincome + sign + "&uid="
						+ Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				DDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				handler1.sendEmptyMessageDelayed(3, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Runnable getnotice = new Runnable() {
		@Override
		public void run() {
			try {
				long time = System.currentTimeMillis();
				String ss = "time=" + time;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getnotice + sign + "&time=" + time;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mUserMapLists", mUserMapLists + "================");
				DataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("getnotice", DataList + "================");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// handler1.sendEmptyMessageDelayed(5, 0);
		}
	};

	// 可提现金额，营业收入，收益
	Runnable getcurrentmoney = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&mtype=" + Constants.mtype;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getcurrentmoney + sign + "&uid="
						+ Constants.Id + "&mtype=" + Constants.mtype;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				CuurrentDataList = Constants.getJsonArray(mUserMapLists.get(
						"Data").toString());
				// Log.i("CuurrentDataList", CuurrentDataList +
				// "================");
				handler1.sendEmptyMessageDelayed(4, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Runnable getmerchantnumforagent = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getmerchantnumforagent + sign + "&uid="
						+ Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				merchantnumforagentlist = Constants.getJsonArray(mUserMapLists
						.get("Data").toString());
				Log.i("merchantnumforagentlist", merchantnumforagentlist.get(0)
						.get("mrynum").toString()
						+ "================");

				handler1.sendEmptyMessageDelayed(6, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler1 = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				// Log.i("json", mDataList.get(0).get("jhnum").toString()
				// + "================" + mDataList);
				if (mDataList.get(0).get("nojhnum") != null) {
					touist_number.setText(mDataList.get(0).get("nojhnum")
							.toString());
				} else {
					touist_number.setText("0");
				}
				if (mDataList.get(0).get("jhnum") != null) {
					member_number.setText(mDataList.get(0).get("jhnum")
							.toString());
				} else {
					member_number.setText("0");
				}
				break;
			case 2:
				// Log.i("msgffffffff", "================" +
				// DataList.get(0).get("money").toString());
				// Log.i("msggggggggg", "================" + DataList);
				// if (DataList.get(0).get("allmoney") != null) {
				// cumulative_consumption_income.setText(DataList.get(0)
				// .get("allmoney").toString());
				// } else {
				// cumulative_consumption_income.setText("0");
				// }
				// mSignNum.setText(signNums + "");
				// new Thread(biRun).start();
				break;
			case 3:
				Log.i("msggggggggg", "================" + DDataList);
				if (DDataList.get(0).get("flmoney") != null) {
					cumulative_gain.setText(DDataList.get(0).get("flmoney")
							.toString());
				} else {
					cumulative_gain.setText("0.00");
				}
				if (DDataList.get(0).get("jhmoney") != null) {
					cumulative_back.setText(DDataList.get(0).get("jhmoney")
							.toString());
				} else {
					cumulative_back.setText("0.00");
				}

				break;
			case 4:
				// if (CuurrentDataList.get(0).get("money1") != null) {
				// agent_home_take_money.setText(CuurrentDataList.get(0)
				// .get("money1").toString());
				// } else {
				// agent_home_take_money.setText("0.00");
				// }
				if (CuurrentDataList.get(0).get("money2") != null) {
					agent_can_raise_cash_income.setText(CuurrentDataList.get(0)
							.get("money2").toString());
				} else {
					agent_can_raise_cash_income.setText("0.00");
				}
				if (CuurrentDataList.get(0).get("money3") != null) {
					agent_can_carry_cash_proceeds.setText(CuurrentDataList
							.get(0).get("money3").toString());
				} else {
					agent_can_carry_cash_proceeds.setText("0.00");
				}
				break;
			case 5:
				mNoticePopupWindow = new NoticePopupWindow(
						AgentHomeActivity.this, DataList);
				mNoticePopupWindow.showAtLocation(member_number,
						Gravity.CENTER, 0, 0);
				break;
			case 6:
				if (merchantnumforagentlist.get(0).get("mrynum") != null) {
					agent_service_number.setText(merchantnumforagentlist.get(0)
							.get("mrynum").toString());
				} else {
					agent_service_number.setText("0");
				}
				if (merchantnumforagentlist.get(0).get("cynum") != null) {
					agent_shanghu_number.setText(merchantnumforagentlist.get(0)
							.get("cynum").toString());
				} else {
					agent_shanghu_number.setText("0");
				}
				break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "再按一次退出程序",
					Toast.LENGTH_SHORT).show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};

	@Override
	protected void onStart() {
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// 当Activity显示出来后，每四秒钟切换�?次图片显�?
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 4,
				TimeUnit.SECONDS);
		super.onStart();
	}

	@Override
	protected void onStop() {
		// 当Activity不可见的时�?�停止切�?
		scheduledExecutorService.shutdown();
		super.onStop();
	}

	/**
	 * 换行切换任务
	 * 
	 * @author chenwei
	 * 
	 */
	private class ScrollTask implements Runnable {

		public void run() {
			synchronized (viewPager) {
				// System.out.println("currentItem: " + currentItem);
				currentItem = (currentItem + 1) % imageViews.size();
				handler.obtainMessage().sendToTarget(); // 通过Handler切换图片
			}
		}

	}

	/**
	 * 当ViewPager中页面的状�?�发生改变时调用
	 * 
	 * @author chenwei
	 * 
	 */
	private class MyPageChangeListener implements OnPageChangeListener {
		private int oldPosition = 0;

		/**
		 * This method will be invoked when a new page becomes selected.
		 * position: Position index of the new selected page.
		 */
		public void onPageSelected(int position) {
			currentItem = position;
			dots.get(oldPosition).setBackgroundResource(R.drawable.dot_normal);
			dots.get(position).setBackgroundResource(R.drawable.dot_focused);
			oldPosition = position;
		}

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}
	}

	/**
	 * 填充ViewPager页面的�?�配�?
	 * 
	 * @author chenwei
	 * 
	 */
	private class MyAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return imageResId.length;
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(imageViews.get(arg1));
			return imageViews.get(arg1);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView((View) arg2);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {

		}
	}

}
