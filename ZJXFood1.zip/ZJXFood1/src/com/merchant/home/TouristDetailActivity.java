package com.merchant.home;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.merchant.constant.Constants;
import com.merchant.home.MemberAccumulationActivity.RunTask;
import com.merchant.home.TouistAccumulationActivity.ViewHolder;
import com.merchant.json.ReadJson;
import com.merchant.manage.UserReviewsActivity.MyAdapter;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;

public class TouristDetailActivity extends Activity implements OnClickListener {
	private TextView title_text;
	// private TextView cumulative_time;
	private ListView lv;
	private ProgressBar progressBar_member_detail;
	private ImageView cumulative_gain_back_image;// ����
	private List<Map<String, Object>> mlistitem;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	ViewHolder hodler = null;
	String str = null;
	private ArrayList<HashMap<String, Object>> addDataList;
	private MyAdapter adapter;
	private String page = "1";
	private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tourist_detail);
		Bundle bundle = getIntent().getExtras();
		str = bundle.getString("time");
		init();
		mRunTask = new RunTask();
		mRunTask.execute("");
		// new Thread(signsRun).start();
	}

	private void init() {
		title_text = (TextView) findViewById(R.id.cumulative_gain_text);
		// cumulative_time = (TextView) findViewById(R.id.cumulative_time);
		title_text.setText("�ο��б�");
		// cumulative_time.setVisibility(View.GONE);
		cumulative_gain_back_image = (ImageView) findViewById(R.id.cumulative_gain_back_image);
		cumulative_gain_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.tourist_detail_listview);
		progressBar_member_detail = (ProgressBar) findViewById(R.id.progressBar_detail);
		progressBar_member_detail.setVisibility(View.VISIBLE);
		lv.setVisibility(View.GONE);

	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&isjh=" + false
							+ "&page=" + page + "&pagesize=10" + "&time=" + str;
					String sign = Constants.sortsStr(ss);
					String strr = Constants.getEveryDayNumber + sign + "&uid="
							+ Constants.Id + "&isjh=" + false + "&page=" + page
							+ "&pagesize=10" + "&time=" + str;
					String json = ReadJson.readParse(strr);
					mUserMapLists = Constants.getJson2Object(json);
					mDataList = Constants.getJsonArray(mUserMapLists
							.get("Data").toString());
					// Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				Log.i("mScrollListener", "++++++mScrollListener2++++++");
				String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
						+ page + "&pagesize=10" + "&time=" + str;
				String sign = Constants.sortsStr(ss);
				String strr = Constants.getEveryDayNumber + sign + "&uid="
						+ Constants.Id + "&isjh=" + false + "&page=" + page
						+ "&pagesize=10" + "&time=" + str;
				String json;

				try {
					json = ReadJson.readParse(strr);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get(
							"Data").toString());
					Log.i("+++++addDataList+++++++", "" + addDataList);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}

	//
	// Runnable signsRun = new Runnable() {
	//
	// @Override
	// public void run() {
	// try {
	// String ss = "uid=" + Constants.Id + "&isjh=" + false + "&page="
	// + 1 + "&pagesize=" + 10 + "&time=" + str;
	// String sign = Constants.sortsStr(ss);
	// String strr = Constants.getEveryDayNumber + sign + "&uid="
	// + Constants.Id + "&isjh=" + false + "&page=" + 1
	// + "&pagesize=" + 10 + "&time=" + str;
	// String json = ReadJson.readParse(strr);
	// mMap = Constants.getJsonObject(json);
	// mDataList = Constants.getJsonArray(mMap.get(0).get("Data")
	// .toString());
	// Log.i("mDataList", "================" + mDataList);
	// handler.sendEmptyMessageDelayed(1, 0);
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	// };
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				mDataList.get(0).get("username").toString();
				mDataList.get(0).get("time").toString();
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv.setAdapter(adapter);
				progressBar_member_detail.setVisibility(View.GONE);
				lv.setVisibility(View.VISIBLE);
				lv.setOnScrollListener(mScrollListener);
				break;
			case 2:
				adapter.nofity(addDataList);
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			// Log.i("msg", lastVisibleIndex + "++++++++++++" +
			// adapter.getCount());
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount() - 1) {
				Log.i("mScrollListener", "++++++mScrollListener1++++++");
				x = 2;
				page = Integer.parseInt(page) + 1 + "";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// �������ɼ���Ŀ������
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.cumulative_gain_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {

		public TextView tourist_detail_text1;
		public TextView tourist_detail_text2;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		public void nofity(ArrayList<HashMap<String, Object>> list) {
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.layout_tourist_detail,
						null);
				hodler.tourist_detail_text1 = (TextView) converView
						.findViewById(R.id.tourist_detail_text1);
				hodler.tourist_detail_text2 = (TextView) converView
						.findViewById(R.id.tourist_detail_text2);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}

			hodler.tourist_detail_text1.setText(mList.get(position)
					.get("username").toString());
			hodler.tourist_detail_text2.setText(mList.get(position).get("time")
					.toString());
			return converView;
		}

	}
}
