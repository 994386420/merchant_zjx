package com.merchant.home;

import com.merchant.pay.PayActivity;
import com.merchant.weixinpay.PayWeixinActivity;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class ChooseZhiFuActivity extends Activity implements OnClickListener {
	String price = null;
	String username = null;
	private FrameLayout zhifubao;
	private FrameLayout weixin;
	private TextView text_title;// 标题
	private ImageView manage_title_back_image;// 返回
	private TextView zh;
	private TextView je;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_choose_zhifu);
		Intent intent = getIntent();
		price = intent.getStringExtra("money");
		username = intent.getStringExtra("username");
		init();
	}

	private void init() {
		zhifubao = (FrameLayout) findViewById(R.id.zhifubao);
		weixin = (FrameLayout) findViewById(R.id.weixinbao);
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("请选择支付方式");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		zh = (TextView) findViewById(R.id.zh);
		je = (TextView) findViewById(R.id.je);
		zh.setText(username);
		je.setText("¥" + price);
		zhifubao.setOnClickListener(this);
		weixin.setOnClickListener(this);
		manage_title_back_image.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.zhifubao:
			intent.setClass(getApplicationContext(), PayActivity.class);
			intent.putExtra("money", price);
			intent.putExtra("username", username);
			startActivity(intent);
			break;
		case R.id.weixinbao:
			intent.setClass(getApplicationContext(), PayWeixinActivity.class);
			intent.putExtra("money", price);
			intent.putExtra("username", username);
			startActivity(intent);
			break;
		}
	}
}
