package com.merchant.home;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class HomeTakeMoneyActivity extends Activity implements OnClickListener {
	private ImageView take_money_back;
	private RelativeLayout main_take_money;
	private ImageButton modify_bank_card;
	private ImageButton set_password_bank_card;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private EditText user_takemoney_edit;
	private EditText user_name_edit;
	private EditText user_phone_edit;
	private EditText user_cardid_edit;
	private EditText user_takemoney_psaaword_edit;
	private Button btn_ttakemoney_submit;
	private TextView home_take_money;
	String money1 = null;
	private LinearLayout forget_password_ll;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_merchant_take_money);
		Intent intent = getIntent();
		money1 = intent.getStringExtra("money1");
		init();
		Log.i("kkkkk", "kkkk" + money1);
		new Thread(getbank).start();
	}

	private void init() {
		main_take_money = (RelativeLayout) findViewById(R.id.main_take_money);
		take_money_back = (ImageView) main_take_money
				.findViewById(R.id.takemoney_back_image);
		modify_bank_card = (ImageButton) findViewById(R.id.modify_bank_card_ib);
		set_password_bank_card = (ImageButton) findViewById(R.id.set_password_bank_card);
		user_takemoney_edit = (EditText) findViewById(R.id.user_takemoney_edit);
		user_name_edit = (EditText) findViewById(R.id.user_name_edt);
		user_phone_edit = (EditText) findViewById(R.id.user_phone_edit);
		user_cardid_edit = (EditText) findViewById(R.id.user_cardid_edit);
		user_takemoney_psaaword_edit = (EditText) findViewById(R.id.user_takemoney_password);
		btn_ttakemoney_submit = (Button) findViewById(R.id.user_takemoney_submit);
		home_take_money = (TextView) findViewById(R.id.take_money);
		home_take_money.setText("¥" + money1);
		forget_password_ll = (LinearLayout) findViewById(R.id.forget_password_ll);
		btn_ttakemoney_submit.setOnClickListener(this);
		modify_bank_card.setOnClickListener(this);
		take_money_back.setOnClickListener(this);
		set_password_bank_card.setOnClickListener(this);
		forget_password_ll.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.takemoney_back_image:
			finish();
			break;
		case R.id.modify_bank_card_ib:
			intent.setClass(getApplicationContext(),
					ModifyBankCardActivity.class);
			startActivity(intent);
			break;
		case R.id.set_password_bank_card:
			intent.setClass(getApplicationContext(), SetPassWordActivity.class);
			startActivity(intent);
			break;
		case R.id.forget_password_ll:
			intent.setClass(getApplicationContext(), SetPassWordActivity.class);
			startActivity(intent);
			break;
		case R.id.user_takemoney_submit:
			// Log.i("msg", "" + mMap.get(2).get("Code").toString());
			if (user_takemoney_edit.getText().toString().equals("")) {
				Toast.makeText(this, "请输入您想提取的金额！", 0).show();
			} else if (user_name_edit.getText().toString().equals("")) {
				Toast.makeText(this, "请输入银行预留姓名！", 0).show();

			} else if (user_phone_edit.getText().toString().equals("")) {
				Toast.makeText(this, "请输入银行预留电话！", 0).show();

			} else if (user_cardid_edit.getText().toString().equals("")) {
				Toast.makeText(this, "请输入银行卡号！", 0).show();

			} else if (user_takemoney_psaaword_edit.getText().toString()
					.equals("")) {
				Toast.makeText(this, "请输入提现密码！", 0).show();
			} else {
				// Toast.makeText(this, "提现密码错误，请仔细核对！", 0).show();
				new Thread(moneyout).start();

			}
			break;
		}
	}

	// 提现
	Runnable moneyout = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid="
						+ Constants.Id
						+ "&money="
						+ user_takemoney_edit.getText().toString()
						+ "&pass="
						+ user_takemoney_psaaword_edit.getText().toString()
						+ "&outtype="
						+ 0
						+ "&personname="
						+ URLEncoder.encode(
								user_name_edit.getText().toString(), "UTF-8")
						+ "&mobile=" + user_phone_edit.getText().toString()
						+ "&bank=" + URLEncoder.encode("中国银行", "UTF-8")
						+ "&cardno=" + user_cardid_edit.getText().toString();
				String sign = Constants.sortsStr(ss);
				String strr = Constants.moneyout
						+ sign
						+ "&uid="
						+ Constants.Id
						+ "&money="
						+ user_takemoney_edit.getText().toString()
						+ "&pass="
						+ user_takemoney_psaaword_edit.getText().toString()
						+ "&outtype="
						+ 0
						+ "&personname="
						+ URLEncoder.encode(
								user_name_edit.getText().toString(), "UTF-8")
						+ "&mobile=" + user_phone_edit.getText().toString()
						+ "&bank=" + URLEncoder.encode("中国银行", "UTF-8")
						+ "&cardno=" + user_cardid_edit.getText().toString();
				String json = ReadJson.readParse(strr);
				Constants.Messagetakemoney = mMap.get(1).get("Message")
						.toString();
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mMap", "================" + mMap);
				// handler.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler.sendEmptyMessageDelayed(3, 0);
		}
	};

	Runnable getbank = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String strr = Constants.getbank + sign + "&uid=" + Constants.Id;
				String json = ReadJson.readParse(strr);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				// Log.i("mDataList", "================" + mDataList);
				handler.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:

				break;
			case 2:
				if (mDataList.get(0).get("personname") != null
						&& mDataList.get(0).get("mobile") != null
						&& mDataList.get(0).get("cardno") != null) {
					user_name_edit.setText(mDataList.get(0).get("personname")
							.toString());
					user_phone_edit.setText(mDataList.get(0).get("mobile")
							.toString());
					user_cardid_edit.setText(mDataList.get(0).get("cardno")
							.toString());
				} else {
					user_name_edit.setText("");
					user_phone_edit.setText("");
					user_cardid_edit.setText("");
				}

				break;
			case 3:
				Toast.makeText(getApplicationContext(),
						Constants.Messagetakemoney, Toast.LENGTH_SHORT).show();
				break;
			}
		};
	};
}
