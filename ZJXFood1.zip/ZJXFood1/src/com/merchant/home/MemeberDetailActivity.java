package com.merchant.home;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MemeberDetailActivity extends Activity implements OnClickListener {
	private TextView title_text;
//	private TextView cumulative_time;
	private ListView lv;
	private ImageView cumulative_gain_back_image;// ����
	private List<Map<String, Object>> mlistitem;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	ViewHolder hodler = null;
	String str = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tourist_detail);
		Bundle bundle = getIntent().getExtras();
		str = bundle.getString("time");
		init();
		new Thread(signsRun).start();
	}
	private void init() {
		title_text = (TextView) findViewById(R.id.cumulative_gain_text);
//		cumulative_time = (TextView) findViewById(R.id.cumulative_time);
		title_text.setText("��Ա�б�");
//		cumulative_time.setVisibility(View.GONE);
		cumulative_gain_back_image = (ImageView) findViewById(R.id.cumulative_gain_back_image);
		cumulative_gain_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.tourist_detail_listview);
	}
	Runnable signsRun = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&isjh=" + true + "&page=" + 1
						+ "&pagesize=" + 10 + "&time=" + str;
				String sign = Constants.sortsStr(ss);
				String strr = Constants.getEveryDayNumber + sign + "&uid="
						+  Constants.Id + "&isjh=" + true + "&page=" + 1
						+ "&pagesize=" + 10 + "&time=" + str;
				String json = ReadJson.readParse(strr);
				mMap = Constants.getJsonObject(json);
				mDataList = Constants.getJsonArray(mMap.get(0).get("Data")
						.toString());
				Log.i("mDataList", "================" + mDataList);
				handler.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				 mDataList.get(0).get("username").toString();
				 mDataList.get(0).get("time").toString();
				 lv.setAdapter(new MyAdapter(getApplicationContext(),
				 mDataList));
				break;
			}
		};
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.cumulative_gain_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {

		public TextView tourist_detail_text1;
		public TextView tourist_detail_text2;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.layout_tourist_detail,
						null);
				hodler.tourist_detail_text1 = (TextView) converView
						.findViewById(R.id.tourist_detail_text1);
				hodler.tourist_detail_text2 = (TextView) converView
						.findViewById(R.id.tourist_detail_text2);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}

			hodler.tourist_detail_text1.setText(mList.get(position).get("username").toString());
			hodler.tourist_detail_text2.setText(mList.get(position).get("time").toString());
			return converView;
		}

	}
}
