package com.merchant.home;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.merchant.manage.ActivationMemberActivity;
import com.merchant.manage.MerchantManageActivity;
import com.merchant.my.MerchantMyActivity;
import com.merchant.popupwindow.NoticePopupWindow;
import com.merchant.util.UpdateVersionService;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView.ScaleType;

/**
 * 美容院
 * 
 * @author chenwei
 * 
 * 
 */
public class BeautySalouHomeActivity extends Activity implements
		OnClickListener {
	private ViewPager viewPager; // android-support-v4中的滑动组件
	private List<ImageView> imageViews; // 滑动的图片集�?
	private int[] imageResId; // 图片ID
	private List<View> dots; // 图片标题正文的那些点
	private int currentItem = 0; // 当前图片的索引号
	private ScheduledExecutorService scheduledExecutorService;
	// private ImageButton merchant_home_takemoney;
	private ImageButton salon_gain_ibt;
	private ImageButton salon_income_ibt;
	private FrameLayout touist_home;// 游客
	private FrameLayout member_home;// 会员
	private FrameLayout cumulative_gain_home;// 累计收益
	private FrameLayout cumulative_salon_back;// 累计返现
	private FrameLayout salon_income_fl;
	private FrameLayout salon_gain_fl;

	private LinearLayout merchant_manage_layout;// 经营
	private LinearLayout merchant_my_layout;// 我的
	private LinearLayout merchant_huiyuan_layout;
	private LinearLayout salon_ll;
	private String tourist = "0";// 游客数量
	private TextView touist_number;
	private TextView member_number;
	private TextView cumulative_salon_back_money;// 累计返现
	private TextView cumulative_gain;// 累计收入
	private TextView my_title_text;
	// private TextView salon_home_take_money;
	private TextView salon_can_raise_cash_income;// 可提现营业收入
	private TextView salon_can_carry_cash_proceeds;// 可提现收益金额
	private TextView salon_shanghu_number;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private HashMap<String, Object> MapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> DataList;
	private ArrayList<HashMap<String, Object>> DDataList;
	private ArrayList<HashMap<String, Object>> CuurrentDataList;
	private ArrayList<HashMap<String, Object>> merchantnumformry;
	boolean isExit;
	private NoticePopupWindow mNoticePopupWindow;
	private UpdateVersionService updateVersionService;
	// 切换当前显示的图�?
	private Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			viewPager.setCurrentItem(currentItem);// 切换当前显示的图�?
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		ExitApplication.getInstance().addActivity(this);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_beauty_salon_home);
		init();
		new Thread(signsRun).start();
		new Thread(getincome).start();
		new Thread(getcurrentmoney).start();
		new Thread(getnotice).start();
		new Thread(getmerchantnumformry).start();
		// new Thread(startUpdateRun).start();
		imageResId = new int[] { R.drawable.title_1, R.drawable.title2,
				R.drawable.title3 };
		imageViews = new ArrayList<ImageView>();
		// 初始化图片资�?
		for (int i = 0; i < imageResId.length; i++) {
			ImageView imageView = new ImageView(this);
			imageView.setImageResource(imageResId[i]);
			imageView.setScaleType(ScaleType.CENTER_CROP);
			imageViews.add(imageView);
		}
		dots = new ArrayList<View>();
		dots.add(findViewById(R.id.v_do0));
		dots.add(findViewById(R.id.v_do1));
		dots.add(findViewById(R.id.v_do2));

		viewPager = (ViewPager) findViewById(R.id.vp);
		viewPager.setAdapter(new MyAdapter());// 设置填充ViewPager页面的适配器
		// 设置监听，当ViewPager中的页面改变时调用
		viewPager.setOnPageChangeListener(new MyPageChangeListener());
	}

	private void init() {
		// merchant_home_takemoney = (ImageButton)
		// findViewById(R.id.salon_home_takemoney_ib);
		merchant_my_layout = (LinearLayout) findViewById(R.id.merchant_my_layout);
		touist_home = (FrameLayout) findViewById(R.id.touist_salon_frame_layout);
		member_home = (FrameLayout) findViewById(R.id.member_salon_frame_layout);
		cumulative_gain_home = (FrameLayout) findViewById(R.id.cumulative_gain_salon_layout);
		cumulative_salon_back = (FrameLayout) findViewById(R.id.cumulative_backmoney_salon_frame_layout);
		merchant_manage_layout = (LinearLayout) findViewById(R.id.merchant_manage_layout);
		touist_number = (TextView) findViewById(R.id.salon_tourist_number);
		member_number = (TextView) findViewById(R.id.salon_member_number);
		cumulative_salon_back_money = (TextView) findViewById(R.id.cumulative_salon_back_money);
		cumulative_gain = (TextView) findViewById(R.id.cumulative_salon_gain);
		my_title_text = (TextView) findViewById(R.id.my_title_text);
		my_title_text.setText(Constants.merchantname);
		// salon_home_take_money = (TextView)
		// findViewById(R.id.salon_home_take_money);
		salon_can_raise_cash_income = (TextView) findViewById(R.id.salon_can_raise_cash_income);
		salon_can_carry_cash_proceeds = (TextView) findViewById(R.id.salon_can_carry_cash_proceeds);
		salon_income_fl = (FrameLayout) findViewById(R.id.salon_income_fl);
		salon_gain_fl = (FrameLayout) findViewById(R.id.salon_gain_fl);
		merchant_huiyuan_layout = (LinearLayout) findViewById(R.id.merchant_huiyuan_layout);
		salon_gain_ibt = (ImageButton) findViewById(R.id.salon_gain_ibt);
		salon_income_ibt = (ImageButton) findViewById(R.id.salon_income_ibt);
		salon_ll = (LinearLayout) findViewById(R.id.salon_ll);
		salon_shanghu_number = (TextView) findViewById(R.id.salon_shanghu_number);
		merchant_manage_layout.setOnClickListener(this);
		member_home.setOnClickListener(this);
		touist_home.setOnClickListener(this);
		cumulative_gain_home.setOnClickListener(this);
		cumulative_salon_back.setOnClickListener(this);
		// merchant_home_takemoney.setOnClickListener(this);
		merchant_my_layout.setOnClickListener(this);
		salon_income_ibt.setOnClickListener(this);
		salon_gain_ibt.setOnClickListener(this);
		merchant_huiyuan_layout.setOnClickListener(this);
		salon_ll.setOnClickListener(this);
		if (Constants.mtype.equals("2")) {
			merchant_manage_layout.setVisibility(View.GONE);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		// 提现
		// case R.id.salon_home_takemoney_ib:
		// intent.setClass(getApplicationContext(),
		// HomeTakeMoneyActivity.class);
		// if (CuurrentDataList.get(0).get("money1") != null) {
		// intent.putExtra("money1", CuurrentDataList.get(0).get("money1")
		// .toString());
		// } else {
		// intent.putExtra("money1", "0.00");
		// }
		// startActivity(intent);
		// break;
		case R.id.salon_income_ibt:
			intent.setClass(getApplicationContext(),
					BussnessTakeMoneyActivity.class);
			if (CuurrentDataList.get(0).get("money2") != null) {
				intent.putExtra("money2", CuurrentDataList.get(0).get("money2")
						.toString());
			} else {
				intent.putExtra("money2", "0.00");
			}
			startActivity(intent);
			break;
		case R.id.salon_gain_ibt:
			intent.setClass(getApplicationContext(),
					GainTakeMoneyActivity.class);
			if (CuurrentDataList.get(0).get("money3") != null) {
				intent.putExtra("money3", CuurrentDataList.get(0).get("money3")
						.toString());
			} else {
				intent.putExtra("money3", "0.00");
			}
			startActivity(intent);
			break;
		// 游客
		case R.id.touist_salon_frame_layout:
			intent.setClass(getApplicationContext(),
					TouistAccumulationActivity.class);
			if (mDataList.get(0).get("nojhnum") != null) {
				intent.putExtra("touist_number", mDataList.get(0)
						.get("nojhnum").toString());
			} else {
				intent.putExtra("touist_number", "0");
			}
			startActivity(intent);
			break;
		// 会员
		case R.id.member_salon_frame_layout:
			intent.setClass(getApplicationContext(),
					MemberAccumulationActivity.class);
			if (mDataList.get(0).get("jhnum") != null) {
				intent.putExtra("member_number", mDataList.get(0).get("jhnum")
						.toString());
			} else {
				intent.putExtra("member_number", "0");
			}

			startActivity(intent);
			break;
		// 累计收益
		case R.id.cumulative_gain_salon_layout:
			intent.setClass(getApplicationContext(),
					CumulativeGainActivity.class);
			if (DDataList.get(0).get("flmoney") != null) {
				intent.putExtra("ggain", DDataList.get(0).get("flmoney")
						.toString());
			} else {
				intent.putExtra("ggain", "0.00");
			}
			startActivity(intent);
			break;
		// 累计返现
		case R.id.cumulative_backmoney_salon_frame_layout:
			intent.setClass(getApplicationContext(),
					CumulativeBackMoneyActivity.class);
			if (DDataList.get(0).get("jhmoney") != null) {
				intent.putExtra("back_money", DDataList.get(0).get("jhmoney")
						.toString());
			} else {
				intent.putExtra("back_money", "0.00");
			}

			startActivity(intent);
			break;
		case R.id.merchant_manage_layout:
			intent.setClass(getApplicationContext(),
					MerchantManageActivity.class);
			startActivity(intent);
			break;
		case R.id.merchant_my_layout:
			intent.setClass(getApplicationContext(), MerchantMyActivity.class);
			startActivity(intent);
			break;
		case R.id.merchant_huiyuan_layout:
			intent.setClass(getApplicationContext(),
					ActivationMemberActivity.class);
			startActivity(intent);
			break;
		// 商户
		case R.id.salon_ll:
			intent.setClass(getApplicationContext(),
					SalonShangHuDeatilActivity.class);
			if (MapLists.get("Data") != null) {
				intent.putExtra("shanghu_number", MapLists.get("Data").toString());
			}else {
				intent.putExtra("shanghu_number", "0");
			}
			startActivity(intent);
			break;
		}
	}

	// 更新
	Runnable startUpdateRun = new Runnable() {
		@Override
		public void run() {
			Looper.prepare();
			updateVersionService = new UpdateVersionService(Constants.update,
					BeautySalouHomeActivity.this);// 创建更新业务对象
			updateVersionService.checkUpdate();// 调用检查更新的方法,如果可以更新.就更新.不能更新就提示已经是最新的版本了
			Looper.loop();
		}
	};
	// 获取游客和会员数
	Runnable signsRun = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.touist + sign + "&uid=" + Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				// Log.i("json", mDataList.get(0).get("jhnum").toString()
				// + "================" + mDataList);
				handler1.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	// 累计收益 返现
	Runnable getincome = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getincome + sign + "&uid="
						+ Constants.Id;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				DDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("msghhhhhhhh", "================" + DDataList);
				handler1.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	// 可提现金额，营业收入，收益
	Runnable getcurrentmoney = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&mtype=" + Constants.mtype;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getcurrentmoney + sign + "&uid="
						+ Constants.Id + "&mtype=" + Constants.mtype;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mMap", mMap + "================");
				CuurrentDataList = Constants.getJsonArray(mUserMapLists.get(
						"Data").toString());
				Log.i("CuurrentDataList", CuurrentDataList + "================");
				handler1.sendEmptyMessageDelayed(3, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Runnable getnotice = new Runnable() {
		@Override
		public void run() {
			try {
				long time = System.currentTimeMillis();
				String ss = "time=" + time;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getnotice + sign + "&time=" + time;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mUserMapLists", mUserMapLists + "================");
				DataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("getnotice", DataList + "================");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// handler1.sendEmptyMessageDelayed(5, 0);
		}
	};

	Runnable getmerchantnumformry = new Runnable() {
		@Override
		public void run() {
			try {
				// long time = System.currentTimeMillis();
				String ss = "uid=" + Constants.Id;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getmerchantnumformry + sign + "&uid="
						+ Constants.Id;
				String json = ReadJson.readParse(str);
				MapLists = Constants.getJson2Object(json);
				Log.i("MapLists", MapLists.get("Data").toString() + "================");
//				merchantnumformry = Constants.getJsonArray(mUserMapLists.get(
//						"Data").toString());
//				Log.i("merchantnumformry", merchantnumformry
//						+ "================");
				handler1.sendEmptyMessageDelayed(6, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// handler1.sendEmptyMessageDelayed(5, 0);
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "再按一次退出程序",
					Toast.LENGTH_SHORT).show();
			// 利用handler延迟发送更改状态信息
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};
	Handler handler1 = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				// Log.i("json", mDataList.get(0).get("jhnum").toString()
				// + "================" + mDataList);
				if (mDataList.get(0).get("nojhnum") != null) {
					touist_number.setText(mDataList.get(0).get("nojhnum")
							.toString());
				} else {
					touist_number.setText("0");
				}
				if (mDataList.get(0).get("jhnum") != null) {
					member_number.setText(mDataList.get(0).get("jhnum")
							.toString());
				} else {
					member_number.setText("0");
				}
				break;
			case 2:
				if (DDataList.get(0).get("flmoney") != null) {
					cumulative_gain.setText(DDataList.get(0).get("flmoney")
							.toString());
				} else {
					cumulative_gain.setText("0.00");
				}
				if (DDataList.get(0).get("jhmoney") != null) {
					cumulative_salon_back_money.setText(DDataList.get(0)
							.get("jhmoney").toString());
				} else {
					cumulative_salon_back_money.setText("0.00");
				}
				break;
			case 3:
				// if (CuurrentDataList.get(0).get("money1") != null) {
				// salon_home_take_money.setText(CuurrentDataList.get(0)
				// .get("money1").toString());
				// } else {
				// salon_home_take_money.setText("0.00");
				// }
				if (CuurrentDataList.get(0).get("money2") != null) {
					salon_can_raise_cash_income.setText(CuurrentDataList.get(0)
							.get("money2").toString());
				} else {
					salon_can_raise_cash_income.setText("0.00");
				}
				if (CuurrentDataList.get(0).get("money3") != null) {
					salon_can_carry_cash_proceeds.setText(CuurrentDataList
							.get(0).get("money3").toString());
				} else {
					salon_can_carry_cash_proceeds.setText("0.00");
				}

				break;
			case 5:
				mNoticePopupWindow = new NoticePopupWindow(
						BeautySalouHomeActivity.this, DataList);
				mNoticePopupWindow.showAtLocation(member_number,
						Gravity.CENTER, 0, 0);
				break;
			case 6:
				salon_shanghu_number.setText(MapLists.get("Data").toString());
				break;
			}
		};
	};

	@Override
	protected void onStart() {
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		// 当Activity显示出来后，每四秒钟切换�?次图片显�?
		scheduledExecutorService.scheduleAtFixedRate(new ScrollTask(), 1, 4,
				TimeUnit.SECONDS);
		super.onStart();
	}

	@Override
	protected void onStop() {
		// 当Activity不可见的时�?�停止切�?
		scheduledExecutorService.shutdown();
		super.onStop();
	}

	/**
	 * 换行切换任务
	 * 
	 * @author chenwei
	 * 
	 */
	private class ScrollTask implements Runnable {

		public void run() {
			synchronized (viewPager) {
				// System.out.println("currentItem: " + currentItem);
				currentItem = (currentItem + 1) % imageViews.size();
				handler.obtainMessage().sendToTarget(); // 通过Handler切换图片
			}
		}

	}

	/**
	 * 当ViewPager中页面的状�?�发生改变时调用
	 * 
	 * @author chenwei
	 * 
	 */
	private class MyPageChangeListener implements OnPageChangeListener {
		private int oldPosition = 0;

		/**
		 * This method will be invoked when a new page becomes selected.
		 * position: Position index of the new selected page.
		 */
		public void onPageSelected(int position) {
			currentItem = position;
			dots.get(oldPosition).setBackgroundResource(R.drawable.dot_normal);
			dots.get(position).setBackgroundResource(R.drawable.dot_focused);
			oldPosition = position;
		}

		public void onPageScrollStateChanged(int arg0) {

		}

		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}
	}

	/**
	 * 填充ViewPager页面的�?�配�?
	 * 
	 * @author chenwei
	 * 
	 */
	private class MyAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			return imageResId.length;
		}

		@Override
		public Object instantiateItem(View arg0, int arg1) {
			((ViewPager) arg0).addView(imageViews.get(arg1));
			return imageViews.get(arg1);
		}

		@Override
		public void destroyItem(View arg0, int arg1, Object arg2) {
			((ViewPager) arg0).removeView((View) arg2);
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {

		}
	}

}
