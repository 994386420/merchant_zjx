package com.merchant.home;

/**
 * ��Ա
 * 
 * @author chenwei
 * 
 * 
 */
import java.util.ArrayList;
import java.util.HashMap;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

public class MemberAccumulationActivity extends Activity implements
		OnClickListener {

	private ImageView memeber_back_image;// ����
	// private TextView member_time;
	private ListView lv;
	private TextView member_number_t;
	private ProgressBar progressBar_member;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	String member_number = null;
	private ArrayList<HashMap<String, Object>> addDataList;
	private MyAdapter adapter;
	private String page = "1";
	private int lastVisibleIndex;
	private int x = 1;
	private RunTask mRunTask;
	private boolean http = true;
//	private MainFrameTask mMainFrameTask = null;
//	// ���ظ���
//	private View mFooterView;
//	private ProgressBar mFooterProgressBar;
//	private TextView mFooterText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_member_accumlation);
		Intent intent = getIntent();
		member_number = intent.getStringExtra("member_number");
		init();
		mRunTask = new RunTask();
		mRunTask.execute("");
		// new Thread(signsRun).start();
	}

	private void init() {
		// member_time = (TextView) findViewById(R.id.member_time);
		memeber_back_image = (ImageView) findViewById(R.id.memeber_back_image);
		member_number_t = (TextView) findViewById(R.id.member_number_t);
		member_number_t.setText(member_number + "��");
		// member_time.setOnClickListener(this);
		memeber_back_image.setOnClickListener(this);
		lv = (ListView) findViewById(R.id.member_listview);
		progressBar_member = (ProgressBar) findViewById(R.id.progressBar_member);
		lv.setOnScrollListener(mScrollListener);
		progressBar_member.setVisibility(View.VISIBLE);
		lv.setVisibility(View.GONE);
		// mFooterView = LayoutInflater.from(getApplicationContext()).inflate(
		// R.layout.footer_auto_load_listview, null);
		// mFooterProgressBar = (ProgressBar) mFooterView
		// .findViewById(R.id.footer_progressbar);
		// mFooterText = (TextView) mFooterView.findViewById(R.id.footer_text);
		//
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.memeber_back_image:
			finish();
			break;
		}
	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... strs) {
			switch (x) {
			case 1:
				try {
					String ss = "uid=" + Constants.Id + "&isjh=" + true
							+ "&page=" + page + "&pagesize=10";
					String sign = Constants.sortsStr(ss);
					String str = Constants.getDateNumber + sign + "&uid="
							+ Constants.Id + "&isjh=" + true + "&page=" + page
							+ "&pagesize=10";
					String json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					mDataList = Constants.getJsonArray(mUserMapLists
							.get("Data").toString());
					// Log.i("mDataList", "================" + mDataList);
					handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 2:
				String ss = "uid=" + Constants.Id + "&isjh=" + true + "&page="
						+ page + "&pagesize=10";
				String sign = Constants.sortsStr(ss);
				String str = Constants.getDateNumber + sign + "&uid="
						+ Constants.Id + "&isjh=" + true + "&page=" + page
						+ "&pagesize=10";
				String json;

				try {
					json = ReadJson.readParse(str);
					mUserMapLists = Constants.getJson2Object(json);
					addDataList = Constants.getJsonArray(mUserMapLists.get(
							"Data").toString());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				handler.sendEmptyMessageDelayed(2, 0);
				break;
			}

			return null;
		}
	}

	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				adapter = new MyAdapter(getApplicationContext(), mDataList);
				lv.setAdapter(adapter);
				// lv.addFooterView(mFooterView);
				progressBar_member.setVisibility(View.GONE);
				lv.setVisibility(View.VISIBLE);
				lv.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(getApplicationContext(),
								MemberDetailActivity.class);
						Bundle bundle = new Bundle();
						bundle.putString("time", mDataList.get(arg2)
								.get("time").toString());
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
				break;
			case 2:
				adapter.nofity(addDataList);
				// mFooterProgressBar.setVisibility(View.GONE);
				// mFooterText.setVisibility(View.VISIBLE);
				// mFooterText.setText("���ݼ�����ȫ�����أ�");
				break;
			}
		};
	};
	OnScrollListener mScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
					&& lastVisibleIndex == adapter.getCount() - 1) {
				x = 2;
				// lv.addFooterView(mFooterView);// ���� ���ظ���
				page = Integer.parseInt(page) + 1 + "";
				mRunTask = new RunTask();
				mRunTask.execute("");
			}
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem,
				int visibleItemCount, int totalItemCount) {
			// �������ɼ���Ŀ������
			lastVisibleIndex = firstVisibleItem + visibleItemCount - 1;
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

	public final class ViewHolder {
		public ImageView ItemImage;
		public TextView ItemText;
		public TextView ItemTitle;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;
		private ArrayList<HashMap<String, Object>> mList;

		public MyAdapter(Context context,
				ArrayList<HashMap<String, Object>> list) {
			this.flater = LayoutInflater.from(context);
			this.mList = list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mList.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		public void nofity(ArrayList<HashMap<String, Object>> list) {
			this.mList.addAll(list);
			notifyDataSetChanged();
		}

		@SuppressLint("InflateParams")
		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.listview, null);

				hodler.ItemImage = (ImageView) converView
						.findViewById(R.id.ItemImage);
				hodler.ItemText = (TextView) converView
						.findViewById(R.id.ItemText);
				hodler.ItemTitle = (TextView) converView
						.findViewById(R.id.ItemTitle);
				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
			hodler.ItemImage.setBackgroundResource(R.drawable.zzz);
			hodler.ItemText.setText(mList.get(position).get("num").toString());
			hodler.ItemTitle
					.setText(mList.get(position).get("time").toString());
			return converView;
		}

	}
}
