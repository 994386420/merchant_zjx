package com.merchant.home;

import java.util.ArrayList;
import java.util.HashMap;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class CumulativeConsumptionDetailActivity extends Activity implements
		OnClickListener {
	private TextView title_text;// 标题
//	private TextView time;
	private ListView lv;
	private ImageView cumulative_gain_back_image;// 返回

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cumulative_consumption_detail);
		init();
	}

	private void init() {
		title_text = (TextView) findViewById(R.id.cumulative_gain_text);
//		time = (TextView) findViewById(R.id.cumulative_time);
//		time.setVisibility(View.GONE);
		title_text.setText("累计消费金额");
		cumulative_gain_back_image = (ImageView) findViewById(R.id.cumulative_gain_back_image);
		cumulative_gain_back_image.setOnClickListener(this);

		lv = (ListView) findViewById(R.id.cumulative_consumption_detail_listview);/* 定义�??个动态数�?? */
		ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String, Object>>();/* 在数组中存放数据 */
		for (int i = 0; i < 10; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("cumulative_consumption_detail_Image1", R.drawable.zzz);// 加入图片
			map.put("cumulative_consumption_detail_Image2",
					R.drawable.cumulative_consumption_photo);// 加入图片
			map.put("cumulative_consumption_detail_Text1", "¥50");
			map.put("cumulative_consumption_detail_Text2", "消费金额");
			listItem.add(map);
		}
		SimpleAdapter mSimpleAdapter = new SimpleAdapter(this, listItem,
				R.layout.cumulative_consumption_listview, new String[] {
						"cumulative_consumption_detail_Image1",
						"cumulative_consumption_detail_Image2",
						"cumulative_consumption_detail_Text1",
						"cumulative_consumption_detail_Text2" }, new int[] {
						R.id.cumulative_consumption_detail_Image1,
						R.id.cumulative_consumption_detail_Image2,
						R.id.cumulative_consumption_detail_Text1,
						R.id.cumulative_consumption_detail_Text2 });
		lv.setAdapter(mSimpleAdapter);// 为ListView绑定适配�??
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Intent intent = new Intent(getApplicationContext(),
						OrderDetailActivity.class);
				startActivity(intent);
				finish();
			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.cumulative_gain_back_image:
			intent.setClass(getApplicationContext(),
					CumulativeConsumptionActivity.class);
			startActivity(intent);
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // 按下的如果是BACK，同时没有重�??
			// do something here
			Intent intent = new Intent(getApplicationContext(),
					CumulativeConsumptionActivity.class);
			startActivity(intent);
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
