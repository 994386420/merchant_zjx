package com.merchant.constant;

import android.app.Application;

public class MyApplication extends Application {

	public String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}