package com.merchant.merchantsettled;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import com.merchant.adapter.MerchantSettledListAdapter;
import com.merchant.adapter.MerchantSettledTypeListAdapter;
import com.merchant.base.BaseActivity;
import com.merchant.constant.Constants;
import com.merchant.dialog.CustomProgressDialog;
import com.merchant.json.ReadJson;
import com.merchant.popupwindow.MerchantSettledPopupWindow;
import com.merchant.popupwindow.MerchantSettledTypePopupWindow;
import com.merchant.util.BitmapUtil;
import com.merchant.util.ImageBean;
import com.merchant.util.PathUtil;
import com.merchant.util.RegExpValidator;
import com.merchant.util.StringUtil;
import com.merchant.util.VerifyCheck;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

/**
 * �̼�������פ
 * 
 * @author chenwei
 * 
 */
@SuppressLint("HandlerLeak")
public class MerChantSettledActivity extends BaseActivity implements
		OnClickListener {
	private ImageView merchant_settled_image;// ����
	/*
	 * ���ͼƬ����
	 */
	private Bitmap bitmap = null;// ͼƬ����
	public static ArrayList<ImageBean> imageList = new ArrayList<ImageBean>();
	private String image_path = null;
	private PopupWindow popupWindow = null;
	private PopupWindow popupW = null;
	private View popView = null;
	private int clickedNum = 0;// �����Ƭ��ť�ı��
	private int CAMER = 10;// ����
	private int ALBUMS = 20;// ��Ƭ
	private Button merchantsettled_submit_btn;// �ύ
	private boolean canSubmit = true;// �ύ�ɵ��
	private ImageButton iamge_business_license_original;
	private ImageButton iamge_business_license_copy;
	// private ImageButton iamge_identity_card_front;
	// private ImageButton iamge_identity_card_negative;
	// private ImageButton iamge_front_lighting;

	private EditText user_name_edit;// �̼����ơ�
	private TextView et_province;// ʡ
	private TextView et_city;// ��
	private TextView et_area;// ����
	private EditText user_adress_edit;// ��ַ
	private TextView user_category_edit;// ���
	private EditText user_phone_edit;// ��ϵ�˵绰
	private EditText user_Legal_personname_edit;// ��������
	private EditText user_legal_id_edit;// ��������֤
	// private EditText user_Business_license_number_edit;// Ӫҵִ�ձ��
	private EditText user_shangji_tuijian_edit;
	/*
	 * �ύ������
	 */
	String merchantName = null;
	String province = null;
	String cityd = null;
	String area = null;
	String phone = null;
	String address = null;
	String category = null;
	String legal_name = null;
	String legal_id = null;
	String license_number = null;
	private String[] mPath = new String[2];
	private int position = 0;
	private int x = 1;
	RunTask mRunTask;
	private AlertDialog mDialog;// �ύ����
	private FrameLayout user_province_frame_layout;
	private FrameLayout user_city_frame_layout;
	private FrameLayout user_area_frame_layout;
	private FrameLayout user_category_frame_layout;
	/*
	 * ���ʡ�ݡ����ء�����
	 */
	// private PopupWindow mPopupWindow;
	// private ListView mListView;
	// private CityListAdapter mListAdapter;
	private String[] mCitys, mAreas;// ������С���������
	// private String[] Array = { "�в�", "����", "�պ�����", "����", "���",
	// "�ưɿ���", "�������",
	// "С��", "��ϯ", "�決", "�ɹ�", "�����", "��ʳ", "����", "����", "�տ�" };
	private HashMap<String, String> mCityMaps, mAreaMaps;// ���С�����map
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private ArrayList<HashMap<String, Object>> mGroupList;
	private MerchantSettledTypeListAdapter mTypeListAdapter;
	private MerchantSettledTypePopupWindow mTypePopupWindow;
	private String mTypeId = "";
	private MerchantSettledPopupWindow mSettledPopupWindow;
	private MerchantSettledListAdapter mSettledListAdapter;
	private String provinceId = "", cityId = "", areaId = "";
	private String provinceName = "", cityName, areaName = "";
	// ��ǰѡ�е��б���λ��
	int clickPsition = -1;
	private PopupWindow pop_window; // PopupWindow��������
	private TextView mWebView;
	private TextView btn_cancel;
	private CustomProgressDialog progressDialog = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_merchant_settled);
		// ��ʼ��xml�ļ�
		initProvinceDatas();
		Init();
		new Thread(getgroups).start();
		// new Thread(runnable).start();
	}

	private void Init() {
		iamge_business_license_original = (ImageButton) this
				.findViewById(R.id.iamge_business_license_original);
		iamge_business_license_copy = (ImageButton) this
				.findViewById(R.id.iamge_business_license_copy);
		// iamge_identity_card_front = (ImageButton) this
		// .findViewById(R.id.iamge_identity_card_front);
		// iamge_identity_card_negative = (ImageButton) this
		// .findViewById(R.id.image_identity_card_negative);
		// iamge_front_lighting = (ImageButton) this
		// .findViewById(R.id.image_front_lighting);
		et_province = (TextView) findViewById(R.id.user_province_edit);
		et_city = (TextView) findViewById(R.id.user_city_edit);
		et_area = (TextView) findViewById(R.id.user_area_edit);
		merchant_settled_image = (ImageView) findViewById(R.id.merchant_settled_image);
		merchantsettled_submit_btn = (Button) findViewById(R.id.merchantsettled_submit_btn);
		user_name_edit = (EditText) findViewById(R.id.user_name_edit);
		user_adress_edit = (EditText) findViewById(R.id.user_adress_edit);
		user_phone_edit = (EditText) findViewById(R.id.user_phone_edit);
		user_Legal_personname_edit = (EditText) findViewById(R.id.user_Legal_personname_edit);
		user_legal_id_edit = (EditText) findViewById(R.id.user_legal_id_edit);
		// user_Business_license_number_edit = (EditText)
		// findViewById(R.id.user_Business_license_number_edit);
		user_province_frame_layout = (FrameLayout) findViewById(R.id.user_province_frame_layout);
		user_city_frame_layout = (FrameLayout) findViewById(R.id.user_city_frame_layout);
		user_area_frame_layout = (FrameLayout) findViewById(R.id.user_area_frame_layout);
		user_category_frame_layout = (FrameLayout) findViewById(R.id.user_category_frame_layout);
		user_category_edit = (TextView) findViewById(R.id.user_category_edit);
		user_shangji_tuijian_edit = (EditText) findViewById(R.id.user_shangji_tuijian_edit);
		merchant_settled_image.setOnClickListener(this);
		iamge_business_license_original.setOnClickListener(this);
		iamge_business_license_copy.setOnClickListener(this);
		// iamge_identity_card_negative.setOnClickListener(this);
		// iamge_identity_card_front.setOnClickListener(this);
		// iamge_front_lighting.setOnClickListener(this);
		merchantsettled_submit_btn.setOnClickListener(this);
		user_province_frame_layout.setOnClickListener(this);
		user_city_frame_layout.setOnClickListener(this);
		user_area_frame_layout.setOnClickListener(this);
		user_category_frame_layout.setOnClickListener(this);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
		View view;
		switch (v.getId()) {

		case R.id.iamge_business_license_original:
			clickedNum = 0;
			showPopupWindow(v);
			break;
		case R.id.iamge_business_license_copy:
			clickedNum = 1;
			showPopupWindow(v);
			break;
		// case R.id.image_identity_card_negative:
		// clickedNum = 2;
		// showPopupWindow(v);
		// break;
		// case R.id.iamge_identity_card_front:
		// clickedNum = 3;
		// showPopupWindow(v);
		// break;
		// case R.id.image_front_lighting:
		// clickedNum = 4;
		// showPopupWindow(v);
		// break;
		case R.id.merchant_settled_image:
			finish();
			break;
		// �ύ
		case R.id.merchantsettled_submit_btn:
			if (validateMessage()) {
				// if (!canSubmit ) {
				// return;
				// }
				// canSubmit = false;
				x = 1;
				startProgressDialog();
				mRunTask = new RunTask();
				mRunTask.execute("");
				// uploadSuccess();
				// }else {
				// uploadfaith();
			}
			// showProgressDialog(this);
			break;

		case R.id.user_province_frame_layout:
			Log.i("ddddd", "=================");
			if (mProvinDatasMap != null && mProvinDatasMap.length > 0) {
				// mProvinceImage.setImageResource(R.drawable.iconfont_xiala_up);
				mSettledListAdapter = new MerchantSettledListAdapter(
						getApplicationContext(), mProvinDatasMap);
				mSettledPopupWindow = new MerchantSettledPopupWindow(
						MerChantSettledActivity.this, mProvinceItemClick,
						mSettledListAdapter);
				mSettledPopupWindow.showAsDropDown(et_province);
			}
			break;

		case R.id.user_city_frame_layout:
			if (mCitys != null && mCitys.length > 0) {
				// mCityImage.setImageResource(R.drawable.iconfont_xiala_up);
				mSettledListAdapter = new MerchantSettledListAdapter(
						getApplicationContext(), mCitys);
				mSettledPopupWindow = new MerchantSettledPopupWindow(
						MerChantSettledActivity.this, mCityItemClick,
						mSettledListAdapter);
				mSettledPopupWindow.showAsDropDown(et_city);
			} else {
				Toast.makeText(getApplicationContext(), "��ѡ��ʡ�ݣ�",
						Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.user_area_frame_layout:
			// if (mAreas != null && mAreas.length > 0) {
			// view = inflater.inflate(R.layout.popup_city_layout, null);
			// mPopupWindow = new PopupWindow(view, LayoutParams.MATCH_PARENT,
			// 300, false);
			// mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
			// mPopupWindow.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
			// mPopupWindow.showAsDropDown(et_area);
			// mListView = (ListView) view.findViewById(R.id.popup_city_list);
			// mListAdapter = new CityListAdapter(getApplicationContext(),
			// mAreas);
			// mListView.setAdapter(mListAdapter);
			// mListView.setOnItemClickListener(mAreaItemClickListener);
			// }
			if (mAreas != null && mAreas.length > 0) {
				// mAreaImage.setImageResource(R.drawable.iconfont_xiala_up);
				mSettledListAdapter = new MerchantSettledListAdapter(
						getApplicationContext(), mAreas);
				mSettledPopupWindow = new MerchantSettledPopupWindow(
						MerChantSettledActivity.this, mAreaItemClick,
						mSettledListAdapter);
				mSettledPopupWindow.showAsDropDown(et_area);
			} else {
				Toast.makeText(getApplicationContext(), "��ѡ��ʡ�ݣ�",
						Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.user_category_frame_layout:
			if (mGroupList != null && mGroupList.size() > 0) {
				mTypeListAdapter = new MerchantSettledTypeListAdapter(
						getApplicationContext(), mGroupList);
				mTypePopupWindow = new MerchantSettledTypePopupWindow(
						MerChantSettledActivity.this, mTypeItemClick,
						mTypeListAdapter);
				mTypePopupWindow.showAsDropDown(user_category_edit);
			}
			break;
		}
	}

	OnItemClickListener mProvinceItemClick = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mSettledPopupWindow.dismiss();
			// mProvinceImage.setImageResource(R.drawable.iconfont_xiala2);
			mCitys = mCitisDatasMap.get(mProvinDatasMap[position]);
			mCityMaps = mCitysAllMap.get(mProvinDatasMap[position]);
			et_province.setText(mProvinDatasMap[position]);

			mAreas = mDistrictDatasMap.get(mCitys[0]);
			mAreaMaps = mDistrictAllMap.get(mCitys[0]);
			et_city.setText(mCitys[0]);
			et_area.setText(mAreas[0]);

			areaName = mAreas[0];
			cityName = mCitys[0];
			areaId = mAreaMaps.get(mAreas[0]);
			cityId = mCityMaps.get(mCitys[0]);

			provinceName = mProvinDatasMap[position];
			provinceId = mProvinceAllMap.get(mProvinDatasMap[position]);
			Log.i("mProvinceText", "provinceName:" + provinceName
					+ "===provinceId:" + provinceId);
			Log.i("mProvinceTextĬ��", "Ĭ��cityName:" + cityName + "===cityId:"
					+ cityId);
			Log.i("mProvinceTextĬ��", "Ĭ��areaName:" + areaName + "===areaId:"
					+ areaId);
		}
	};
	OnItemClickListener mCityItemClick = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mSettledPopupWindow.dismiss();
			// mCityImage.setImageResource(R.drawable.iconfont_xiala2);
			mAreas = mDistrictDatasMap.get(mCitys[position]);
			mAreaMaps = mDistrictAllMap.get(mCitys[position]);
			et_city.setText(mCitys[position]);

			et_area.setText(mAreas[0]);
			areaId = mAreaMaps.get(mAreas[0]);

			cityId = mCityMaps.get(mCitys[position]);
			cityName = mCitys[position];
			Log.i("city", "cityName:" + cityName + "===cityId:" + cityId);
		}
	};
	OnItemClickListener mAreaItemClick = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mSettledPopupWindow.dismiss();
			// mAreaImage.setImageResource(R.drawable.iconfont_xiala2);
			et_area.setText(mAreas[position]);
			areaId = mAreaMaps.get(mAreas[position]);
			areaName = mAreas[position];
			Log.i("mAreas", "areaName:" + areaName + "=========areaId:"
					+ areaId);
		}
	};
	OnItemClickListener mTypeItemClick = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			mTypePopupWindow.dismiss();
			user_category_edit.setText(mGroupList.get(position).get("name")
					.toString());
			mTypeId = mGroupList.get(position).get("id").toString();
			Constants.groupid = mGroupList.get(position).get("id").toString();
			Constants.groupname = mGroupList.get(position).get("name")
					.toString();
		}
	};

	private void startProgressDialog() {
		if (progressDialog == null) {
			progressDialog = CustomProgressDialog.createDialog(this);
			// progressDialog.setMessage("��¼��...");
		}
		progressDialog.show();
	}

	private void stopProgressDialog() {
		if (progressDialog != null) {
			progressDialog.dismiss();
			progressDialog = null;
		}
	}

	/**
	 * ��ⷢ����Ϣ������
	 */
	private Boolean validateMessage() {
		merchantName = user_name_edit.getText().toString();
		// ����̼�����
		if (StringUtil.isNullOrEmpty(merchantName)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_merchant_name), 0).show();
			return false;
		}
		address = user_adress_edit.getText().toString();
		// ����ַ
		if (StringUtil.isNullOrEmpty(address)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_write_address), 0).show();
			return false;
		}
		category = user_category_edit.getText().toString();
		// ����Ƿ�ѡ�����
		if (StringUtil.isNullOrEmpty(category)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_choose_category), 0)
					.show();
			return false;
		}

		legal_name = user_Legal_personname_edit.getText().toString();
		// ��ⷨ������
		if (StringUtil.isNullOrEmpty(legal_name)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_write_legalname), 0)
					.show();
			return false;
		}
		legal_id = user_legal_id_edit.getText().toString();
		// ��ⷨ������֤
		if (RegExpValidator.IsIDcard(legal_id)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_write_legalid), 0).show();
			return false;
		}
		phone = user_phone_edit.getText().toString();
		// ����ֻ�����
		if (VerifyCheck.isMobilePhoneVerify(phone)) {
			Toast.makeText(this,
					this.getString(R.string.correctly_phone_number), 0).show();
			return false;
		}
		return true;
	}

	/**
	 * ��ʾPopupWindow
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@SuppressLint({ "InlinedApi", "InflateParams" })
	private void showPopupWindow(View anchor) {
		popView = LayoutInflater.from(this).inflate(
				R.layout.popupwindow_pop_setted, null);
		popupWindow = new PopupWindow(popView, LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT);
		popupWindow.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
		popupWindow.setFocusable(true);// ��ý���
		popupWindow.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
		popupWindow.setAnimationStyle(R.style.AnimBottom);
		popupWindow.showAtLocation(anchor, Gravity.BOTTOM, 0, 0);
		popupWindow.update();// ˢ������
		// popupWindow.dismiss();
		popView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (popupWindow != null && popupWindow.isShowing()) {
					popupWindow.dismiss();
					popupWindow = null;
				}
				return false;
			}
		});
		// ���õ���¼�
		Button btn_taking_pictures = (Button) popView
				.findViewById(R.id.btn_taking_pictures_setted);
		Button btn_photo_album = (Button) popView
				.findViewById(R.id.btn_photo_album_setted);
		Button btn_cancle = (Button) popView.findViewById(R.id.btn_cancle);
		// ����
		btn_taking_pictures.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				deleteData(clickedNum);
				Intent intent = new Intent();
				intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
				// �ȶ���һ��ͼƬ�ļ���·��
				image_path = PathUtil.getPath_Image();
				Uri uri = Uri.fromFile(new File(image_path));
				intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
				intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
				startActivityForResult(intent, CAMER + clickedNum);
			}
		});
		// ��Ƭ
		btn_photo_album.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// ���ѡ�����յİ�ť����ͼƬ����ɾ��
				deleteData(clickedNum);
				if (Environment.getExternalStorageState().equals(
						Environment.MEDIA_MOUNTED)) {
					Intent intent = new Intent();
					intent.setAction(Intent.ACTION_GET_CONTENT);
					intent.addCategory(Intent.CATEGORY_OPENABLE);
					intent.setType("image/jpeg");
					startActivityForResult(intent, ALBUMS + clickedNum);
				}
			}
		});
		btn_cancle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				popupWindow.dismiss();
			}
		});
	}

	/**
	 * �����Ƭ
	 */
	@SuppressWarnings("deprecation")
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Bitmap small_Bitmap = null;
		// �ж��Ƿ񷵻سɹ�
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode >= ALBUMS && requestCode < ALBUMS + 5) {// ��������淵�ص�����
				if (data == null) {
					Toast.makeText(this, "ͼƬû���õ�", 0).show();
					return;
				}
				clickedNum = requestCode - ALBUMS;
				// �������
				Uri uri = data.getData();
				Log.i("msg", uri.toString());
				// ���ͼƬ·��
				String proj = MediaStore.Images.Media.DATA;
				Cursor c = this.managedQuery(uri, new String[] { proj }, null,
						null, null);
				c.moveToFirst();
				int column_index = c
						.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
				image_path = c.getString(column_index);
				Log.i("msg", "path: " + image_path);
				// �Ż�ͼƬ
				bitmap = BitmapUtil.createImageThumbnail(image_path);
				image_path = PathUtil.getPath_Image();// ���һ���µ�ͼƬ·��

			}

			if (requestCode >= CAMER && requestCode < CAMER + 5) {// ��������淵�ص�����
				clickedNum = requestCode - CAMER;
				if (!Environment.getExternalStorageState().equals(
						Environment.MEDIA_MOUNTED)) {
					Toast.makeText(this, "SD��������", 1).show();
					return;
				}
				// ���������ص�����//�Ӵ洢��·���л��ͼƬ
				bitmap = BitmapUtil.createImageThumbnail(image_path);// ���·���ڵ�������ʱ����Ѿ��õ���
				// ����sd����
				Log.i("msg", "pathName: " + image_path);
			}
			mPath[clickedNum] = image_path;
			Log.i("msgggggggg", image_path);

			BitmapUtil.saveBitmap(image_path, bitmap);// ����ͼƬ
			small_Bitmap = BitmapUtil.createImageThumbnail(bitmap);// ��С
			// ��ͼƬ�ŵ��ؼ���
			switch (clickedNum) {
			case 0:
				iamge_business_license_original.setImageBitmap(small_Bitmap);
				Log.i("msg", "photo0Im: " + iamge_business_license_original);
				break;
			case 1:
				iamge_business_license_copy.setImageBitmap(small_Bitmap);
				break;
			// case 2:
			// iamge_identity_card_negative.setImageBitmap(small_Bitmap);
			// break;
			// case 3:
			// iamge_identity_card_front.setImageBitmap(small_Bitmap);
			// break;
			// case 4:
			// iamge_front_lighting.setImageBitmap(small_Bitmap);
			// break;
			}
			addData();
		} else {
			Toast.makeText(this, "ͼƬû���õ�", 0).show();
		}
		popupWindow.dismiss();

		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * ����ͼƬ·����ͼƬ������
	 */
	private void addData() {
		// ����ͼƬ·����������
		String[] s = image_path.split("/");
		ImageBean bean = new ImageBean(clickedNum, s[s.length - 1], bitmap);
		imageList.add(bean);
	}

	/**
	 * ɾ������
	 */
	public static void deleteData(int index) {
		// ���ѡ�����յİ�ť����ͼƬ����ɾ��
		for (int i = 0; i < imageList.size(); i++) {
			if (imageList.get(i).get_id() == index) {
				BitmapUtil.deleteBitmap(imageList.get(i).getPath());
				imageList.remove(i);
			}
		}
	}

	// �̼���פ�����ϴ�
	private void uploadEvaluation(String[] path) throws Exception {
		String res = "";
		try {
			// 510000 510100 510104
			Log.i("path", path[0] + "====" + path[1]);
			String ss = "merchantname="
					+ user_name_edit.getText().toString()
					+ "&mtype="
					+ 3
					+ "&provinceid="
					+ provinceId
					// + et_province.getText().toString()
					+ "&cityid="
					+ cityId
					// + et_city.getText().toString()
					+ "&areaid="
					+ areaId
					// + et_area.getText().toString()
					+ "&address=" + user_adress_edit.getText().toString()
					+ "&groupid=" + mTypeId
					+ "&phone="
					+ user_phone_edit.getText().toString()
					+ "&legalpersonname="
					+ user_Legal_personname_edit.getText().toString()
					+ "&legalpersoncardno="
					+ user_legal_id_edit.getText().toString()
					// + "&blnum="
					// + user_Business_license_number_edit.getText().toString()
					+ "&usercode="
					+ user_shangji_tuijian_edit.getText().toString();
			String sign = Constants.sortsStr(ss);
			res = Constants.apply
					+ sign
					+ "&merchantname="
					+ URLEncoder.encode(user_name_edit.getText().toString(),
							"UTF-8")
					+ "&mtype="
					+ 3
					+ "&provinceid="
					+ provinceId
					// + et_province.getText().toString()
					+ "&cityid="
					+ cityId
					// + et_city.getText().toString()
					+ "&areaid="
					+ areaId
					// + et_area.getText().toString()
					+ "&address="
					+ URLEncoder.encode(user_adress_edit.getText().toString(),
							"UTF-8")
					+ "&groupid="
					+ mTypeId
					// + user_category_edit.getText().toString()
					+ "&phone="
					+ user_phone_edit.getText().toString()
					+ "&legalpersonname="
					+ URLEncoder.encode(user_Legal_personname_edit.getText()
							.toString(), "UTF-8")
					+ "&legalpersoncardno="
					+ user_legal_id_edit.getText().toString()
					// + "&blnum="
					// + URLEncoder.encode(user_Business_license_number_edit
					// .getText().toString(), "UTF-8")
					+ "&usercode="
					+ user_shangji_tuijian_edit.getText().toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HttpClient httpclient = new DefaultHttpClient();
		Log.i("res", res + "=========res========");
		HttpPost httpPost = new HttpPost(res);
		MultipartEntity mulentity = new MultipartEntity(
				HttpMultipartMode.BROWSER_COMPATIBLE);
		// mulentity.addPart("foodname", new StringBody("ssnn"));
		// mulentity.addPart("foodstyle", new StringBody("type"));
		// mulentity.addPart("price", new StringBody("123"));

		// ����ͼƬ��������
		if (!(path[0].equals(""))) {
			FileBody filebody = new FileBody(new File(path[0]));
			mulentity.addPart("foodimg1", filebody);
		}
		if (!(path[1].equals(""))) {
			FileBody filebody2 = new FileBody(new File(path[1]));
			mulentity.addPart("foodimg2", filebody2);
		}
		httpPost.setEntity(mulentity);
		HttpResponse response = httpclient.execute(httpPost);
		HttpEntity resEntity = response.getEntity();
		String str = EntityUtils.toString(resEntity, "utf-8");
		Log.i("response", response.getEntity() + "==========�ϴ���Ϣ==========="
				+ str);
		mMap = Constants.getJsonObject(str);
		stopProgressDialog();
		handler.sendEmptyMessageDelayed(2, 0);
	}

	class RunTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... arg0) {
			switch (x) {
			case 1:
				try {
					uploadEvaluation(mPath);
					// handler.sendEmptyMessageDelayed(1, 0);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					// uploadEvaluation(arg0[0]);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			return null;
		}
	}

	Runnable getgroups = new Runnable() {

		@Override
		public void run() {
			try {
				// String ss ="";
				// String sign = Constants.sortsStr(ss);
				long time = System.currentTimeMillis();
				String ss = "time=" + time;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getgroups + sign + "&time=" + time;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mMap", mMap + "================");
				mGroupList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mGroupList", mGroupList + "================");
				Constants.groupid = mGroupList.get(0).get("id").toString();

				// handler.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler = new Handler() {
		@SuppressLint({ "HandlerLeak", "InlinedApi" })
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1:
				break;
			case 2:
				LayoutInflater inflater = LayoutInflater
						.from(getApplicationContext());
				View view = inflater.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(user_adress_edit, Gravity.CENTER, 0, 0);
				popupW.update();// ˢ������
				popView.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mMap.get(1).get("Message") != null) {
					mWebView.setText(mMap.get(1).get("Message").toString());
				}
				// ȡ����ť
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						finish();
						popupW.dismiss();
					}
				});
				// Toast.makeText(getApplicationContext(),
				// mMap.get(1).get("Message").toString(), 0).show();
				break;
			}
		};
	};

	// /**
	// * ��ʾ�Ի���
	// */
	// protected void showProgressDialog(Context context) {
	// if (mDialog == null) {
	// mDialog = new AlertDialog.Builder(context).create();
	// mDialog.setCancelable(false);
	// }
	// if (!mDialog.isShowing()) {
	// mDialog.show();
	// mDialog.setContentView(R.layout.progress_bar);
	// }
	// }
	//
	// /**
	// * �ύ�ɹ�֮��
	// *
	// * @param view
	// */
	// private void uploadSuccess() {
	// if (mDialog != null && mDialog.isShowing()) {
	// mDialog.dismiss();
	// mDialog = null;
	// // clearInput();
	// canSubmit = true;
	// // Log.i("msg", "imageList.size(): " + imageList.size());
	// //
	// // Toast.makeText(MerChantSettledActivity.this, "�ύ���ݳɹ�", 1).show();
	// }
	// }
	//
	// /**
	// * �ύʧ��֮��
	// *
	// * @param view
	// */
	// private void uploadfaith() {
	// if (mDialog != null && mDialog.isShowing()) {
	// mDialog.dismiss();
	// mDialog = null;
	// // clearInput();
	// canSubmit = true;
	// Log.i("msg", "imageList.size(): " + imageList.size());
	// Toast.makeText(MerChantSettledActivity.this, "�ύ����ʧ��", 1).show();
	// }
	// }
}