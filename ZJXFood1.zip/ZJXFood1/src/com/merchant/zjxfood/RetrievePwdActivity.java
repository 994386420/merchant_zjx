package com.merchant.zjxfood;

import java.io.IOException;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.merchant.adapter.RetrieveSpinnerAdapter;
import com.merchant.constant.Constants;
import com.merchant.constant.MyApplication;
import com.merchant.json.ReadJson;
import com.merchant.log.MyLogActivity;
import com.merchant.util.ToastUtil;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author Administrator �������� ͨ���ֻ���֤�һ�����
 */
@SuppressLint("HandlerLeak")
public class RetrievePwdActivity extends Activity implements OnClickListener {

	private FrameLayout mFrameLayout1, mFrameLayout2, mFrameLayout3;
	private PopupWindow mPopupWindow;
	private ListView mListView;
	private String[] mArrays;
	private RetrieveSpinnerAdapter mSpinnerAdapter;
	private TextView mProblemText1, mProblemText2, mProblemText3;
	private ScrollView mScrollView;
	private Button mNextBtn, mResetBtn;
	private TextView mSetUpPwdText;
	private View mSetUpView, mSecurityView;
	private TextView mGetCode;
	private RelativeLayout mHeadLayout;
	private ImageView mBackImage;
	private EditText mPhoneEdit, mCodeEdit;
	private String code;
	private int n = 60;
	private Timer mTimer;
	private LinearLayout mCheckPhone, mSetNewPsw, mSafeCheck;
	private boolean isClick = true;
	private TextView mCodeText;
	private EditText mNewPwd, mNewPwd2;
	private Button mNewBtn;// �һ�������ɰ�ť
	private Pattern p = Pattern.compile("\\s*|\t|\r|\n");
	private HashMap<String, Object> mUserMapLists;
	private PopupWindow pop_window;
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;
	private MyApplication MyApplication;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.retrieve_password_layout);

		init();
		mArrays = getResources().getStringArray(R.array.problem);
	}

	private void init() {
		mNextBtn = (Button) findViewById(R.id.retrieve_next_btn);
		mSetUpView = findViewById(R.id.security_verification_setting_view);
		mGetCode = (TextView) findViewById(R.id.retrieve_pwd_get_code_text);
		mHeadLayout = (RelativeLayout) findViewById(R.id.title_retrieve_pwd_id);
		mBackImage = (ImageView) mHeadLayout
				.findViewById(R.id.retrieve_password_image);
		mPhoneEdit = (EditText) findViewById(R.id.retrieve_pwd_input_phone_text);
		mCodeEdit = (EditText) findViewById(R.id.retrieve_pwd_input_phone_code_text);
		mNewPwd = (EditText) findViewById(R.id.new_pwd_edit);
		mNewPwd2 = (EditText) findViewById(R.id.new_pwd_two_edit);
		mCodeText = (TextView) findViewById(R.id.retrieve_pwd_text);
		mCheckPhone = (LinearLayout) findViewById(R.id.retrieve_pwd_content_layout);
		mSetNewPsw = (LinearLayout) findViewById(R.id.set_newpwd_layout);
		mResetBtn = (Button) findViewById(R.id.reset_psw_btn);
		mSafeCheck = (LinearLayout) findViewById(R.id.retrieve_pwd_security_verification_layout);
		mGetCode.setOnClickListener(this);
		mSetNewPsw.setVisibility(View.GONE);
		mNextBtn.setOnClickListener(this);
		mResetBtn.setOnClickListener(this);
		mBackImage.setOnClickListener(this);
		mGetCode.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
	}

	@SuppressLint("InflateParams")
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.retrieve_next_btn:
			Log.i("gallery", code + "=======================");
			if (mCodeEdit.getText().toString().equals(code)) {
				mCheckPhone.setVisibility(View.GONE);
				mSafeCheck.setVisibility(View.GONE);
				mSetNewPsw.setVisibility(View.VISIBLE);

			} else {
				Toast.makeText(getApplicationContext(), "��֤���������",
						Toast.LENGTH_SHORT).show();
			}
			break;
		// �������������İ�ť
		case R.id.reset_psw_btn:
			if (!mNewPwd.getText().toString().equals("")
					&& !mNewPwd2.getText().toString().equals("")) {
				if (isPwd(mNewPwd.getText().toString())
						&& isPwd(mNewPwd2.getText().toString())) {
					if (mNewPwd.getText().toString()
							.equals(mNewPwd2.getText().toString())) {
						new Thread(resetPswRun).start();
					} else {
						Toast.makeText(getApplicationContext(), "�����������벻һ�£�",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(getApplicationContext(), "�����ʽ����ȷ��",
							Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(getApplicationContext(), "���벻��Ϊ�գ�",
						Toast.LENGTH_SHORT).show();
			}
			break;

		case R.id.retrieve_password_image:
			finish();
			break;
		case R.id.retrieve_pwd_get_code_text:
			if (!(mPhoneEdit.getText().toString().equals(""))) {

				if (isClick) {
					mGetCode.setTextColor(getResources().getColor(R.color.no));
					isClick = false;
					Random random = new Random();
					String result = "";
					for (int i = 0; i < 6; i++) {
						result += random.nextInt(10);
					}
					code = result;
					Log.i("test", code + "==========code=========");
					mTimer = new Timer();
					TimerTask task = new TimerTask() {
						public void run() {
							n--;
							if (n <= 0) {
								handler.sendEmptyMessageDelayed(4, 0);
							} else {
								handler.sendEmptyMessageDelayed(3, 0);
							}
						}
					};
					mTimer.schedule(task, 60, 1000);
					new Thread(codeRun).start();
				}
			} else {
				Toast.makeText(getApplicationContext(), "�ֻ��Ų���Ϊ��!",
						Toast.LENGTH_SHORT).show();

			}
			Log.i("gallery", code + "=======================");
			break;
		}

	}

	OnItemClickListener mItemClickListener1 = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			mProblemText1.setText(mArrays[position]);
			mPopupWindow.dismiss();
		}
	};

	OnItemClickListener mItemClickListener2 = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			mProblemText2.setText(mArrays[position]);
			mPopupWindow.dismiss();
		}
	};

	OnItemClickListener mItemClickListener3 = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id) {
			mProblemText3.setText(mArrays[position]);
			mPopupWindow.dismiss();

		}
	};

	Runnable codeRun = new Runnable() {
		@Override
		public void run() {
			try {
				// URLEncoder.encode("������", "UTF_8")
				String ss = "mobile=" + mPhoneEdit.getText().toString()
						+ "&Code=" + code;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getSmsMsg + sign + "&mobile="
						+ mPhoneEdit.getText().toString() + "&Code=" + code;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("codejson", mUserMapLists + "=====================");
				// String content = URLEncoder.encode("���м��ż��š�", "UTF_8")
				// + URLEncoder.encode(code, "UTF_8")
				// + URLEncoder
				// .encode("��ʳ����Ů(�̼Ұ�)�ֻ���֤�룬10��������Ч��", "UTF_8");
				// String json = ReadJson.readParse(Constants.getSmsMsg
				// + "&content=" + content + "&mobile="
				// + mPhoneEdit.getText().toString() + "&Code=" + code);
				handler.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				//
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!isNetworkConnected(getApplicationContext())) {
				handler.sendEmptyMessageDelayed(5, 0);
			} else {
				handler.sendEmptyMessageDelayed(6, 0);
			}

		}
	};

	public boolean isNetworkConnected(Context context) {
		if (context != null) {
			ConnectivityManager mConnectivityManager = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo mNetworkInfo = mConnectivityManager
					.getActiveNetworkInfo();
			if (mNetworkInfo != null) {
				return mNetworkInfo.isAvailable();
			}
		}
		return false;
	}

	// ��������runnable
	Runnable resetPswRun = new Runnable() {
		@Override
		public void run() {
			Looper.prepare();
			String sign = Constants.sortsStr("&uid=" + Constants.Id
					+ "&password="
					+ p.matcher(mNewPwd.getText().toString()).replaceAll(""));
			String json = Constants.updatepass + sign + "&uid=" + Constants.Id
					+ "&password="
					+ p.matcher(mNewPwd.getText().toString()).replaceAll("");
			Log.d("�һ�����json", Constants.updatepass + "mobile="
					+ mPhoneEdit.getText().toString() + "&password="
					+ p.matcher(mNewPwd.getText().toString()).replaceAll("")
					+ "===============");

			try {
				String res = ReadJson.readParse(json);
				if (!res.equals("0")) {
					handler.sendEmptyMessageDelayed(1, 0);
				} else {
					Toast.makeText(getApplicationContext(), "�޸�ʧ�ܣ�",
							Toast.LENGTH_SHORT).show();
				}
				Looper.loop();
				Log.i("��������", res + "=======���ý��========");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	@SuppressLint({ "InflateParams", "ClickableViewAccessibility", "ShowToast" })
	Handler handler = new Handler() {
		@SuppressLint("InlinedApi")
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				String str = "�޸ĳɹ��������µ�¼��";
				ToastUtil.showToastInfo(getApplicationContext(), str);
				intent.setClass(getApplicationContext(), MyLogActivity.class);
				MyApplication = (MyApplication) getApplication();
				MyApplication.setName("0");
				startActivity(intent);
				finish();
				break;
			case 2:
				mGetCode.setTextColor(getResources().getColor(R.color.no));
				isClick = false;
				break;
			case 3:
				mCodeText.setText(n + "");
				mCodeText.setVisibility(View.VISIBLE);

				break;
			case 4:
				mGetCode.setTextColor(getResources().getColor(R.color.white));
				mTimer.cancel();
				mTimer.purge();
				mTimer = null;
				isClick = true;
				n = 60;
				mCodeText.setVisibility(View.GONE);
				break;
			case 5:
				Toast.makeText(getApplicationContext(), "��������ʧ�ܣ����������Ƿ�����!", 0)
						.show();
				break;
			case 6:
				LayoutInflater inflater1 = LayoutInflater
						.from(getApplicationContext());
				View view1 = inflater1.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view1.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view1
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view1, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(mCodeEdit, Gravity.CENTER, 0, 0);
				popupW.update();// ˢ������
				view1.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						popupW.dismiss();
					}
				});
				break;
			}
		};
	};

	// ��֤����
	public static boolean isPwd(String str) {
		String regex = "[0-9A-Za-z]*";
		return match(regex, str);
	}

	private static boolean match(String regex, String str) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}
}
