package com.merchant.zjxfood;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("HandlerLeak")
public class RetrievePassWordActivity extends Activity implements OnClickListener {

	private ImageView set_password_image;
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private EditText user_newpassword_edit;
	private EditText corfirm_user_newpassword_edit;
	private Button user_save_password;
	private EditText corfirm_yzm;// ��֤��
	private TextView get_code;
	private TextView retrieve_pwd;
	private String code;
	private int n = 60;
	private Timer mTimer;
	private String phone = "15928046246";
	private boolean isClick = true;
	private PopupWindow pop_window;
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_merchant_set_password);
		init();
	}

	private void init() {
		set_password_image = (ImageView) findViewById(R.id.set_password_image);
		user_newpassword_edit = (EditText) findViewById(R.id.user_newpassword_edit);
		corfirm_user_newpassword_edit = (EditText) findViewById(R.id.corfirm_user_newpassword_edit);
		user_save_password = (Button) findViewById(R.id.user_save_password);
		corfirm_yzm = (EditText) findViewById(R.id.corfirm_yzm);
		get_code = (TextView) findViewById(R.id.get_code);
		retrieve_pwd = (TextView) findViewById(R.id.retrieve_pwd);
		set_password_image.setOnClickListener(this);
		user_save_password.setOnClickListener(this);
		get_code.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		Intent intent = new Intent();
		switch (v.getId()) {
		case R.id.set_password_image:
			finish();
			break;
		case R.id.get_code:
			// if (!(mPhoneEdit.getText().toString().equals(""))) {

			if (isClick) {
				get_code.setTextColor(getResources().getColor(R.color.gray));
				isClick = false;
				Random random = new Random();
				String result = "";
				for (int i = 0; i < 6; i++) {
					result += random.nextInt(10);
				}
				code = result;
				Log.i("test", code + "==========code=========");
				mTimer = new Timer();
				TimerTask task = new TimerTask() {
					public void run() {
						n--;
						if (n <= 0) {
							handler.sendEmptyMessageDelayed(4, 0);
						} else {
							handler.sendEmptyMessageDelayed(3, 0);
						}
					}
				};
				mTimer.schedule(task, 60, 1000);
				new Thread(codeRun).start();
			}
			// Toast.makeText(getApplicationContext(), "�ֻ��Ų���Ϊ��!",
			// Toast.LENGTH_SHORT).show();
			//
			// }
			Log.i("gallery", code + "=======================");
			break;

		case R.id.user_save_password:

			if (corfirm_yzm.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "�������ֻ���֤�룡",
						Toast.LENGTH_SHORT).show();
			} else if (user_newpassword_edit.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "�������������룡",
						Toast.LENGTH_SHORT).show();
			} else if (!corfirm_yzm.getText().toString().equals(code)) {
				Toast.makeText(getApplicationContext(), "��֤���������",
						Toast.LENGTH_SHORT).show();
			} else if (!user_newpassword_edit.getText().toString().equals(" ")
					&& !corfirm_user_newpassword_edit.getText().toString()
							.equals(" ")) {
				if (isPwd(user_newpassword_edit.getText().toString())
						&& isPwd(corfirm_user_newpassword_edit.getText()
								.toString())) {
					if (user_newpassword_edit
							.getText()
							.toString()
							.equals(corfirm_user_newpassword_edit.getText()
									.toString())) {
						new Thread(updatepaypass).start();
						// Toast.makeText(getApplicationContext(), "�����������óɹ���",
						// Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(getApplicationContext(), "�����������벻һ�£�",
								Toast.LENGTH_SHORT).show();
					}
				} else {
					Toast.makeText(getApplicationContext(), "�����ʽ����ȷ��",
							Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(getApplicationContext(), "���벻��Ϊ�գ�",
						Toast.LENGTH_SHORT).show();
			}

			break;

		}
	}

	// ��֤����
	public static boolean isPwd(String str) {
		String regex = "[0-9A-Za-z]*";
		return match(regex, str);
	}

	private static boolean match(String regex, String str) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}

	Runnable updatepaypass = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&password="
						+ user_newpassword_edit.getText().toString();
				String sign = Constants.sortsStr(ss);
				String strr = Constants.updatepaypass + sign + "&uid="
						+ Constants.Id + "&password="
						+ user_newpassword_edit.getText().toString();
				String json = ReadJson.readParse(strr);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mUserMapLists", "================" + mUserMapLists);
				handler.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler.sendEmptyMessageDelayed(5, 0);
		}
	};
	Runnable codeRun = new Runnable() {
		@Override
		public void run() {
			try {
				// URLEncoder.encode("������", "UTF_8")
				// String content = URLEncoder.encode("���м��ż��š�", "UTF_8")
				// + URLEncoder.encode(code, "UTF_8")
				// + URLEncoder
				// .encode("��ʳ����Ů(�̼Ұ�)�ֻ���֤�룬10��������Ч��", "UTF_8");
				String ss = "mobile=" + Constants.mobile + "&Code=" + code;
				String sign = Constants.sortsStr(ss);
				String str = Constants.getSmsMsg + sign + "&mobile="
						+ Constants.mobile + "&Code=" + code;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("codejson", mUserMapLists + "=====================");

				handler.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				//
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			handler.sendEmptyMessageDelayed(6, 0);
		}
	};
	Handler handler = new Handler() {
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@SuppressLint({ "InlinedApi", "ClickableViewAccessibility",
				"InflateParams", "HandlerLeak" })
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				// String str = "�޸ĳɹ��������µ�¼��";
				// ToastUtil.showToastInfo(getApplicationContext(), str);
				// intent.setClass(getApplicationContext(),
				// MyLogActivity.class);
				// startActivity(intent);
				//
				// finish();
				break;

			case 2:
				get_code.setTextColor(getResources().getColor(R.color.gray));
				isClick = false;
				break;
			case 3:
				retrieve_pwd.setText(n + "");
				retrieve_pwd.setVisibility(View.VISIBLE);

				break;
			case 4:
				get_code.setTextColor(getResources().getColor(
						R.color.main_title_color));
				mTimer.cancel();
				mTimer.purge();
				mTimer = null;
				isClick = true;
				n = 60;
				retrieve_pwd.setVisibility(View.GONE);
				break;
			case 5:
				LayoutInflater inflater = LayoutInflater
						.from(getApplicationContext());
				View view = inflater.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(user_newpassword_edit, Gravity.CENTER, 0,
						0);
				popupW.update();// ˢ������
				view.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						finish();
						popupW.dismiss();
					}
				});

				break;
			// Toast.makeText(getApplicationContext(),
			// mUserMapLists.get("Message").toString(),
			// Toast.LENGTH_SHORT).show();
			// break;
			case 6:
				LayoutInflater inflater1 = LayoutInflater
						.from(getApplicationContext());
				View view1 = inflater1.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view1.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view1
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view1, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(user_newpassword_edit, Gravity.CENTER, 0,
						0);
				popupW.update();// ˢ������
				view1.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						popupW.dismiss();
					}
				});
				break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
