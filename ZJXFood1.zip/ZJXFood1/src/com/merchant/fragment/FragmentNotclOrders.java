package com.merchant.fragment;



import com.zjxfood.merchant.activity.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;


public class FragmentNotclOrders extends Fragment{
	protected View mContentView;// 当前内容View
	private ListView mListView;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mContentView = inflater
				.inflate(R.layout.fragment_all_order, container, false);
		init();
		return mContentView;
	}
	
	private void init(){
		mListView = (ListView) mContentView.findViewById(R.id.listView_no_cl);
	}
}
