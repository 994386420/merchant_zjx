package com.merchant.fragment;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.merchant.manage.ManageFoodsOrederDetail;
import com.merchant.manage.ReviewsActivity;
import com.merchant.manage.UserReviewsActivity.MyAdapter;
import com.merchant.manage.UserReviewsActivity.ViewHolder;
import com.zjxfood.merchant.activity.R;

public class FragmentAllOrders extends Fragment {
	protected View mContentView;// 当前内容View
	private ListView mListView;
	private List<Map<String, Object>> mlistitem;
	

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mContentView = inflater
				.inflate(R.layout.fragment_all_order, container, false);
		init();
		return mContentView;
	}
	
	private void init(){
		mListView = (ListView) mContentView.findViewById(R.id.listView);
		mlistitem = getData();
		MyAdapter adapter = new MyAdapter(getActivity());
		mListView.setAdapter(adapter);
		mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub

			}
		});
	}
	private List<Map<String, Object>> getData() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		for (int i = 0; i < 10; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			// String url = "http://10.167.12.184:8080/examples/image/1.png";
			//
			// Bitmap bitmap = getImageByURL(url);

//			map.put("user_reviews_imageview", R.drawable.photo3);
			map.put("user_reviews_text1", "25555555");
			map.put("user_reviews_text2", "250");
			map.put("user_reviews_text3", "250");
			map.put("user_reviews_button", "查看详情");
			list.add(map);
		}
		return list;

	}
	public final class ViewHolder {
//		public ImageView user_reviews_imageview;
		public TextView user_reviews_text1;
		public TextView user_reviews_text2;
		public TextView user_reviews_text3;
		public Button foods_order_detail;
	}

	public class MyAdapter extends BaseAdapter {

		private LayoutInflater flater;

		public MyAdapter(Context content) {
			this.flater = LayoutInflater.from(content);
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mlistitem.size();
		}

		@Override
		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View converView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder hodler = null;
			if (converView == null) {
				hodler = new ViewHolder();
				converView = flater.inflate(R.layout.manage_foods_order_list_item,
						null);

				hodler.user_reviews_text1 = (TextView) converView
						.findViewById(R.id.d);
				hodler.user_reviews_text2 = (TextView) converView
						.findViewById(R.id.d1);
				hodler.user_reviews_text3 = (TextView) converView
						.findViewById(R.id.d2);
				hodler.foods_order_detail = (Button) converView
						.findViewById(R.id.foods_order_detail);

				converView.setTag(hodler);
			} else {
				hodler = (ViewHolder) converView.getTag();
			}
//			hodler.user_reviews_imageview
//					.setBackgroundResource((Integer) mlistitem.get(position)
//							.get("user_reviews_imageview"));
			hodler.user_reviews_text1.setText((String) mlistitem.get(position)
					.get("user_reviews_text1"));
			hodler.user_reviews_text2.setText((String) mlistitem.get(position)
					.get("user_reviews_text2"));
			hodler.user_reviews_text3.setText((String) mlistitem.get(position)
					.get("user_reviews_text3"));
			hodler.foods_order_detail.setText((String) mlistitem.get(position)
					.get("user_reviews_button"));
			hodler.foods_order_detail
					.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v) {
							//TODO Auto-generated method stub						
							Intent intent = new Intent();
							intent.setClass(getActivity(),
									ManageFoodsOrederDetail.class);
							startActivity(intent);
						}
					});
			return converView;
		}

	}
}
