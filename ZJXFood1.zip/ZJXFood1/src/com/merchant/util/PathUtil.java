package com.merchant.util;

import java.io.File;
import java.util.Calendar;
import java.util.Locale;

import android.os.Environment;
import android.text.format.DateFormat;

public class PathUtil {
	public static String path = Environment.getExternalStorageDirectory().getPath()+File.separator+"yappam";
	/**
	 * 创建sd中存放图片的路径 并返回图片的路径
	 * @return
	 */
	public static String getPath_Image(){
		String image_path = path;
		File dir = new File(image_path);
		if(!dir.exists()){
			dir.mkdirs();
		}
		String image_name = DateFormat.format("yyyyMMdd_hhmmss", Calendar.getInstance(Locale.CHINA))+".jpg";;
		String image_paths = dir.getPath()+File.separator+image_name;
		return image_paths;
	}
}
