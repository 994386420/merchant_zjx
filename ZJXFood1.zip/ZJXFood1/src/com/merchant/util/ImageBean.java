package com.merchant.util;

import android.graphics.Bitmap;

public class ImageBean {
	private int _id = -1;
	private String path;
	private Bitmap bit;
	public int get_id() {
		return _id;
	}
	public void set_id(int _id) {
		this._id = _id;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Bitmap getBit() {
		return bit;
	}
	public void setBit(Bitmap bit) {
		this.bit = bit;
	}
	public ImageBean(int _id, String path, Bitmap bit) {
		this._id = _id;
		this.path = path;
		this.bit = bit;
	}
	
	
}
