package com.merchant.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *  验证类，用来验证账号密码，手机邮箱，�?
 * @author CaoYe
 *
 */
public class VerifyCheck {
	
	/**
	 * 验证手机号码的格式是否正�?
	 */
	public static boolean isMobilePhoneVerify(String mobileString){
		if(mobileString ==null || "".equals(mobileString.trim())){
			return true;
		}else{
			Pattern p = Pattern.compile("^1[3|5|8][0-9]{9}$");
			Matcher m = p.matcher(mobileString.trim());
			if(!m.matches()){
				return true;
			}else{
				return false;
			}
		}
		
	}
}
