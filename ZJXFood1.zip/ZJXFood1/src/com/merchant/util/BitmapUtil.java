package com.merchant.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.merchant.base.BaseActivity;


import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.util.Log;

public class BitmapUtil {
	static Activity activity;

	/**
	 * ����ͼƬ��ѹ��ͼ  ��һ����  �ò���  ûЧ��
	 */
	public static Bitmap createImageThumbnail(InputStream scrSample){
		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inJustDecodeBounds = true;
		Bitmap bitmap = BitmapFactory.decodeStream(scrSample, null, opts);
		opts.inJustDecodeBounds = false;
		int w = opts.outWidth;
		int h = opts.outHeight;
		Log.i("msg", "w: "+w);
		int ww = 480;
		int hh = 800;
		int be = 1;
		if(w > h && w>ww){
			be = w/ww;
		}else if(w < h && h>hh){
			be = h/hh;
		}
		if(be <= 0){
			be = 1;//������Ϊ1
		}
		opts.inSampleSize = be;
		opts.inPreferredConfig = Config.ARGB_8888;
		opts.inPurgeable = true;
		opts.inInputShareable = true;
		Bitmap bitmap1 = BitmapFactory.decodeStream(scrSample, null, opts);
		
		return bitmap1;
		
	}
	/**
	 * ����ͼƬ��ѹ��ͼ  ��һ��ͼƬ·��
	 */
	public static Bitmap createImageThumbnail(String image_path){
		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inJustDecodeBounds = true;//�ܶ�
		BitmapFactory.decodeFile(image_path, opts);//��ͼƬ����Ϣ
		int w = opts.outWidth;
		int h = opts.outHeight;
		opts.inJustDecodeBounds = false;//��д
		int ww = 480;
		int hh = 800;
		int be = 1;
		if(w > h && w>ww){
			be = w/ww;
		}else if(w < h && h>hh){
			be = h/hh;
		}
		if(be <= 0){
			be = 1;//������Ϊ1
		}
		opts.inSampleSize = be;
		//��д�ɲ�д
		opts.inPreferredConfig = Config.ARGB_8888;//ûЧ��
		opts.inPurgeable = true;
		opts.inInputShareable = true;
		Bitmap bitmap = BitmapFactory.decodeFile(image_path, opts);//�Ż�֮���ͼƬ
		
		return compressImage(bitmap);
		
	}
	/**
	 * ����ͼƬ������ͼ  ��һ��Bitmap
	 */
	public static Bitmap createImageThumbnail(Bitmap bitmap){
		bitmap = Bitmap.createScaledBitmap(bitmap, BaseActivity.screenH/3-130,  BaseActivity.screenH/3-130, true);
		
		return bitmap;
		
	}
	/**
	 * ��ͼƬ
	 */
	public static void saveBitmap(String pathName,Bitmap bitmap){
		FileOutputStream out = null;
		File file = new File(pathName);
		try {
			out = new FileOutputStream(file);
			bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);//����ֱ���������������ͼƬ
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			try {
				out.flush();
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * ɾ��ͼƬ
	 */
	public static void deleteBitmap(String pathName){
		File file = new File(PathUtil.path+File.separator+pathName);
		try {
			if(file.exists()){
				file.delete();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	/**
	 * ͼƬ����������������
	 */
	public static Bitmap compressImage(Bitmap image){
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		image.compress(Bitmap.CompressFormat.JPEG, 100, baos);//��ͼƬ�ŵ��ܵ�����
		int quaity = 100;
		while(baos.toByteArray().length/1024 > 100){
			baos.reset();//�����
			image.compress(Bitmap.CompressFormat.JPEG, quaity, baos);
			quaity -= 10;
		}
		ByteArrayInputStream isbm = new ByteArrayInputStream(baos.toByteArray());
		Bitmap bitmap = BitmapFactory.decodeStream(isbm,null,null);
		return bitmap;
	}
	public static Bitmap getBitmapFromSDCard(String localUrl){
		return BitmapFactory.decodeFile(getFile(localUrl).getPath());
		
	}
	
	public static File getFile(String localUrl){
		File file = new File(localUrl);
		return file;
	}
	
	
}
