package com.merchant.util;

/**
 * 判断字符串是否为�?
 * @author CaoYe
 *
 */
public class StringUtil {
	
	public static boolean isNullOrEmpty(String content){
		boolean result = false;
		if(null == content || "".equals(content.trim())){
			return true;
		}
		return false;
	}
}
