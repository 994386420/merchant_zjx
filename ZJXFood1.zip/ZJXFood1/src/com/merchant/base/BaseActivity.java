package com.merchant.base;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.merchant.model.CityModel;
import com.merchant.model.DistrictModel;
import com.merchant.model.ProvinceModel;
import com.merchant.service.XmlParserHandler;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Window;
import android.widget.TextView;

public class BaseActivity extends Activity {
	public static int screenW;
	public static int screenH;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		Display m = this.getWindowManager().getDefaultDisplay();
		screenW = m.getWidth();
		screenH = m.getHeight();
		// setNetWork();
	}

	// public void setNetWork() {
	// StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
	// .detectDiskReads().detectDiskWrites().detectNetwork()
	// .penaltyLog()
	// .build());
	// StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
	// .detectLeakedSqlLiteObjects() // ̽�� SQLite���ݿ����
	// .penaltyLog() // ��ӡ logcat
	// .penaltyDeath().build());
	// }
	//
	//
	// protected void dialog() {
	// //���������ģʽ
	// AlertDialog.Builder builder = new Builder(BaseActivity.this);
	// TextView iv = new TextView(this);
	//
	// builder.setMessage("�ף�ȷ��Ҫ�˳���?");
	// // builder.setIcon(R.drawable.lo);
	// builder.setTitle("Hello");
	// builder.setPositiveButton("���ٶ���~",
	// new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog, int which) {
	// dialog.dismiss();
	// BaseActivity.this.finish();
	// }
	// });
	// builder.setNegativeButton("�ٹ���~",
	// new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog, int which) {
	// dialog.dismiss();
	// }
	// });
	// builder.create().show();
	// }

	/**
	 * ����ʡ
	 */
	protected String[] mProvinDatasMap;
	protected HashMap<String, String> mProvinceAllMap = new HashMap<String, String>();
	// protected String[] mProvinceDatas;
	/**
	 * key - ʡ value - ��
	 */
	protected Map<String, String[]> mCitisDatasMap = new HashMap<String, String[]>();
	protected HashMap<String, HashMap<String, String>> mCitysAllMap = new HashMap<String, HashMap<String, String>>();
	/**
	 * key - �� values - ��
	 */
	protected Map<String, String[]> mDistrictDatasMap = new HashMap<String, String[]>();
	protected HashMap<String, HashMap<String, String>> mDistrictAllMap = new HashMap<String, HashMap<String, String>>();
	/**
	 * key - �� values - �ʱ�
	 */
	protected Map<String, String> mZipcodeDatasMap = new HashMap<String, String>();

	/**
	 * ��ǰʡ������
	 */
	protected String mCurrentProviceName;
	protected String mCurrentProviceId;
	/**
	 * ��ǰ�е�����
	 */
	protected String mCurrentCityName;
	protected String mCurrentCityId;
	/**
	 * ��ǰ��������
	 */
	protected String mCurrentDistrictName = "";
	protected String mCurrentDistrictId = "";

	/**
	 * ��ǰ������������
	 */
	protected String mCurrentZipCode = "";

	/**
	 * ����ʡ������XML����
	 */

	protected void initProvinceDatas() {
		List<ProvinceModel> provinceList = null;
		AssetManager asset = getAssets();
		try {
			InputStream input = asset.open("province.xml");
			// ����һ������xml�Ĺ�������
			SAXParserFactory spf = SAXParserFactory.newInstance();
			// ����xml
			SAXParser parser = spf.newSAXParser();
			XmlParserHandler handler = new XmlParserHandler();
			parser.parse(input, handler);
			input.close();
			// ��ȡ��������������
			provinceList = handler.getDataList();
			// */ ��ʼ��Ĭ��ѡ�е�ʡ���С���
			if (provinceList != null && !provinceList.isEmpty()) {
				mCurrentProviceName = provinceList.get(0).getName();
				List<CityModel> cityList = provinceList.get(0).getCityList();
				if (cityList != null && !cityList.isEmpty()) {
					mCurrentCityName = cityList.get(0).getName();
					List<DistrictModel> districtList = cityList.get(0)
							.getDistrictList();
					mCurrentDistrictName = districtList.get(0).getName();
					mCurrentZipCode = districtList.get(0).getZipcode();
				}
			}
			// */
			// mProvinceDatas = new String[provinceList.size()];
			mProvinDatasMap = new String[provinceList.size()];
			for (int i = 0; i < provinceList.size(); i++) {
				// ��������ʡ������
				// mProvinceDatas[i] = provinceList.get(i).getName();
				mProvinDatasMap[i] = provinceList.get(i).getName();
				mProvinceAllMap.put(provinceList.get(i).getName(), provinceList
						.get(i).getId());
				List<CityModel> cityList = provinceList.get(i).getCityList();
				String[] cityNames = new String[cityList.size()];
				HashMap<String, String> cityMaps = new HashMap<String, String>();
				for (int j = 0; j < cityList.size(); j++) {
					// ����ʡ����������е�����
					cityNames[j] = cityList.get(j).getName();
					cityMaps.put(cityList.get(j).getName(), cityList.get(j)
							.getId());
					List<DistrictModel> districtList = cityList.get(j)
							.getDistrictList();
					String[] distrinctNameArray = new String[districtList
							.size()];
					HashMap<String, String> distrinctMap = new HashMap<String, String>();
					DistrictModel[] distrinctArray = new DistrictModel[districtList
							.size()];
					for (int k = 0; k < districtList.size(); k++) {
						// ����������������/�ص�����
						DistrictModel districtModel = new DistrictModel(
								districtList.get(k).getName(), districtList
										.get(k).getZipcode());
						// ��/�ض��ڵ��ʱ࣬���浽mZipcodeDatasMap
						mZipcodeDatasMap.put(districtList.get(k).getName(),
								districtList.get(k).getZipcode());
						distrinctArray[k] = districtModel;
						distrinctNameArray[k] = districtModel.getName();
						distrinctMap.put(districtModel.getName(),
								districtModel.getZipcode());
					}
					// ��-��/�ص����ݣ����浽mDistrictDatasMap
					mDistrictDatasMap.put(cityNames[j], distrinctNameArray);
					mDistrictAllMap.put(cityNames[j], distrinctMap);
				}
				// ʡ-�е����ݣ����浽mCitisDatasMap
				// Log.i("mCitisDatasMap",provinceList.get(i).getName()+"================="+cityNames[i]);
				mCitisDatasMap.put(provinceList.get(i).getName(), cityNames);
				mCitysAllMap.put(provinceList.get(i).getName(), cityMaps);
			}
			// Log.i("mCitisDatasMap",
			// mCitisDatasMap.get("zipcode")+"=================");
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {

		}
	}
}