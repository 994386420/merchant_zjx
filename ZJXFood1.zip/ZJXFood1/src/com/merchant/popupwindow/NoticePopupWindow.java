package com.merchant.popupwindow;

import java.util.ArrayList;
import java.util.HashMap;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

public class NoticePopupWindow extends PopupWindow {

	// private Button btn_take_photo, btn_pick_photo, btn_cancel;
	private View mMenuView;
	private TextView btn_cancel, mTitle, mContent;
	private LinearLayout mLayout;
	private TextView mWebView;

	public NoticePopupWindow(Activity context,
			ArrayList<HashMap<String, Object>> DataList) {
		super(context);
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mMenuView = inflater.inflate(R.layout.notice_popup_layout, null);
		mWebView = (TextView) mMenuView
				.findViewById(R.id.notice_popup_content_text2);
		mLayout = (LinearLayout) mMenuView
				.findViewById(R.id.notice_popup_layout);
		mTitle = (TextView) mMenuView
				.findViewById(R.id.notice_popup_title_text);
		// if (DataList.get(0).get("title") != null) {
		// mTitle.setText(DataList.get(0).get("title").toString());
		// }else {
		mTitle.setText("��ʾ");
		// }
		// if (DataList.get(0).get("content") != null) {
		// // mContent.setText(mList.get(0).get("content").toString());
		// mWebView.loadDataWithBaseURL(null, DataList.get(0).get("content")
		// .toString(), "text/html", "utf-8", null);
		// }else {
		mWebView.setText("ƽ̨֪ͨ");
		// }

		btn_cancel = (TextView) mMenuView
				.findViewById(R.id.notice_popup_cancel_text);
		// ȡ����ť
		btn_cancel.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// ���ٵ�����
				dismiss();
			}
		});
		// ���ð�ť����
		// ����SelectPicPopupWindow��View
		this.setContentView(mMenuView);
		// ����SelectPicPopupWindow��������Ŀ�
		this.setWidth(LayoutParams.FILL_PARENT);
		// ����SelectPicPopupWindow��������ĸ�
		this.setHeight(LayoutParams.MATCH_PARENT);
		// ����SelectPicPopupWindow��������ɵ��
		this.setFocusable(true);
		// ����SelectPicPopupWindow�������嶯��Ч��
		// this.setAnimationStyle(R.style.AnimBottom);
		// ʵ����һ��ColorDrawable��ɫΪ��͸��
		// ColorDrawable dw = new ColorDrawable(0xb0000000);
		ColorDrawable dw = new ColorDrawable(R.color.transparent2);
		// ����SelectPicPopupWindow��������ı���
		this.setBackgroundDrawable(dw);
		LayoutParams params = mLayout.getLayoutParams();
		params.height = LayoutParams.WRAP_CONTENT;
		mLayout.setLayoutParams(params);
		// mMenuView����OnTouchListener�����жϻ�ȡ����λ�������ѡ������������ٵ�����
		mMenuView.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
				int height = mMenuView.findViewById(R.id.notice_popup_layout)
						.getTop();
				int y = (int) event.getY();
				if (event.getAction() == MotionEvent.ACTION_UP) {
					if (y < height) {
						dismiss();
					}
				}
				return true;
			}
		});

	}

}
