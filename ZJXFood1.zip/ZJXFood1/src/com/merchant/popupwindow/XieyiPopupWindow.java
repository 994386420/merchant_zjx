package com.merchant.popupwindow;

import java.io.InputStream;

import org.apache.http.util.EncodingUtils;

import com.merchant.util.DensityUtils;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

public class XieyiPopupWindow extends PopupWindow {


//	private Button btn_take_photo, btn_pick_photo, btn_cancel;
	private View mMenuView;
	private TextView mAgree, mRefuse;
	private TextView mContentText;
	private Context mContext;
	private ScrollView mScrollView;
	
	public XieyiPopupWindow(Activity context,OnClickListener itemsOnClick) {
		super(context);
		mContext = context;
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mMenuView = inflater.inflate(R.layout.pop_xieyi, null);
		mAgree = (TextView) mMenuView.findViewById(R.id.popup_reg_xieyi_to_confirm_text);
		mRefuse = (TextView) mMenuView.findViewById(R.id.popup_reg_xieyi_cancel_cancel_text);
		mContentText = (TextView) mMenuView.findViewById(R.id.change_head_location_text);	
		mContentText.setText(getFromAssets("xieyi.txt"));	
		mScrollView = (ScrollView) mMenuView.findViewById(R.id.popup_jh_alert_scroll_layout);
//		mContentText.setMovementMethod(ScrollingMovementMethod.getInstance());
		LayoutParams params = mScrollView.getLayoutParams();
		params.height = DensityUtils.dp2px(mContext, 300);
		mScrollView.setLayoutParams(params);
		
		//���ð�ť����
		mAgree.setOnClickListener(itemsOnClick);
		mRefuse.setOnClickListener(itemsOnClick);
		//����SelectPicPopupWindow��View
		this.setContentView(mMenuView);
		//����SelectPicPopupWindow��������Ŀ�
		this.setWidth(LayoutParams.FILL_PARENT);
		//����SelectPicPopupWindow��������ĸ�
		this.setHeight(LayoutParams.MATCH_PARENT);
		//����SelectPicPopupWindow��������ɵ��
		this.setFocusable(true);
		//����SelectPicPopupWindow�������嶯��Ч��
		this.setAnimationStyle(R.style.AnimTop);
		//ʵ����һ��ColorDrawable��ɫΪ��͸��
		ColorDrawable dw = new ColorDrawable(0xb0000000);
		//����SelectPicPopupWindow��������ı���
		this.setBackgroundDrawable(dw);
		//mMenuView����OnTouchListener�����жϻ�ȡ����λ�������ѡ������������ٵ�����
		mMenuView.setOnTouchListener(new OnTouchListener() {
			
			public boolean onTouch(View v, MotionEvent event) {
				
				int height = mMenuView.findViewById(R.id.popup_xieyi_content_layout).getTop();
				int y=(int) event.getY();
				if(event.getAction()==MotionEvent.ACTION_UP){
					if(y<height){
						dismiss();
					}
				}				
				return true;
			}
		});
	}
	//��ȡЭ���ļ�
		public String getFromAssets(String fileName) {
			String result = "";
			try {
				InputStream in = mContext.getResources().getAssets().open(fileName);
				// ��ȡ�ļ����ֽ���
				int lenght = in.available();
				// ����byte����
				byte[] buffer = new byte[lenght];
				// ���ļ��е����ݶ���byte������
				in.read(buffer);
				result = EncodingUtils.getString(buffer, "GBK");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}
}
