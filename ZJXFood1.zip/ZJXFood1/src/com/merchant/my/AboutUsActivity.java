package com.merchant.my;

import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * ����ʳ����Ů
 * 
 * @author chenwei
 * 
 * 
 */
public class AboutUsActivity extends Activity implements OnClickListener {
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about_us);
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("��������");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

}
