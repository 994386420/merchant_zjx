package com.merchant.my;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.merchant.constant.Constants;
import com.merchant.constant.MyApplication;
import com.merchant.json.ReadJson;
import com.merchant.log.MyLogActivity;
import com.merchant.util.ToastUtil;
import com.zjxfood.merchant.activity.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginPasswordChangeActivity extends Activity implements
		OnClickListener {
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private EditText original_password_edit;
	private EditText new_password_edit;
	private EditText confirm_new_password_edit;
	private Button login_password_btn;
	private MyApplication MyApplication;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_password_change);
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("��¼�����޸�");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		original_password_edit = (EditText) findViewById(R.id.original_password_edit);
		new_password_edit = (EditText) findViewById(R.id.new_password_edit);
		confirm_new_password_edit = (EditText) findViewById(R.id.confirm_new_password_edit);
		login_password_btn = (Button) findViewById(R.id.login_password_btn);
		login_password_btn.setOnClickListener(this);
	}

	// if (isPwd(new_password_edit.getText().toString())
	// && isPwd(confirm_new_password_edit.getText()
	// .toString())) {
	// if (new_password_edit
	// .getText()
	// .toString()
	// .equals(confirm_new_password_edit.getText()
	// .toString())) {
	//
	// } else {
	// Toast.makeText(getApplicationContext(),
	// "�����������벻һ�£�", Toast.LENGTH_SHORT).show();
	// }
	// } else {
	// Toast.makeText(getApplicationContext(), "�����ʽ����ȷ��",
	// Toast.LENGTH_SHORT).show();
	// }
	// } else {
	// Toast.makeText(getApplicationContext(), "���벻��Ϊ�գ�",
	// Toast.LENGTH_SHORT).show();
	// }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.login_password_btn:
			if (original_password_edit.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "������ԭ���룡",
						Toast.LENGTH_SHORT).show();
			} else if (new_password_edit.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "�����������룡",
						Toast.LENGTH_SHORT).show();
			} else if (confirm_new_password_edit.getText().toString()
					.equals("")) {
				Toast.makeText(getApplicationContext(), "��ȷ�������룡",
						Toast.LENGTH_SHORT).show();
			} else if (!original_password_edit.getText().toString()
					.equals(Constants.password)) {
				Toast.makeText(getApplicationContext(), "ԭ��������������������룡",
						Toast.LENGTH_SHORT).show();
				Log.i("msg", "" + Constants.password);
			} else if (!new_password_edit.getText().toString()
					.equals(confirm_new_password_edit.getText().toString())) {
				Toast.makeText(getApplicationContext(), "�����������벻һ�£���ȷ�Ϻ��ٴ����룡",
						Toast.LENGTH_SHORT).show();
			} else {
				new Thread(updatepass).start();
				handler.sendEmptyMessageDelayed(1, 0);
				// Toast.makeText(getApplicationContext(), "�����޸ĳɹ���",
				// Toast.LENGTH_SHORT).show();
			}
			break;

		}
	}

	// ��֤����
	public static boolean isPwd(String str) {
		String regex = "[0-9A-Za-z]*";
		return match(regex, str);
	}

	private static boolean match(String regex, String str) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}

	Runnable updatepass = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&password="
						+ new_password_edit.getText().toString();
				String sign = Constants.sortsStr(ss);
				String strr = Constants.updatepass + sign + "&uid="
						+ Constants.Id + "&password="
						+ new_password_edit.getText().toString();
				Log.i("ID", "================" + Constants.Id);
				String json = ReadJson.readParse(strr);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("mMap", "================" + mMap);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mDataList", "================" + mDataList);
				// if (mMap.get(0).get("Code").equals("200")) {
				//

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		Intent intent = new Intent();

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				String str = "�޸ĳɹ��������µ�¼��";
				ToastUtil.showToastInfo(getApplicationContext(), str);
				intent.setClass(getApplicationContext(), MyLogActivity.class);
				MyApplication = (MyApplication) getApplication();
				MyApplication.setName("0");
				startActivity(intent);
				finish();
				break;
			case 2:

				break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

}
