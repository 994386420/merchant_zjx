package com.merchant.my;

/**
 * �ҵ���Ϣ
 * 
 * @author chenwei
 * 
 * 
 */
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.merchant.pay.PayActivity;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class MyMessageActivity extends Activity implements OnClickListener {
	private TextView text_title;// ����
	// private LinearLayout my_address_layout;// ��ַ
	private ImageView manage_title_back_image;// ����
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mMap;
	private ArrayList<HashMap<String, Object>> mDataList;
	private TextView merchant_name;// �̼�����
	private TextView user_name;// �˺�
	private TextView merchant_code;// �Ƽ���
	private TextView merchant_phone;// �绰
	private TextView merchant_address;// ��ַ
	private TextView merchant_activity;// �
	private Button save_btn;
	private PopupWindow pop_window;
	private TextView mWebView;
	private TextView btn_cancel;
	private PopupWindow popupW = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activty_my_message);
		new Thread(getmyinfo).start();
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("�ҵ���Ϣ");
		// my_address_layout = (LinearLayout)
		// findViewById(R.id.my_address_layout);
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		merchant_name = (TextView) findViewById(R.id.merchant_name);
		user_name = (TextView) findViewById(R.id.user_name);
		merchant_code = (TextView) findViewById(R.id.merchant_code);
		merchant_phone = (TextView) findViewById(R.id.merchant_phone);
		merchant_address = (TextView) findViewById(R.id.merchant_address);
		merchant_activity = (TextView) findViewById(R.id.merchant_activity);
		save_btn = (Button) findViewById(R.id.my_save_btn);

		manage_title_back_image.setOnClickListener(this);
		// my_address_layout.setOnClickListener(this);
		save_btn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		Intent intent = new Intent();
		switch (v.getId()) {
		// case R.id.my_address_layout:
		// intent.setClass(getApplicationContext(),
		// MyAddressChooseActivity.class);
		// startActivity(intent);
		// break;
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.my_save_btn:
			// Log.i("json", "++++++++++++++++++++=" + mMap);
			new Thread(updateactivity).start();
			break;
		}
	}

	Runnable getmyinfo = new Runnable() {

		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&mtype=" + Constants.mtype;
				String sign = Constants.sortsStr(ss);
				Log.i("sign", "================" + sign);
				String str = Constants.getmyinfo + sign + "&uid="
						+ Constants.Id + "&mtype=" + Constants.mtype;
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				// Log.i("json", "++++++++++++++++++++=" + mMap);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				// Log.i("mDataList", "================" + mDataList);
				handler1.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Runnable updateactivity = new Runnable() {
		@Override
		public void run() {
			try {
				String ss = "uid=" + Constants.Id + "&activity="
						+ merchant_activity.getText().toString();
				String sign = Constants.sortsStr(ss);
				// Log.i("sign", "================" + sign);
				String str = Constants.updateactivity
						+ sign
						+ "&uid="
						+ Constants.Id
						+ "&activity="
						+ URLEncoder.encode(merchant_activity.getText()
								.toString(), "UTF-8");
				String json = ReadJson.readParse(str);
				mUserMapLists = Constants.getJson2Object(json);
				Log.i("jgggggggggggggggg", "++++++++++++++++++++=" + mMap);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("gggggggggggg", "================" + mDataList);
				handler1.sendEmptyMessageDelayed(2, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler1 = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:

				if (mDataList.get(0).get("merchantname") != null) {
					merchant_name.setText(mDataList.get(0).get("merchantname")
							.toString());
				} else {
					merchant_name.setText("");
				}
				if (mDataList.get(0).get("username") != null) {
					user_name.setText(mDataList.get(0).get("username")
							.toString());
				} else {
					user_name.setText("");
				}
				if (mDataList.get(0).get("usercode") != null) {
					merchant_code.setText(mDataList.get(0).get("usercode")
							.toString());
				} else {
					merchant_code.setText("");
				}
				if (mDataList.get(0).get("phone") != null) {
					merchant_phone.setText(mDataList.get(0).get("phone")
							.toString());
				} else {
					merchant_phone.setText("");
				}

				if (mDataList.get(0).get("address") != null) {
					merchant_address.setText(mDataList.get(0).get("address")
							.toString());
				} else {
					merchant_address.setText("");
				}

				if (mDataList.get(0).get("introduction") != null) {
					merchant_activity.setText(mDataList.get(0)
							.get("introduction").toString());
				} else {
					merchant_activity.setText("");
				}

				break;
			case 2:
				LayoutInflater inflater = LayoutInflater
						.from(getApplicationContext());
				View view = inflater.inflate(R.layout.pop_merchant_successd,
						null);
				mWebView = (TextView) view.findViewById(R.id.notice_popup);
				btn_cancel = (TextView) view
						.findViewById(R.id.popup_cancel_text);
				popupW = new PopupWindow(view, LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT, false);
				popupW.setBackgroundDrawable(new ColorDrawable(-00000000));// ���ñ���͸��
				popupW.setFocusable(true);// ��ý���
				popupW.setOutsideTouchable(true);// ���õ�������⣬popupWindow��ʧ
				popupW.setAnimationStyle(R.style.AnimBottom);
				popupW.showAtLocation(user_name, Gravity.CENTER, 0, 0);
				popupW.update();// ˢ������
				view.setOnTouchListener(new OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if (popupW != null && popupW.isShowing()) {
							popupW.dismiss();
							popupW = null;
						}
						return false;
					}
				});
				if (mUserMapLists.get("Message") != null) {
					mWebView.setText(mUserMapLists.get("Message").toString());
				}
				btn_cancel.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						finish();
						popupW.dismiss();
					}
				});
				break;			
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}
}
