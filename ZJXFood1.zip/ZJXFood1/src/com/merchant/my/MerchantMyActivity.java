package com.merchant.my;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import com.merchant.base.ExitApplication;
import com.merchant.constant.Constants;
import com.merchant.constant.MyApplication;
import com.merchant.home.SetPassWordActivity;
import com.merchant.log.MyLogActivity;
import com.merchant.manage.ActivationMemberActivity;
import com.merchant.manage.MerchantManageActivity;
import com.merchant.manage.XiYiActivity;
import com.merchant.util.ParseXmlService;
import com.merchant.util.UpdateVersionService;
import com.zjxfood.merchant.activity.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * ʳ����Ů�̼Ұ� �ҵ�ҳ��
 * 
 * @author chenwei
 * 
 * 
 */
public class MerchantMyActivity extends Activity implements OnClickListener {

	private LinearLayout merchant_manage_layout2;// ��Ӫ
	private LinearLayout merchant_home_layout2;// ��ҳ
	private LinearLayout merchant_huiyuan_layout2;// ��Ա
	private FrameLayout my_message_frame_layout;// �ҵ���Ϣ
	private FrameLayout login_password_change_frame_layout;// ��¼�����޸�
	private FrameLayout propose_password_change_frame_layout;// ���������޸�
	private FrameLayout about_us_frame_layout;// ��������
	private ImageButton check_update_imagebtn;// ����
	private TextView mVersionText;// ��ǰ�汾
	private FrameLayout clear_rubbish_frame;// ��������
	private String version;
	private UpdateVersionService updateVersionService;
	private TextView my_title_text;
	private Button mCancelBtn;
	boolean isExit;
	private HashMap<String, String> hashMap;// �洢���°汾��xml��Ϣ
	private boolean isUpdate = false;
	private MyApplication MyApplication;
	private TextView cache;
	private FrameLayout xiyi_ll;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my);
		ExitApplication.getInstance().addActivity(this);
		ExitApplication.getInstance().addMyActivity(this);
		init();
		if (Constants.mtype.equals("3")) {
			my_message_frame_layout.setVisibility(View.GONE);
		} else if (Constants.mtype.equals("1")) {
			merchant_manage_layout2.setVisibility(View.GONE);
		} else if (Constants.mtype.equals("2")) {
			merchant_manage_layout2.setVisibility(View.GONE);
		}
		// ��ȡpackagemanager��ʵ��
		PackageManager packageManager = getPackageManager();
		// getPackageName()���㵱ǰ��İ�����0�����ǻ�ȡ�汾��Ϣ
		PackageInfo packInfo;
		try {
			packInfo = packageManager.getPackageInfo(getPackageName(), 0);
			version = packInfo.versionName;
			// Log.i("version", version + "=======version==========");
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		mVersionText.setText(version + "");
		// try {
		// cache.setText(CleanUtil.getCacheSize(getCacheDir()));
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

	}

	private void init() {
		merchant_home_layout2 = (LinearLayout) findViewById(R.id.merchant_home_layout2);
		merchant_manage_layout2 = (LinearLayout) findViewById(R.id.merchant_manage_layout2);
		my_message_frame_layout = (FrameLayout) findViewById(R.id.my_message_frame_layout);
		login_password_change_frame_layout = (FrameLayout) findViewById(R.id.login_password_change_frame_layout);
		propose_password_change_frame_layout = (FrameLayout) findViewById(R.id.propose_password_change_frame_layout);
		about_us_frame_layout = (FrameLayout) findViewById(R.id.about_us_frame_layout);
		check_update_imagebtn = (ImageButton) findViewById(R.id.check_update_imagebtn);
		mVersionText = (TextView) findViewById(R.id.version_text);
		clear_rubbish_frame = (FrameLayout) findViewById(R.id.clear_rubbish_framelayout);
		my_title_text = (TextView) findViewById(R.id.my_title_text);
		my_title_text.setText(Constants.merchantname);
		mCancelBtn = (Button) findViewById(R.id.my_cancel_btn);
		merchant_huiyuan_layout2 = (LinearLayout) findViewById(R.id.merchant_huiyuan_layout2);
		cache = (TextView) findViewById(R.id.cache);
		xiyi_ll = (FrameLayout) findViewById(R.id.xiyi_ll);
		xiyi_ll.setOnClickListener(this);
		merchant_home_layout2.setOnClickListener(this);
		merchant_manage_layout2.setOnClickListener(this);
		my_message_frame_layout.setOnClickListener(this);
		login_password_change_frame_layout.setOnClickListener(this);
		propose_password_change_frame_layout.setOnClickListener(this);
		about_us_frame_layout.setOnClickListener(this);
		check_update_imagebtn.setOnClickListener(this);
		clear_rubbish_frame.setOnClickListener(this);
		mCancelBtn.setOnClickListener(this);
		merchant_huiyuan_layout2.setOnClickListener(this);
		if (Constants.mtype.equals("1") || Constants.mtype.equals("3")) {
			merchant_huiyuan_layout2.setVisibility(View.GONE);
		}
	}

	@Override
	public void onClick(View v) {
		Intent intent = new Intent();
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.merchant_home_layout2:
			new Thread(Run).start();
			break;
		case R.id.merchant_manage_layout2:
			intent.setClass(getApplicationContext(),
					MerchantManageActivity.class);
			startActivity(intent);
			finish();
			break;
		case R.id.merchant_huiyuan_layout2:
			intent.setClass(getApplicationContext(),
					ActivationMemberActivity.class);
			startActivity(intent);
			finish();
			break;
		// �ҵ���Ϣ
		case R.id.my_message_frame_layout:
			intent.setClass(getApplicationContext(), MyMessageActivity.class);
			startActivity(intent);
			break;
		case R.id.login_password_change_frame_layout:
			intent.setClass(getApplicationContext(),
					LoginPasswordChangeActivity.class);
			startActivity(intent);
			break;
		case R.id.propose_password_change_frame_layout:
			intent.setClass(getApplicationContext(), SetPassWordActivity.class);
			startActivity(intent);
			break;
		case R.id.about_us_frame_layout:
			intent.setClass(getApplicationContext(), AboutUsActivity.class);
			startActivity(intent);
			break;
		case R.id.xiyi_ll:
			intent.setClass(getApplicationContext(), XiYiActivity.class);
			startActivity(intent);
			break;
		case R.id.check_update_imagebtn:
			MyLogActivity.num = "1";
			Log.i("merchant", "++++++++++" + MyLogActivity.num);
			new Thread(startUpdateRun).start();
			break;
		// ��������
		case R.id.clear_rubbish_framelayout:
			SharedPreferences sp = getApplicationContext()
					.getSharedPreferences("MyMerchants", MODE_PRIVATE);
			Editor editor = sp.edit();
			editor.clear();
			editor.commit();
			Toast.makeText(getApplicationContext(), "����ɹ���", Toast.LENGTH_SHORT)
					.show();
			break;

		case R.id.my_cancel_btn: // �˳���¼ Constants.onLine = 0;
			Constants.clearUserInfo();
			SharedPreferences sp1 = getApplicationContext()
					.getSharedPreferences("MyMerchants", MODE_PRIVATE);
			Editor editor1 = sp1.edit();
			editor1.clear();
			editor1.commit();
			MyApplication = (MyApplication) getApplication();
			MyApplication.setName("0");
			intent.setClass(getApplicationContext(), MyLogActivity.class);
			startActivity(intent);
			finish();
			break;
		}
	}

	Runnable updateRun = new Runnable() {
		@Override
		public void run() {
			if (isUpdate()) {
				handler.sendEmptyMessageDelayed(4, 0);
			}
		}
	};
	// ����
	Runnable startUpdateRun = new Runnable() {
		@Override
		public void run() {
			Looper.prepare();
			updateVersionService = new UpdateVersionService(Constants.update,
					MerchantMyActivity.this);// ��������ҵ�����
			updateVersionService.checkUpdate();// ���ü����µķ���,������Ը���.�͸���.���ܸ��¾���ʾ�Ѿ������µİ汾��
			Looper.loop();
		}
	};
	Runnable Run = new Runnable() {

		@Override
		public void run() {
			try {
				if (Constants.mtype.equals("1")) {
					handler.sendEmptyMessageDelayed(1, 1);
				} else if (Constants.mtype.equals("2")) {
					handler.sendEmptyMessageDelayed(2, 1);
				} else if (Constants.mtype.equals("3")) {
					handler.sendEmptyMessageDelayed(3, 1);
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	@SuppressLint("HandlerLeak")
	Handler handler = new Handler() {
		@SuppressLint("HandlerLeak")
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				// ������
				ExitApplication.getInstance().finishMy();
				break;
			case 2:
				// ����Ժ
				ExitApplication.getInstance().finishMy();
				break;
			case 3:
				// ������
				ExitApplication.getInstance().finishMy();
				break;
			case 4:
				new Thread(startUpdateRun).start();
				break;
			}
		};
	};

	private boolean isUpdate() {
		int versionCode = Integer.parseInt(version);
		Log.i("version", "=============1========" + versionCode);
		try {
			// ��version.xml�ŵ������ϣ�Ȼ���ȡ�ļ���Ϣ
			URL url = new URL(Constants.update);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(5 * 1000);
			conn.setRequestMethod("GET");// ����Ҫ��д
			InputStream inputStream = conn.getInputStream();
			// ����XML�ļ���
			ParseXmlService service = new ParseXmlService();
			hashMap = service.parseXml(inputStream);
			Log.i("version",
					"=========2============"
							+ Integer.valueOf(hashMap.get("version")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (null != hashMap) {
			int serverCode = Integer.valueOf(hashMap.get("version"));
			Log.i("version", serverCode + "=====================" + versionCode);
			// �汾�ж�
			if (serverCode != versionCode) {
				// Toast.makeText(context, "�°汾��: " + serverCode,
				// Toast.LENGTH_SHORT).show();
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exit();
			return false;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	private void exit() {
		if (!isExit) {
			isExit = true;
			Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",
					Toast.LENGTH_SHORT).show();
			// ����handler�ӳٷ��͸���״̬��Ϣ
			mHandler.sendEmptyMessageDelayed(0, 2000);
		} else {
			ExitApplication.getInstance().exit();
			System.exit(0);
		}
	}

	@SuppressLint("HandlerLeak")
	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			isExit = false;
		}

	};

}
