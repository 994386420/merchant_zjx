package com.merchant.my;

import java.util.ArrayList;
import java.util.HashMap;

import com.merchant.constant.Constants;
import com.merchant.json.ReadJson;
import com.zjxfood.merchant.activity.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ProposePasswordChangeActivity extends Activity implements
		OnClickListener {
	private TextView text_title;// ����
	private ImageView manage_title_back_image;// ����
	private ArrayList<HashMap<String, Object>> mMap;
	private HashMap<String, Object> mUserMapLists;
	private ArrayList<HashMap<String, Object>> mDataList;
	private EditText original_password_edit_propose;
	private EditText new_password_edit_propose;
	private EditText confirm_new_password_edit_propose;
	private Button take_pass_save;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_proposed_password_change);
		init();
	}

	private void init() {
		text_title = (TextView) findViewById(R.id.manage_title_text);
		text_title.setText("���������޸�");
		manage_title_back_image = (ImageView) findViewById(R.id.manage_title_back_image);
		manage_title_back_image.setOnClickListener(this);
		original_password_edit_propose = (EditText) findViewById(R.id.original_password_edit_propose);
		new_password_edit_propose = (EditText) findViewById(R.id.new_password_edit_propose);
		;
		confirm_new_password_edit_propose = (EditText) findViewById(R.id.confirm_new_password_edit_propose);
		take_pass_save = (Button) findViewById(R.id.take_pass_save);
		take_pass_save.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.manage_title_back_image:
			finish();
			break;
		case R.id.take_pass_save:
			if (original_password_edit_propose.getText().toString().equals("")) {
				Toast.makeText(getApplicationContext(), "������ԭ���룡",
						Toast.LENGTH_SHORT).show();
			} else if (new_password_edit_propose.getText().toString()
					.equals("")) {
				Toast.makeText(getApplicationContext(), "�����������룡",
						Toast.LENGTH_SHORT).show();
			} else if (confirm_new_password_edit_propose.getText().toString()
					.equals("")) {
				Toast.makeText(getApplicationContext(), "��ȷ�������룡",
						Toast.LENGTH_SHORT).show();
				// } else if
				// (!original_password_edit_propose.getText().toString()
				// .equals(Constants.password)) {
				// Toast.makeText(getApplicationContext(), "ԭ��������������������룡",
				// Toast.LENGTH_SHORT).show();
				// Log.i("msg","" + Constants.password);
			} else if (!new_password_edit_propose
					.getText()
					.toString()
					.equals(confirm_new_password_edit_propose.getText()
							.toString())) {
				Toast.makeText(getApplicationContext(), "�����������벻һ�£���ȷ�Ϻ��ٴ����룡",
						Toast.LENGTH_SHORT).show();
			} else {
				new Thread(updatepaypass).start();
				// handler.sendEmptyMessageDelayed(1, 0);
				// Toast.makeText(getApplicationContext(), "�����޸ĳɹ���",
				// Toast.LENGTH_SHORT).show();
			}
			break;

		}
	}

	Runnable updatepaypass = new Runnable() {
		@Override
		public void run() {
			try {
				// String ss = "uid=" + Constants.Id + "&isjh=" + true +
				// "&page="
				// + 1 + "&pagesize=" + 20 + "&time=" + str;
				// String sign = Constants.sortsStr(ss);
				String strr = Constants.updatepaypass + "&uid=" + Constants.Id
						+ "&password="
						+ new_password_edit_propose.getText().toString();
				String json = ReadJson.readParse(strr);
				mUserMapLists = Constants.getJson2Object(json);
				mDataList = Constants.getJsonArray(mUserMapLists.get("Data")
						.toString());
				Log.i("mDataList", "================" + mMap);
				handler.sendEmptyMessageDelayed(1, 0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			Intent intent = new Intent();
			switch (msg.what) {
			case 1:
				// String str = "�޸ĳɹ��������µ�¼��";
				// ToastUtil.showToastInfo(getApplicationContext(), str);
				// intent.setClass(getApplicationContext(),
				// MyLogActivity.class);
				// startActivity(intent);
				//
				// finish();
				break;
			}
		};
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // ���µ������BACK��ͬʱû���ظ�
			// do something here
			finish();
		}

		return super.onKeyDown(keyCode, event);
	}

}
